# Änderungsprotokoll

Das Changelog dokumentiert die produktiven Funktionen und sichtbaren Verbesserungen der Schützen-App. Interne Umbauten und überholte Zwischenstände werden nicht einzeln aufgeführt.

## 2.40.18

- Der App-Start versucht fehlgeschlagene Inhaltsabrufe automatisch erneut.
- Bei einem vorübergehenden Fehler erscheint ein verständlicher Hinweis zum Herunterwischen mit zusätzlicher Tipp-Aktion.

## 2.40.17

- Die Zurück-Schaltfläche in der Detailansicht erhält eine kompaktere Schrift und mehr Abstand zum folgenden Inhalt.

## 2.40.16

- Die Zurück-Aktion in der Detailansicht wird als kompakte pillenförmige Schaltfläche mit der variablen App-Designfarbe dargestellt.

## 2.40.15

- Detailansichten bieten jetzt eine Zurück-Aktion zur ursprünglichen Karte und stellen deren Position in der Terminübersicht wieder her.
- Die App verwendet einheitliche eigene Layout-Abstände; die überflüssige Theme-Abstandsoption wurde aus den Einstellungen entfernt.

## 2.40.14

- Detailansichten zeigen das Startdatum beziehungsweise den vollständigen Zeitraum jetzt direkt unter dem Terminnamen.

## 2.40.13

- Tageskarten zeigen jetzt oberhalb des Titels ebenfalls den Namen der zugeordneten Gruppe.

## 2.40.12

- Gruppen können bereits importierte Termine vor späteren Feed-Aktualisierungen schützen, während neue Termine weiterhin einmalig importiert werden.

## 2.40.11

- Der Kalenderimport erkennt bereits vorhandene manuelle Termine bei vollständig identischen Daten und legt dadurch keine unnötigen Dubletten an.

## 2.40.10

- Kleine Fehlerkorrekturen und Verbesserungen an der Darstellung.

## 2.40.9

- Lange Termintitel werden auf kleinen Bildschirmen responsiv dargestellt und bleiben dadurch auch auf iPhones innerhalb der Karten gut lesbar.

## 2.40.8

- Überschriften übernehmen die Typografie des aktiven WordPress-Themes und der WordPress Font Library.
- Die App kann dadurch das Corporate Design der jeweiligen WordPress-Installation direkt verwenden.

## 2.40.0

- Die Schnellbearbeitung unterstützt Startdatum, Enddatum und weitere Terminoptionen zuverlässig.

## 2.37.0

- Der Kalenderimport verarbeitet standardkonforme, gefaltete Google-iCal-Zeilen zuverlässig.
- Termine ohne gültiges Startdatum werden beim Abgleich sicher behandelt.

## 2.36.0

- Mehrere Termine können gemeinsam einer Gruppe zugeordnet oder aus einer Gruppe entfernt werden.
- Mehrere Termine können gemeinsam auf die Blacklist gesetzt oder wieder freigegeben werden.

## 2.35.0

- Blacklisting mit eigenem Backend-Tab, Einzelaktionen und wiederverwendbaren Titel-Regeln ergänzt.
- Geblacklistete Termine bleiben im Backend verwaltbar und erscheinen nicht im Frontend.

## 2.34.0

- Einheitliches JSON-Transferformat für Einstellungen, Termine inklusive Meta-Daten, Nachrichten, Infos, Personen, Marschordnungen, Gruppen, Kalenderquellen und Blacklist-Daten ergänzt.
- Private iCal-Adressen können ausdrücklich als sensibler Bestandteil einbezogen werden.

## 2.32.0

- Termine können als „Vereinsintern“ gekennzeichnet werden.
- Der Hinweis erscheint in Termin-Cards und Detailansichten.

## 2.31.0

- Termine unterstützen Startdatum, Enddatum und Ganztagesstatus.
- Termine können gezielt von Sammelkarten ausgeschlossen werden.
- Gruppen können bei Sammelkarten priorisiert werden.
- iCal-Termine mit einer Dauer von mehr als sieben Kalendertagen werden für eine saubere Kalenderdarstellung berücksichtigt.

## 2.30.0

- Die Anmeldung und Abmeldung verwendet WordPress-Benutzerkonten und die Standard-Anmeldeseite.
- Die öffentliche App bleibt ohne Anmeldung nutzbar; geschützte Inhalte werden nach der Anmeldung angezeigt.

## 2.29.0

- Geschützte Kalenderquellen können einzelnen vorhandenen WordPress-Benutzern freigegeben werden.
- Administratoren und eingeschränkte Benutzer werden entsprechend ihrer WordPress-Berechtigungen behandelt.

## 2.27.2

- Kalenderquellen unterstützen feste Sichtbarkeiten für öffentliche, interne und berechtigte Inhalte.

## 2.26.11

- Beschreibungen aus dem iCal-Feld `DESCRIPTION` werden als Terminnotizen übernommen.

## 2.26.8

- Termin-Metadaten und Kalenderwochen verwenden konsistente, einstellbare Designfarben.

## 2.26.6

- Tageskarten bündeln passende Ganztagstermine übersichtlich mit den zeitlich definierten Terminen des Tages.

## 2.24.0

- Kopfzeile, Vereinslogo, Titel und Untertitel der App können im Backend gepflegt werden.
- WordPress-Site-Icon und geprüfte Vereinslogos werden für die App-Darstellung verwendet.

## 2.23.0

- Nachrichten und Infos können einzeln in der unteren App-Navigation ein- oder ausgeblendet werden.

## 2.22.0

- Die App kann auf jeder WordPress-Seite mit dem Shortcode `[schuetzen_app]` als eigenständige Vollbild-App eingesetzt werden.

## 2.21.5

- Web-App-Manifest und App-Symbole werden aus der jeweiligen WordPress-Installation erzeugt.

## 2.17.0

- Gruppen, Farben und Kalenderquellen können frei verwaltet werden.
- iCalendar-Feeds werden automatisch und manuell synchronisiert und über stabile Kalenderkennungen aktuell gehalten.
- Importierte Termine können je Kalenderquelle als Entwurf oder automatisch veröffentlicht angelegt werden.

## 2.15.5

- Kalenderwochen werden nach dem ISO-Standard dargestellt.

## Frühere produktive Grundlagen

- Termine, Nachrichten, Infos, Personen und Marschordnungen werden als eigene WordPress-Inhalte verwaltet.
- Termine können Gruppen, Bildern, Orten, Treffpunkten und Marschordnungen zugeordnet werden.
- Die responsive PWA-Oberfläche bietet Terminübersicht, Detailansichten, Nachrichten, Infos und eine mobile Navigation.
- App-Farben, Gruppenfarben, Logo und zentrale Designelemente können ohne Theme-Anpassungen im Backend gepflegt werden.
- Kleine Fehlerkorrekturen und Verbesserungen an Import, Darstellung, Cache-Verhalten und mobiler Bedienung werden fortlaufend eingearbeitet.
