<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_REST {
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			'schuetzen-app/v1',
			'/content',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_content' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function get_content() {
		$event_data   = $this->get_entries( 'schuetzen_event', true );
		$message_data = $this->get_entries( 'schuetzen_message' );
		$info_data    = $this->get_entries( 'schuetzen_info' );

		return rest_ensure_response(
			array(
				'app_name' => get_bloginfo( 'name' ),
				'app_description' => get_bloginfo( 'description' ),
				'events'   => $event_data,
				'messages' => $message_data,
				'info'     => $info_data,
			)
		);
	}

	private function get_entries( $post_type, $events = false ) {
		$query_args = array(
			'post_type'      => $post_type,
			'post_status'    => 'publish',
			'posts_per_page' => $events ? 50 : 20,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( $events ) {
			$query_args['orderby']  = 'meta_value';
			$query_args['meta_key'] = '_schuetzen_event_date';
			$query_args['order']    = 'ASC';
			$query_args['meta_query'] = array(
				array(
					'key'     => '_schuetzen_event_date',
					'value'   => current_time( 'Y-m-d' ),
					'compare' => '>=',
					'type'    => 'DATE',
				),
			);
		}

		$posts = get_posts( $query_args );

		return array_map(
			function ( $post ) use ( $events, $post_type ) {
				$data = array(
					'id'          => $post->ID,
					'title'       => get_the_title( $post ),
					'date'        => get_the_date( 'Y-m-d', $post ),
					'description' => wpautop( wp_kses_post( $post->post_content ) ),
					'image'       => get_the_post_thumbnail_url( $post, 'large' ) ?: '',
					'category'    => $post_type === 'schuetzen_info' ? get_post_meta( $post->ID, '_schuetzen_info_category', true ) : '',
				);

				if ( $events ) {
					$data['date']     = get_post_meta( $post->ID, '_schuetzen_event_date', true );
					$data['time']     = get_post_meta( $post->ID, '_schuetzen_event_time', true );
					$data['location'] = get_post_meta( $post->ID, '_schuetzen_event_location', true );
					$data['meeting_point'] = get_post_meta( $post->ID, '_schuetzen_event_meeting_point', true );
					$data['category'] = get_post_meta( $post->ID, '_schuetzen_event_category', true );
					$data['march_order'] = $this->get_march_order( get_post_meta( $post->ID, '_schuetzen_event_march_order', true ) );
				}

				return $data;
			},
			$posts
		);
	}

	private function get_march_order( $order_id ) {
		$order_id = absint( $order_id );
		if ( ! $order_id || 'schuetzen_march' !== get_post_type( $order_id ) ) {
			return null;
		}

		$blocks = get_post_meta( $order_id, '_schuetzen_march_order_blocks', true );
		if ( ! is_array( $blocks ) || ! $blocks ) {
			$legacy_rows = get_post_meta( $order_id, '_schuetzen_march_order_rows', true );
			$blocks      = is_array( $legacy_rows ) && $legacy_rows ? array( $legacy_rows ) : array();
		}
		$blocks = array_slice( $blocks, 0, 5 );
		$data = array(
			'id'    => $order_id,
			'title' => get_the_title( $order_id ),
			'blocks' => array(),
		);

		foreach ( $blocks as $block ) {
			$clean_rows = array();
			foreach ( $block as $row ) {
				$people = array();
				foreach ( array_slice( (array) $row, 0, 3 ) as $person_id ) {
					$person_id = absint( $person_id );
					if ( ! $person_id || 'schuetzen_person' !== get_post_type( $person_id ) ) {
						$people[] = null;
						continue;
					}
					$people[] = array(
						'id'    => $person_id,
						'name'  => get_the_title( $person_id ),
						'role'  => get_post_meta( $person_id, '_schuetzen_person_role', true ),
						'image' => get_the_post_thumbnail_url( $person_id, 'thumbnail' ) ?: '',
					);
				}
				if ( array_filter( $people ) ) {
					$clean_rows[] = $people;
				}
			}
			$data['blocks'][] = $clean_rows;
		}

		while ( $data['blocks'] && ! end( $data['blocks'] ) ) {
			array_pop( $data['blocks'] );
		}

		return $data;
	}
}
