<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_REST {
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			'schuetzen-app/v1',
			'/content',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_content' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function get_content() {
		$event_data   = $this->get_entries( 'schuetzen_event', true );
		$message_data = $this->get_entries( 'schuetzen_message' );
		$info_data    = $this->get_entries( 'schuetzen_info' );

		return rest_ensure_response(
			array(
				'app_name' => get_bloginfo( 'name' ),
				'app_description' => get_bloginfo( 'description' ),
				'groups'   => Schuetzen_App_Groups::get(),
				'calendar_sources' => $this->get_calendar_sources(),
				'events'   => $event_data,
				'messages' => $message_data,
				'info'     => $info_data,
			)
		);
	}

	private function get_calendar_sources() {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$sources  = Schuetzen_App_Calendar_Sources::sanitize_sources( is_array( $settings ) ? ( $settings['calendar_sources'] ?? array() ) : array() );
		$primary_group = Schuetzen_App_Groups::primary_id();
		$always_visible_groups = array( $primary_group );
		foreach ( Schuetzen_App_Groups::get() as $group ) {
			if ( ! empty( $group['always_visible'] ) ) {
				$always_visible_groups[] = $group['id'];
			}
		}
		$result   = array();
		foreach ( $sources as $source ) {
			if ( empty( $source['active'] ) ) {
				continue;
			}
			$result[] = array(
				'id'    => $source['id'],
				'name'  => $source['name'],
				'group' => $source['group'],
				'always_visible' => in_array( $source['group'], $always_visible_groups, true ),
			);
		}
		return $result;
	}

	private function get_entries( $post_type, $events = false ) {
		$query_args = array(
			'post_type'      => $post_type,
			'post_status'    => 'publish',
			'posts_per_page' => $events ? -1 : 20,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( $events ) {
			$query_args['orderby']  = 'meta_value';
			$query_args['meta_key'] = '_schuetzen_event_date';
			$query_args['order']    = 'ASC';
			$query_args['meta_query'] = array(
				'relation' => 'OR',
				array(
					'key'     => '_schuetzen_event_date',
					'value'   => current_time( 'Y-m-d' ),
					'compare' => '>=',
					'type'    => 'DATE',
				),
				array(
					'key'     => '_schuetzen_event_end_date',
					'value'   => current_time( 'Y-m-d' ),
					'compare' => '>=',
					'type'    => 'DATE',
				),
			);
		}

		$posts = get_posts( $query_args );

		return array_map(
			function ( $post ) use ( $events, $post_type ) {
				$local_description = wpautop( wp_kses_post( $post->post_content ) );
				$data = array(
					'id'          => $post->ID,
					'title'       => get_the_title( $post ),
					'date'        => get_the_date( 'Y-m-d', $post ),
					'description' => $local_description,
					'image'       => get_the_post_thumbnail_url( $post, 'large' ) ?: '',
					'category'    => $post_type === 'schuetzen_info' ? get_post_meta( $post->ID, '_schuetzen_info_category', true ) : ( $post_type === 'schuetzen_message' ? get_post_meta( $post->ID, '_schuetzen_message_category', true ) : '' ),
					'pdf'         => $post_type === 'schuetzen_info' ? ( wp_get_attachment_url( get_post_meta( $post->ID, '_schuetzen_info_pdf', true ) ) ?: '' ) : '',
				);

				if ( $events ) {
					$data['date']     = get_post_meta( $post->ID, '_schuetzen_event_date', true );
					$data['time']     = get_post_meta( $post->ID, '_schuetzen_event_time', true );
					$data['time_approx'] = '1' === get_post_meta( $post->ID, '_schuetzen_event_time_approx', true );
					$data['time_after'] = '1' === get_post_meta( $post->ID, '_schuetzen_event_time_after', true );
					$data['time_after_text'] = get_post_meta( $post->ID, '_schuetzen_event_time_after_text', true );
					$data['location'] = get_post_meta( $post->ID, '_schuetzen_event_location', true );
					$data['meeting_point'] = get_post_meta( $post->ID, '_schuetzen_event_meeting_point', true );
					$data['category'] = get_post_meta( $post->ID, '_schuetzen_event_category', true );
					$data['all_day'] = '1' === get_post_meta( $post->ID, '_schuetzen_event_all_day', true );
					$data['end_date'] = get_post_meta( $post->ID, '_schuetzen_event_end_date', true );
					$data['source_name'] = get_post_meta( $post->ID, '_schuetzen_event_source_name', true );
					$data['source_id'] = get_post_meta( $post->ID, '_schuetzen_event_source_id', true );
					$data['external'] = '' !== $data['source_id'];
					$source_description = wpautop( wp_kses_post( get_post_meta( $post->ID, '_schuetzen_event_source_description', true ) ) );
					$data['description'] = $source_description . $local_description;
					$data['march_order'] = $this->get_march_order( get_post_meta( $post->ID, '_schuetzen_event_march_order', true ) );
				}

				return $data;
			},
			$posts
		);
	}

	private function get_march_order( $order_id ) {
		$order_id = absint( $order_id );
		if ( ! $order_id || 'schuetzen_march' !== get_post_type( $order_id ) ) {
			return null;
		}

		$blocks = get_post_meta( $order_id, '_schuetzen_march_order_blocks', true );
		if ( ! is_array( $blocks ) || ! $blocks ) {
			$legacy_rows = get_post_meta( $order_id, '_schuetzen_march_order_rows', true );
			$blocks      = is_array( $legacy_rows ) && $legacy_rows ? array( $legacy_rows ) : array();
		}
		$blocks = array_slice( $blocks, 0, 5 );
		$data = array(
			'id'    => $order_id,
			'title' => get_the_title( $order_id ),
			'blocks' => array(),
		);

		if ( 'wolke' === strtolower( trim( $data['title'] ) ) ) {
			$all_people = get_posts(
				array(
					'post_type'      => 'schuetzen_person',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'orderby'        => 'title',
					'order'          => 'ASC',
				)
			);
			$rows = array();
			foreach ( array_chunk( $all_people, 3 ) as $people_chunk ) {
				$row = array();
				foreach ( $people_chunk as $person ) {
					$row[] = array(
						'id'    => $person->ID,
						'name'  => get_the_title( $person ),
						'role'  => get_post_meta( $person->ID, '_schuetzen_person_role', true ),
						'image' => get_the_post_thumbnail_url( $person->ID, 'thumbnail' ) ?: '',
					);
				}
				$rows[] = $row;
			}
			$data['blocks'] = $rows ? array( $rows ) : array();
			return $data;
		}

		foreach ( $blocks as $block ) {
			$clean_rows = array();
			foreach ( $block as $row ) {
				$people = array();
				foreach ( array_slice( (array) $row, 0, 3 ) as $person_id ) {
					$person_id = absint( $person_id );
					if ( ! $person_id || 'schuetzen_person' !== get_post_type( $person_id ) ) {
						$people[] = null;
						continue;
					}
					$people[] = array(
						'id'    => $person_id,
						'name'  => get_the_title( $person_id ),
						'role'  => get_post_meta( $person_id, '_schuetzen_person_role', true ),
						'image' => get_the_post_thumbnail_url( $person_id, 'thumbnail' ) ?: '',
					);
				}
				if ( array_filter( $people ) ) {
					$clean_rows[] = $people;
				}
			}
			$data['blocks'][] = $clean_rows;
		}

		while ( $data['blocks'] && ! end( $data['blocks'] ) ) {
			array_pop( $data['blocks'] );
		}

		return $data;
	}
}
