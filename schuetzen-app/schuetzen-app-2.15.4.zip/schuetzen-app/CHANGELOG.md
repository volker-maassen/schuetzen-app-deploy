# Änderungsprotokoll

## 2.15.4

- Bereits installierte Versionen werden nicht mehr durch einen veralteten Update-Transient erneut angeboten.
- Der Übergang vom bisherigen Updater auf die korrigierte Cache-Behandlung funktioniert nach einem einzigen Update.

## 2.15.3

- Der WordPress-Update-Cache wird nach einer Aktualisierung erst am Ende des Requests geleert.
- Die Cache-Bereinigung reagiert nur noch auf Aktualisierungen der Schützen-App.
- Das erneute Angebot derselben Plugin-Version direkt nach einer erfolgreichen Aktualisierung wurde behoben.

## 2.2.1

- Die Terminabfrage auf 50 Einträge erhöht, damit umfangreiche Schützenfest-Tagesprogramme vollständig angezeigt werden.

## 2.2.0

- Zug-, Korps- und Regimentsfarben im App-Panel einstellbar gemacht.
- Termine können einer Gruppe zugeordnet werden.
- Der linke Rand der Termin-Card übernimmt die Farbe der zugeordneten Gruppe.
- Antretezeiten aus dem Majorsbefehl 2026 als Terminvorschläge dokumentiert.

## 2.1.0

- Marschordnungen um fünf separat pflegbare Marschblöcke mit jeweils bis zu 20 dreireihigen Zeilen erweitert.
- Bestehende Marschordnungen werden automatisch als erster Marschblock weiterverwendet.
- Marschblock-Bezeichnungen werden im Frontend nur angezeigt, wenn mehr als ein Block befüllt ist.

## 2.0.2

- Personenbilder und Fallback-Icons auf 4rem vergrößert.
- Titel der Marschordnung zentriert.
- Dezenter Schatten für Personenbilder und Fallback-Icons ergänzt.

## 2.0.1

- Interne Bezeichnung des Inhaltstyps gekürzt, damit der WordPress-Menüpunkt Marschordnungen korrekt registriert wird.

## 2.0.0

- Personen als eigene Inhalte mit optionalem Portraitbild und Rolle ergänzt.
- Marschordnungen als eigene Inhalte mit flexiblen Ein-, Zwei- und Dreierreihen ergänzt.
- Marschordnungen können direkt einem Termin zugeordnet und auf der Detailseite angezeigt werden.
- Personen ohne Portraitbild erhalten automatisch ein neutrales Personen-Icon.

## 1.9.5

- HTML-Entities in manuellen Termin-, Nachrichten- und Info-Texten werden vor der Ausgabe korrekt dekodiert.

## 1.9.4

- Header-Schatten dauerhaft sichtbar gemacht.

## 1.9.3

- Header-Schatten an den Footer-Schatten angeglichen.
- Update-Abfrage mit Cache-Busting für `update.json` versehen.
- WordPress-Update-Transient nach Plugin-Aktualisierung gelöscht.

## 1.9.2

- Rahmenlinie der unteren App-Navigation entfernt.

## 1.9.1

- Oberen Abstand der Hero-Zone auf 1,2rem erhöht.

## 1.9.0

- Hintergrundfarbe des Headers im Plugin-Backend einstellbar gemacht.
- Hintergrundfarbe des Footer-Menüs im Plugin-Backend einstellbar gemacht.

## 1.8.2

- Header wieder auf die ursprüngliche App-Breite zurückgeführt.
- Nur die unteren Ecken mit dem Radius des Footer-Menüs abgerundet.
- Icon und Schriftzug im Header mit zusätzlichem Innenabstand versehen.

## 1.8.1

- Header auf die gesamte App-Breite ausgedehnt.
- Schatten auf die Unterkante des Headers begrenzt.

## 1.8.0

- Kopfzeile bleibt beim Scrollen sichtbar.
- Dezenter Schatten erscheint nur beim Scrollen nach oben.

## 1.7.3

- Aktive Markierung der Info-Filter beim Wechsel in den Bereich Infos korrigiert.

## 1.7.2

- Der aktive Info-Filter wird beim Öffnen jetzt auch tatsächlich angewendet.
- Beim Wechsel in den Bereich Infos startet die Ansicht standardmäßig mit der Kategorie Zug.

## 1.7.1

- Info-Filter in der Reihenfolge Zug, Korps, Regiment und Alle angeordnet.
- Zug ist beim Öffnen standardmäßig aktiv.

## 1.7.0

- Zweizeilige Kopfzeile im Plugin-Backend einstellbar gemacht.
- Website-Icon, Website-Titel und Untertitel werden aus den WordPress-Allgemeinen Einstellungen übernommen.

## 1.6.1

- Termine werden ausschließlich aus `.ics`-Anhängen importiert.
- Normale Text-Mails ohne Kalenderdatei werden als Termin-Mail übersprungen.

## 1.6.0

- iCalendar-Dateien (`.ics`) aus Termin-Mails werden importiert.
- Bestehende Termine werden über ihre Kalender-UID aktualisiert statt dupliziert.
- Titel, Beschreibung, Beginn, Ende und Ort werden aus dem iCalendar übernommen.

## 1.5.4

- Verschachtelte Outlook-MIME-Mails werden jetzt korrekt ausgelesen.
- HTML- und Textteile werden auch innerhalb von `multipart/alternative` erkannt.

## 1.5.3

- MIME- und Base64-Inhalte aus Outlook-Mails werden korrekt aufgelöst.
- HTML-Mailinhalt wird nicht mehr als Rohdaten in den Beitrag übernommen.

## 1.5.2

- HTML-Mailtexte aus Outlook werden vor der Erkennung von Terminangaben bereinigt.
- Datum, Uhrzeit und Ort werden dadurch auch aus HTML-Mails übernommen.

## 1.5.1

- Mailtest vom Einstellungsformular getrennt.
- „Änderungen speichern“ sendet wieder korrekt an WordPress.

## 1.5.0

- Manuellen Mailimport-Testlauf ergänzt.
- Importstatus und Fehlerprotokoll im Admin-Panel ergänzt.

## 1.4.0

- Erstes Bild aus einem Mailanhang als Beitragsbild übernommen.
- Bildanhänge über der eingestellten Maximalgröße verworfen.
- Info-Kategorie aus der Mailzeile `Kategorie` übernommen.

## 1.3.0

- Separate IMAP-Benutzer und Passwörter für Termine, Nachrichten und Infos ergänzt.
- Mailimport auf drei getrennte Postfächer umgestellt.

## 1.2.1

- Mailstruktur-Dokumentation im Admin-Panel ergänzt.
- Einstellbare maximale Bildgröße für Mailanhänge ergänzt.

## 1.2.0

- IMAP-Mailimport für Termine, Nachrichten und Infos ergänzt.
- Absender-Whitelist und Betreff-/Textübernahme integriert.
- Terminangaben aus Mailzeilen `Datum`, `Uhrzeit` und `Ort` werden übernommen.

## 1.1.1

- Unterschiedliche Standardwerte für die App-Farben im Admin-Panel ergänzt.

## 1.1.0

- Administrationspanel für Mailadressen, Absender-Whitelist und App-Farben ergänzt.
- Einstellbare Farben werden im Frontend als CSS-Variablen verwendet.

## 1.0.3

- Abgelaufene Termine zusätzlich direkt in der App ausgeblendet.
- REST-Inhalte werden nicht mehr aus dem Service-Worker-Cache geladen.

## 1.0.2

- Orts-Icon bei mehrzeiligem Umbruch oben an der ersten Textzeile ausgerichtet.

## 1.0.1

- Loader beim manuellen Aktualisieren verbessert.
- Aktueller Bereich und geöffnete Detailansicht bleiben nach dem Aktualisieren erhalten.

## 1.0.0

- Manuelles Aktualisieren durch Wischen nach unten ergänzt.
- Loader während des Datenabrufs ergänzt.
- Automatische Intervallabfrage entfernt.

## 0.9.5

- Inhalte werden während der geöffneten App automatisch alle 30 Sekunden aktualisiert.

## 0.9.4

- Inhalte werden bei Aktualisierung und beim Zurückkehren zur App frisch geladen.
- API-Abruf für aktuelle Nachrichten und Infos vom Browser-Cache ausgenommen.

## 0.9.3

- Info-Kategorien korrekt an die App-API übergeben.

## 0.9.2

- Info-Filter bei Terminen und Nachrichten zuverlässig ausgeblendet.

## 0.9.1

- Kategorie-Buttons nur noch im Tab „Infos“ sichtbar.
- Beschreibungstexte aus Termin- und Info-Cards entfernt.
- Nachrichten behalten eine kurze Einleitung.

## 0.9.0

- Info-Kategorien Regiment, Korps und Zug im Backend ergänzt.
- Filterleiste mit Alle, Regiment, Korps und Zug ergänzt.
- Info-Übersicht zeigt nur noch die Überschriften.

## 0.8.2

- Datumsangaben bei Nachrichten und Infos entfernt.
- Überschriften in Cards und Detailansicht bündig ausgerichtet.

## 0.8.1

- Uhrzeit und Ort in Termin-Cards getrennt dargestellt.
- Lokale Uhr- und Orts-Icons ergänzt.
- Uhrzeit um „Uhr“ ergänzt.

## 0.8.0

- Lokale SVG-Icons für Termine, Nachrichten und Infos ergänzt.
- Navigation auf scharfe, farbsteuerbare Icons umgestellt.

## 0.7.2

- Hintergrundbilder aus den Cards entfernt und ausschließlich in den Datums-Badges dargestellt.
- `--schuetzen-green-dark` als 60%-Overlay für Badges und Detailansicht ergänzt.

## 0.7.1

- Bilddarstellung in Cards und Detailansicht korrigiert.
- Detailansicht nutzt jetzt den Tab „Termine“ als Rückkehr zur Terminübersicht.

## 0.7.0

- Beitragsbilder für Termine, Nachrichten und Infos ergänzt.
- Klickbare Cards mit Detailansicht und Hintergrundbild ergänzt.
- Kurztexte nach 50 Zeichen gekürzt.

## 0.6.2

- Vergangene Termine werden ab dem Folgetag ausgeblendet.
- Termin-Cards mit Datumsblock und Wochenüberschriften gestaltet.

## 0.6.1

- Hochformat als bevorzugte App-Ausrichtung festgelegt.
- Hinweis bei mobiler Querformat-Nutzung ergänzt.

## 0.6.0

- App-Optik mit kompakter Kopfzeile, Vereinsabzeichen und unterer Navigation überarbeitet.
- Kartenlayout und mobile App-Anmutung verbessert.

## 0.5.0

- Vereinsabzeichen als PWA-App-Icons ergänzt.
- Apple-Startbildschirm-Metadaten ergänzt.
- Root-Service-Worker mit Offline-Cache ergänzt.

## 0.4.0

- Eigenständige App-Seite ohne WordPress-Theme-Rahmen ergänzt.

## 0.3.1

- Datumsanzeige im Format „Wochentag, dd. Monat JJJJ“ ergänzt.

## 0.3.0

- Backend-Bereiche für Termine, Nachrichten und Infos ergänzt.
- Navigation zwischen den Inhaltsbereichen ergänzt.

## 0.2.0

- PWA-Grundgerüst, responsive Frontend-Oberfläche und REST-Endpunkt ergänzt.

## 0.1.0

- Erste Plugin-Grundversion mit eigener Update-Anbindung.
