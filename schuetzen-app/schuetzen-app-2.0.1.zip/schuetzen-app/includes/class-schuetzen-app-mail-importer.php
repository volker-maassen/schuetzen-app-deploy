<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Mail_Importer {
	public function __construct() {
		add_filter( 'cron_schedules', array( $this, 'add_schedule' ) );
		add_action( 'schuetzen_app_import_mail', array( $this, 'import_mail' ) );
		add_action( 'admin_post_schuetzen_app_import_now', array( $this, 'manual_import' ) );
		if ( ! wp_next_scheduled( 'schuetzen_app_import_mail' ) ) {
			wp_schedule_event( time() + 60, 'schuetzen_app_five_minutes', 'schuetzen_app_import_mail' );
		}
	}

	public function add_schedule( $schedules ) {
		$schedules['schuetzen_app_five_minutes'] = array( 'interval' => 300, 'display' => 'Alle fünf Minuten' );
		return $schedules;
	}

	public function import_mail() {
		if ( ! function_exists( 'imap_open' ) ) {
			$this->log( 'Fehler: PHP-IMAP ist auf dem Server nicht aktiviert.' );
			return;
		}
		$settings = get_option( 'schuetzen_app_settings', array() );
		$host     = $settings['imap_host'] ?? '';
		$port     = absint( $settings['imap_port'] ?? 993 );
		if ( ! $host ) {
			$this->log( 'Fehler: IMAP-Mailserver fehlt.' );
			return;
		}
		foreach ( array( 'events' => 'schuetzen_event', 'messages' => 'schuetzen_message', 'info' => 'schuetzen_info' ) as $mail_key => $post_type ) {
			$user = $settings[ 'imap_' . $mail_key . '_user' ] ?? '';
			$password = $settings[ 'imap_' . $mail_key . '_password' ] ?? '';
			if ( $user && $password ) {
				$this->import_mailbox( $settings, $host, $port, $user, $password, $post_type );
			} else {
				$this->log( 'Übersprungen: IMAP-Zugang für ' . $mail_key . ' fehlt.' );
			}
		}
	}

	public function manual_import() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'schuetzen_app_import_now' ) ) {
			wp_die( 'Nicht autorisiert.' );
		}
		$this->import_mail();
		wp_safe_redirect( add_query_arg( array( 'page' => 'schuetzen-app', 'schuetzen_app_imported' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private function import_mailbox( $settings, $host, $port, $user, $password, $target_post_type ) {
		$mailbox = sprintf( '{%s:%d/imap/ssl/novalidate-cert}INBOX', $host, $port );
		$connection = @imap_open( $mailbox, $user, $password );
		if ( ! $connection ) {
			$this->log( 'Fehler: IMAP-Anmeldung für ' . $target_post_type . ' fehlgeschlagen.' );
			return;
		}
		$allowed = array_filter( array_map( 'sanitize_email', preg_split( '/\r\n|\r|\n/', $settings['whitelist'] ?? '' ) ) );
		$messages = imap_search( $connection, 'UNSEEN' ) ?: array();
		$this->log( count( $messages ) . ' ungelesene Mail(s) in ' . $target_post_type . ' gefunden.' );
		foreach ( $messages as $message_number ) {
			$overview = imap_fetch_overview( $connection, $message_number, 0 );
			$overview = $overview[0] ?? null;
			$from     = $overview ? strtolower( (string) preg_replace( '/.*<([^>]+)>/', '$1', $overview->from ) ) : '';
			if ( ! in_array( $from, array_map( 'strtolower', $allowed ), true ) ) {
				imap_setflag_full( $connection, (string) $message_number, '\\Seen' );
				continue;
			}
			$to      = strtolower( (string) ( $overview->to ?? '' ) );
			$subject = sanitize_text_field( $this->decode_header( $overview->subject ?? '' ) );
			if ( 'schuetzen_event' === $target_post_type ) {
				$ics = $this->get_ics_attachment( $connection, $message_number );
				if ( false !== $ics ) {
					$post_id = $this->import_ics_event( $ics['body'] );
					if ( $post_id && ! is_wp_error( $post_id ) ) {
						$this->attach_first_image( $connection, $message_number, $post_id, $settings );
						$this->log( 'ICS-Termin importiert: ' . get_the_title( $post_id ) );
					}
					imap_setflag_full( $connection, (string) $message_number, '\\Seen' );
					continue;
				}
				$this->log( 'Termin-Mail ohne ICS-Anhang übersprungen: ' . ( $subject ?: '(ohne Betreff)' ) );
				imap_setflag_full( $connection, (string) $message_number, '\\Seen' );
				continue;
			}
			$body    = $this->get_body( $connection, $message_number );
			if ( $target_post_type ) {
				$post_id = wp_insert_post( array( 'post_type' => $target_post_type, 'post_status' => 'publish', 'post_title' => $subject ?: 'Neue Nachricht', 'post_content' => wp_kses_post( $this->clean_body( $body ) ) ), true );
				if ( ! is_wp_error( $post_id ) && 'schuetzen_event' === $target_post_type ) {
					$this->save_event_fields( $post_id, $body );
				}
				if ( ! is_wp_error( $post_id ) && 'schuetzen_info' === $target_post_type ) {
					$this->save_info_category( $post_id, $body );
				}
				if ( ! is_wp_error( $post_id ) ) {
					$this->attach_first_image( $connection, $message_number, $post_id, $settings );
				}
			}
			imap_setflag_full( $connection, (string) $message_number, '\\Seen' );
		}
		imap_close( $connection );
	}

	private function log( $message ) {
		$log = get_option( 'schuetzen_app_import_log', array() );
		array_unshift( $log, current_time( 'd.m.Y H:i:s' ) . ' – ' . $message );
		update_option( 'schuetzen_app_import_log', array_slice( $log, 0, 20 ), false );
	}

	private function decode_header( $value ) {
		$parts = imap_mime_header_decode( (string) $value );
		return implode( '', array_map( static function ( $part ) { return $part->text; }, $parts ) );
	}

	private function get_body( $connection, $message_number ) {
		$structure = imap_fetchstructure( $connection, $message_number );
		foreach ( array( 'HTML', 'PLAIN' ) as $subtype ) {
			$body = $this->find_text_part( $connection, $message_number, $structure, $subtype );
			if ( false !== $body ) {
				return $body;
			}
		}
		return $this->decode_part( imap_body( $connection, $message_number, FT_PEEK ), $structure->encoding ?? 0 );
	}

	private function find_text_part( $connection, $message_number, $part, $subtype, $section = '' ) {
		if ( 'TEXT' === strtoupper( $part->type ?? '' ) && $subtype === strtoupper( $part->subtype ?? '' ) && $section ) {
			return $this->decode_part( imap_fetchbody( $connection, $message_number, $section ), $part->encoding ?? 0 );
		}
		foreach ( $part->parts ?? array() as $index => $child ) {
			$child_section = $section ? $section . '.' . ( $index + 1 ) : (string) ( $index + 1 );
			$body = $this->find_text_part( $connection, $message_number, $child, $subtype, $child_section );
			if ( false !== $body ) {
				return $body;
			}
		}
		return false;
	}

	private function decode_part( $body, $encoding ) {
		if ( 3 === (int) $encoding ) {
			return base64_decode( $body, true ) ?: '';
		}
		if ( 4 === (int) $encoding ) {
			return quoted_printable_decode( $body );
		}
		return $body;
	}

	private function get_ics_attachment( $connection, $message_number ) {
		$structure = imap_fetchstructure( $connection, $message_number );
		if ( empty( $structure ) ) {
			return false;
		}
		return $this->find_ics_part( $connection, $message_number, $structure );
	}

	private function find_ics_part( $connection, $message_number, $part, $section = '' ) {
		$filename = '';
		foreach ( array( 'dparameters', 'parameters' ) as $parameter_group ) {
			foreach ( $part->$parameter_group ?? array() as $parameter ) {
				if ( in_array( strtoupper( $parameter->attribute ?? '' ), array( 'FILENAME', 'NAME' ), true ) ) {
					$filename = $this->decode_header( $parameter->value ?? '' );
				}
			}
		}
		$is_ics = preg_match( '/\.ics$/i', $filename ) || 'CALENDAR' === strtoupper( $part->subtype ?? '' );
		if ( $is_ics && $section ) {
			return array(
				'filename' => $filename ?: 'calendar.ics',
				'body'     => $this->decode_part( imap_fetchbody( $connection, $message_number, $section ), $part->encoding ?? 0 ),
			);
		}
		foreach ( $part->parts ?? array() as $index => $child ) {
			$child_section = $section ? $section . '.' . ( $index + 1 ) : (string) ( $index + 1 );
			$attachment = $this->find_ics_part( $connection, $message_number, $child, $child_section );
			if ( false !== $attachment ) {
				return $attachment;
			}
		}
		return false;
	}

	private function import_ics_event( $ics ) {
		$fields = $this->parse_ics( $ics );
		if ( empty( $fields['uid'] ) || empty( $fields['title'] ) || empty( $fields['start'] ) ) {
			$this->log( 'ICS übersprungen: UID, Titel oder Beginn fehlt.' );
			return false;
		}
		$existing = get_posts( array( 'post_type' => 'schuetzen_event', 'post_status' => 'any', 'meta_key' => '_schuetzen_event_uid', 'meta_value' => $fields['uid'], 'posts_per_page' => 1, 'fields' => 'ids' ) );
		$post_data = array( 'post_type' => 'schuetzen_event', 'post_status' => 'publish', 'post_title' => $fields['title'], 'post_content' => wp_kses_post( $fields['description'] ?? '' ) );
		if ( ! empty( $existing[0] ) ) {
			$post_data['ID'] = (int) $existing[0];
			$post_id = wp_update_post( $post_data, true );
		} else {
			$post_id = wp_insert_post( $post_data, true );
		}
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}
		update_post_meta( $post_id, '_schuetzen_event_uid', $fields['uid'] );
		update_post_meta( $post_id, '_schuetzen_event_date', $fields['date'] );
		update_post_meta( $post_id, '_schuetzen_event_time', $fields['time'] );
		update_post_meta( $post_id, '_schuetzen_event_end', $fields['end'] );
		update_post_meta( $post_id, '_schuetzen_event_location', $fields['location'] );
		return $post_id;
	}

	private function parse_ics( $ics ) {
		$lines = preg_split( "/\r\n|\n|\r/", (string) $ics );
		$unfolded = array();
		foreach ( $lines as $line ) {
			if ( isset( $line[0] ) && in_array( $line[0], array( ' ', "\t" ), true ) && ! empty( $unfolded ) ) {
				$unfolded[ count( $unfolded ) - 1 ] .= ltrim( $line );
			} else {
				$unfolded[] = $line;
			}
		}
		$values = array();
		$inside_event = false;
		foreach ( $unfolded as $line ) {
			if ( 'BEGIN:VEVENT' === strtoupper( trim( $line ) ) ) {
				$inside_event = true;
				continue;
			}
			if ( 'END:VEVENT' === strtoupper( trim( $line ) ) ) {
				break;
			}
			if ( ! $inside_event || ! preg_match( '/^([A-Z][A-Z0-9-]*)(?:;[^:]*)?:(.*)$/i', $line, $match ) ) {
				continue;
			}
			$values[ strtoupper( $match[1] ) ] = $this->unescape_ics( trim( $match[2] ) );
		}
		$start = $this->parse_ics_date( $values['DTSTART'] ?? '' );
		return array( 'uid' => $values['UID'] ?? '', 'title' => $values['SUMMARY'] ?? '', 'description' => $values['DESCRIPTION'] ?? '', 'date' => $start['date'], 'time' => $start['time'], 'end' => $this->parse_ics_date( $values['DTEND'] ?? '' )['value'], 'location' => $values['LOCATION'] ?? '', 'start' => $start['value'] );
	}

	private function parse_ics_date( $value ) {
		if ( ! preg_match( '/^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2}))?/', (string) $value, $match ) ) {
			return array( 'value' => '', 'date' => '', 'time' => '' );
		}
		$date = $match[1] . '-' . $match[2] . '-' . $match[3];
		$time = isset( $match[4] ) ? $match[4] . ':' . $match[5] : '';
		return array( 'value' => $date . ( $time ? ' ' . $time : '' ), 'date' => $date, 'time' => $time );
	}

	private function unescape_ics( $value ) {
		return str_replace( array( '\\\\n', '\\\\N', '\\\\,', '\\\\;', '\\\\\\\\' ), array( "\n", "\n", ',', ';', '\\' ), $value );
	}

	private function clean_body( $body ) {
		$body = $this->plain_text( $body );
		$body = preg_replace( '/^(Datum|Uhrzeit|Ort|Kategorie):.*$/mi', '', $body );
		return trim( preg_replace( "/\n{3,}/", "\n\n", $body ) );
	}

	private function save_event_fields( $post_id, $body ) {
		$body = $this->plain_text( $body );
		$patterns = array( 'date' => '/^Datum:\s*(\d{4}-\d{2}-\d{2}|\d{2}\.\d{2}\.\d{4})/mi', 'time' => '/^Uhrzeit:\s*([^\r\n]+)/mi', 'location' => '/^Ort:\s*([^\r\n]+)/mi' );
		foreach ( $patterns as $key => $pattern ) {
			if ( preg_match( $pattern, $body, $match ) ) {
				$value = sanitize_text_field( $match[1] );
				if ( 'date' === $key && preg_match( '/^(\d{2})\.(\d{2})\.(\d{4})$/', $value, $date ) ) {
					$value = $date[3] . '-' . $date[2] . '-' . $date[1];
				}
				update_post_meta( $post_id, '_schuetzen_event_' . $key, $value );
			}
		}
	}

	private function plain_text( $body ) {
		$body = preg_replace( '/<\/?(br|div|p|pre)[^>]*>/i', "\n", (string) $body );
		$body = wp_strip_all_tags( html_entity_decode( $body, ENT_QUOTES, 'UTF-8' ) );
		return trim( preg_replace( "/\n{2,}/", "\n", $body ) );
	}

	private function save_info_category( $post_id, $body ) {
		if ( preg_match( '/^Kategorie:\s*(Regiment|Korps|Zug)\s*$/mi', $body, $match ) ) {
			update_post_meta( $post_id, '_schuetzen_info_category', sanitize_key( $match[1] ) );
		}
	}

	private function attach_first_image( $connection, $message_number, $post_id, $settings ) {
		$structure = imap_fetchstructure( $connection, $message_number );
		if ( empty( $structure->parts ) ) {
			return;
		}
		foreach ( $structure->parts as $index => $part ) {
			if ( 'IMAGE' !== strtoupper( $part->type === 5 ? 'image' : ( $part->subtype ?? '' ) ) && 5 !== (int) $part->type ) {
				continue;
			}
			$filename = '';
			foreach ( array( 'dparameters', 'parameters' ) as $parameter_group ) {
				foreach ( $part->$parameter_group ?? array() as $parameter ) {
					if ( 'FILENAME' === strtoupper( $parameter->attribute ?? '' ) || 'NAME' === strtoupper( $parameter->attribute ?? '' ) ) {
						$filename = $this->decode_header( $parameter->value );
					}
				}
			}
			$body = imap_fetchbody( $connection, $message_number, (string) ( $index + 1 ) );
			if ( 3 === (int) $part->encoding ) {
				$body = base64_decode( $body, true );
			} elseif ( 4 === (int) $part->encoding ) {
				$body = quoted_printable_decode( $body );
			}
			if ( ! $body || strlen( $body ) > ( absint( $settings['max_image_mb'] ?? 5 ) * 1024 * 1024 ) ) {
				continue;
			}
			$tmp = wp_tempnam( $filename ?: 'schuetzen-app-image.jpg' );
			file_put_contents( $tmp, $body );
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$attachment_id = media_handle_sideload( array( 'name' => sanitize_file_name( $filename ?: 'schuetzen-app-image.jpg' ), 'tmp_name' => $tmp, 'size' => strlen( $body ) ), $post_id );
			if ( ! is_wp_error( $attachment_id ) ) {
				set_post_thumbnail( $post_id, $attachment_id );
			}
			if ( file_exists( $tmp ) ) {
				unlink( $tmp );
			}
			return;
		}
	}
}
