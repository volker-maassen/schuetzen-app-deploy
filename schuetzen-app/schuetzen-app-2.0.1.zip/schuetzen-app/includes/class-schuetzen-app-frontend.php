<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Frontend {
	public function __construct() {
		add_shortcode( 'schuetzen_app', array( $this, 'render_app' ) );
		add_filter( 'template_include', array( $this, 'use_standalone_template' ) );
		add_action( 'template_redirect', array( $this, 'serve_service_worker' ) );
	}

	public function serve_service_worker() {
		if ( ! isset( $_GET['schuetzen_app_sw'] ) ) {
			return;
		}

		nocache_headers();
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: /' );
		readfile( plugin_dir_path( SCHUETZEN_APP_FILE ) . 'app/service-worker.js' );
		exit;
	}

	public function use_standalone_template( $template ) {
		$host = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) ) : '';

		if ( is_page( 9 ) && 'app.hubertus-fahnenzug.de' === $host ) {
			return plugin_dir_path( SCHUETZEN_APP_FILE ) . 'app-page.php';
		}

		return $template;
	}

	public function render_app() {
		$asset_url = plugin_dir_url( SCHUETZEN_APP_FILE ) . 'app/';

		wp_enqueue_style(
			'schuetzen-app',
			$asset_url . 'app.css',
			array(),
			SCHUETZEN_APP_VERSION
		);
		$settings = get_option( 'schuetzen_app_settings', array() );
		$defaults = array(
			'green'      => '#1e4d3a',
			'green_dark' => '#123326',
			'gold'       => '#d6a84f',
			'cream'      => '#f7f4ec',
			'paper'      => '#fffdf8',
			'ink'        => '#1f2824',
			'muted'      => '#69736d',
			'header'     => '#f7f4ec',
			'footer'     => '#fffdf8',
		);
		$css = ':root{';
		foreach ( $defaults as $key => $default ) {
			$value = sanitize_hex_color( $settings[ 'color_' . $key ] ?? '' ) ?: $default;
			$css .= '--schuetzen-' . esc_attr( str_replace( '_', '-', $key ) ) . ':' . esc_attr( $value ) . ';';
		}
		$css .= '}';
		wp_add_inline_style( 'schuetzen-app', $css );
		wp_enqueue_script(
			'schuetzen-app',
			$asset_url . 'app.js',
			array(),
			SCHUETZEN_APP_VERSION,
			true
		);

		wp_localize_script(
			'schuetzen-app',
			'SchuetzenAppConfig',
			array(
				'apiUrl'    => esc_url_raw( rest_url( 'schuetzen-app/v1/content' ) ),
				'appName'   => get_bloginfo( 'name' ),
				'iconUrl'   => esc_url( get_site_icon_url( 192 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-192.png' ),
				'brandLine1' => sanitize_text_field( $settings['brand_line_1'] ?? 'ST. HUBERTUS' ),
				'brandLine2' => sanitize_text_field( $settings['brand_line_2'] ?? 'Fahnenzug' ),
				'iconBase'  => esc_url( $asset_url . 'icons/' ),
				'manifest'  => esc_url( $asset_url . 'manifest.webmanifest' ),
				'workerUrl' => esc_url( home_url( '/?schuetzen_app_sw=1' ) ),
			)
		);

		return '<div class="schuetzen-app" id="schuetzen-app" aria-live="polite">
			<div class="schuetzen-app__loading">App wird geladen …</div>
		</div>';
	}
}
