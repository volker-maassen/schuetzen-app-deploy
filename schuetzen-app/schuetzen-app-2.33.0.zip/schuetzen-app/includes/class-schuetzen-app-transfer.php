<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Transfer {
	const SCHEMA_VERSION = 1;
	const BLACKLIST_OPTION = 'schuetzen_app_blacklist';

	public function __construct() {
		add_action( 'admin_post_schuetzen_app_export_bundle', array( $this, 'export_bundle' ) );
		add_action( 'admin_post_schuetzen_app_import_bundle', array( $this, 'import_bundle' ) );
	}

	public static function render_panel() {
		$export_url = wp_nonce_url( admin_url( 'admin-post.php?action=schuetzen_app_export_bundle' ), 'schuetzen_app_export_bundle' );
		?>
		<hr>
		<h2>Schützen-App-Daten exportieren</h2>
		<p>Der Schützen-App-Export ist unabhängig vom WordPress-Exporter und enthält nur die ausgewählten App-Daten.</p>
		<p>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="events" checked form="schuetzen-app-export-form"> Termine inklusive Meta-Informationen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="march_orders" checked form="schuetzen-app-export-form"> Marschordnungen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="groups" checked form="schuetzen-app-export-form"> Gruppen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="calendar_sources" form="schuetzen-app-export-form"> Kalenderquellen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="blacklist" checked form="schuetzen-app-export-form"> Blacklist und Blacklist-Regeln</label>
		</p>
		<p><label><input type="checkbox" name="schuetzen_app_export_private_urls" value="1" form="schuetzen-app-export-form"> Private iCal-Adressen einschließen</label><br><small>Nur aktivieren, wenn die JSON-Datei vertraulich behandelt wird.</small></p>
		<p><button type="submit" class="button button-primary" form="schuetzen-app-export-form">Ausgewählte Daten als JSON herunterladen</button></p>
		<hr>
		<h2>Schützen-App-Daten importieren</h2>
		<p>Der Import arbeitet standardmäßig ergänzend: neue Inhalte werden angelegt, vorhandene Inhalte mit derselben Transfer-ID aktualisiert. Nicht enthaltene Daten werden nicht gelöscht.</p>
		<p><input type="file" name="schuetzen_app_bundle_file" accept="application/json,.json" required form="schuetzen-app-bundle-import-form"></p>
		<p>
			<label><input type="checkbox" name="schuetzen_app_import_events" value="1" checked form="schuetzen-app-bundle-import-form"> Termine importieren</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_march_orders" value="1" checked form="schuetzen-app-bundle-import-form"> Marschordnungen importieren</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_groups" value="1" form="schuetzen-app-bundle-import-form"> Gruppen importieren</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_calendar_sources" value="1" form="schuetzen-app-bundle-import-form"> Kalenderquellen importieren</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_blacklist" value="1" checked form="schuetzen-app-bundle-import-form"> Blacklist-Regeln übernehmen</label>
		</p>
		<p><button type="submit" class="button button-primary" form="schuetzen-app-bundle-import-form" onclick="return window.confirm('Die ausgewählten Schützen-App-Daten werden ergänzend importiert. Fortfahren?');">Ausgewählte Daten importieren</button></p>
		<p class="description">Benutzer, Passwörter und individuelle Zugriffsrechte sind niemals Bestandteil dieses Exports.</p>
		<p><a href="<?php echo esc_url( $export_url ); ?>" class="button">Schnellexport der Standardauswahl</a></p>
		<?php
	}

	public function export_bundle() {
		$this->require_admin( 'Keine Berechtigung für den Schützen-App-Export.' );
		check_admin_referer( 'schuetzen_app_export_bundle' );
		$datasets = array_map( 'sanitize_key', (array) ( $_POST['schuetzen_app_export_datasets'] ?? array( 'events', 'march_orders', 'groups', 'blacklist' ) ) );
		$payload = array(
			'type' => 'schuetzen-app-bundle',
			'schema_version' => self::SCHEMA_VERSION,
			'plugin_version' => SCHUETZEN_APP_VERSION,
			'exported_at' => gmdate( 'c' ),
			'datasets' => array(),
		);
		if ( in_array( 'groups', $datasets, true ) ) $payload['datasets']['groups'] = Schuetzen_App_Groups::get();
		if ( in_array( 'calendar_sources', $datasets, true ) ) $payload['datasets']['calendar_sources'] = $this->export_sources( ! empty( $_POST['schuetzen_app_export_private_urls'] ) );
		if ( in_array( 'march_orders', $datasets, true ) ) $payload['datasets']['march_orders'] = $this->export_march_orders();
		if ( in_array( 'events', $datasets, true ) ) $payload['datasets']['events'] = $this->export_events();
		if ( in_array( 'blacklist', $datasets, true ) ) $payload['datasets']['blacklist'] = get_option( self::BLACKLIST_OPTION, array( 'entries' => array(), 'rules' => array() ) );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="schuetzen-app-daten-' . gmdate( 'Y-m-d' ) . '.json"' );
		echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	public function import_bundle() {
		$this->require_admin( 'Keine Berechtigung für den Schützen-App-Import.' );
		check_admin_referer( 'schuetzen_app_import_bundle' );
		$file = $_FILES['schuetzen_app_bundle_file'] ?? array();
		if ( ! is_array( $file ) || ! is_uploaded_file( $file['tmp_name'] ?? '' ) || UPLOAD_ERR_OK !== (int) ( $file['error'] ?? 0 ) || (int) ( $file['size'] ?? 0 ) > MB_IN_BYTES ) {
			$this->redirect( 'import-error' );
		}
		$payload = json_decode( (string) file_get_contents( $file['tmp_name'] ), true );
		if ( ! is_array( $payload ) || 'schuetzen-app-bundle' !== ( $payload['type'] ?? '' ) || self::SCHEMA_VERSION !== (int) ( $payload['schema_version'] ?? 0 ) || ! is_array( $payload['datasets'] ?? null ) ) {
			$this->redirect( 'import-invalid' );
		}
		$result = array( 'created' => 0, 'updated' => 0, 'skipped' => 0 );
		$datasets = $payload['datasets'];
		$march_map = ! empty( $_POST['schuetzen_app_import_march_orders'] ) ? $this->import_march_orders( $datasets['march_orders'] ?? array(), $result ) : array();
		if ( ! empty( $_POST['schuetzen_app_import_groups'] ) && isset( $datasets['groups'] ) ) update_option( 'schuetzen_app_settings', $this->merge_groups( $datasets['groups'] ), false );
		if ( ! empty( $_POST['schuetzen_app_import_calendar_sources'] ) && isset( $datasets['calendar_sources'] ) ) $this->import_sources( $datasets['calendar_sources'], $result );
		if ( ! empty( $_POST['schuetzen_app_import_events'] ) ) $this->import_events( $datasets['events'] ?? array(), $march_map, $result );
		if ( ! empty( $_POST['schuetzen_app_import_blacklist'] ) && isset( $datasets['blacklist'] ) ) update_option( self::BLACKLIST_OPTION, $this->merge_blacklist( $datasets['blacklist'] ), false );
		set_transient( 'schuetzen_app_transfer_notice_' . get_current_user_id(), $result, 120 );
		$this->redirect( 'bundle-imported' );
	}

	private function export_events() {
		$items = array();
		foreach ( get_posts( array( 'post_type' => 'schuetzen_event', 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $post ) {
			$date = get_post_meta( $post->ID, '_schuetzen_event_date', true );
			$category = get_post_meta( $post->ID, '_schuetzen_event_category', true );
			$key = get_post_meta( $post->ID, '_schuetzen_event_external_key', true ) ?: hash( 'sha256', $post->post_title . '|' . $date . '|' . $category );
			$march_id = absint( get_post_meta( $post->ID, '_schuetzen_event_march_order', true ) );
			$items[] = array( 'key' => $key, 'title' => $post->post_title, 'content' => $post->post_content, 'status' => $post->post_status, 'meta' => array( 'date' => $date, 'end_date' => get_post_meta( $post->ID, '_schuetzen_event_end_date', true ), 'time' => get_post_meta( $post->ID, '_schuetzen_event_time', true ), 'time_approx' => get_post_meta( $post->ID, '_schuetzen_event_time_approx', true ), 'time_after' => get_post_meta( $post->ID, '_schuetzen_event_time_after', true ), 'time_after_text' => get_post_meta( $post->ID, '_schuetzen_event_time_after_text', true ), 'location' => get_post_meta( $post->ID, '_schuetzen_event_location', true ), 'meeting_point' => get_post_meta( $post->ID, '_schuetzen_event_meeting_point', true ), 'category' => $category, 'all_day' => get_post_meta( $post->ID, '_schuetzen_event_all_day', true ), 'collector_disabled' => get_post_meta( $post->ID, '_schuetzen_event_collector_disabled', true ), 'internal' => get_post_meta( $post->ID, '_schuetzen_event_internal', true ), 'source_id' => get_post_meta( $post->ID, '_schuetzen_event_source_id', true ), 'source_name' => get_post_meta( $post->ID, '_schuetzen_event_source_name', true ) ), 'march_order_key' => $march_id ? $this->march_key( $march_id ) : '' );
		}
		return $items;
	}

	private function export_march_orders() {
		$items = array();
		foreach ( get_posts( array( 'post_type' => 'schuetzen_march', 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $post ) $items[] = array( 'key' => $this->march_key( $post->ID ), 'title' => $post->post_title, 'status' => $post->post_status, 'blocks' => get_post_meta( $post->ID, '_schuetzen_march_order_blocks', true ) );
		return $items;
	}

	private function export_sources( $include_urls ) {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$sources = Schuetzen_App_Calendar_Sources::sanitize_sources( is_array( $settings ) ? ( $settings['calendar_sources'] ?? array() ) : array() );
		if ( ! $include_urls ) foreach ( $sources as &$source ) $source['url'] = '';
		return $sources;
	}

	private function import_events( $items, $march_map, &$result ) {
		foreach ( (array) $items as $item ) {
			$key = sanitize_text_field( $item['key'] ?? '' );
			if ( '' === $key || empty( $item['title'] ) ) { $result['skipped']++; continue; }
			$existing = get_posts( array( 'post_type' => 'schuetzen_event', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_schuetzen_transfer_key', 'meta_value' => $key ) );
			$data = array( 'post_type' => 'schuetzen_event', 'post_title' => sanitize_text_field( $item['title'] ), 'post_content' => wp_kses_post( $item['content'] ?? '' ), 'post_status' => in_array( $item['status'] ?? 'draft', array( 'publish', 'draft', 'pending', 'private' ), true ) ? $item['status'] : 'draft' );
			if ( $existing ) { $data['ID'] = (int) $existing[0]; $post_id = wp_update_post( wp_slash( $data ), true ); $action = 'updated'; } else { $post_id = wp_insert_post( wp_slash( $data ), true ); $action = 'created'; }
			if ( is_wp_error( $post_id ) ) { $result['skipped']++; continue; }
			update_post_meta( $post_id, '_schuetzen_transfer_key', $key );
			foreach ( (array) ( $item['meta'] ?? array() ) as $meta_key => $value ) update_post_meta( $post_id, '_schuetzen_event_' . sanitize_key( $meta_key ), sanitize_text_field( $value ) );
			if ( ! empty( $item['march_order_key'] ) && isset( $march_map[ $item['march_order_key'] ] ) ) update_post_meta( $post_id, '_schuetzen_event_march_order', $march_map[ $item['march_order_key'] ] );
			$result[ $action ]++;
		}
	}

	private function import_march_orders( $items, &$result ) {
		$map = array();
		foreach ( (array) $items as $item ) {
			$key = sanitize_text_field( $item['key'] ?? '' ); if ( '' === $key || empty( $item['title'] ) ) { $result['skipped']++; continue; }
			$existing = get_posts( array( 'post_type' => 'schuetzen_march', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_schuetzen_transfer_key', 'meta_value' => $key ) );
			$data = array( 'post_type' => 'schuetzen_march', 'post_title' => sanitize_text_field( $item['title'] ), 'post_status' => 'publish' ); if ( $existing ) { $data['ID'] = (int) $existing[0]; $id = wp_update_post( wp_slash( $data ), true ); $action = 'updated'; } else { $id = wp_insert_post( wp_slash( $data ), true ); $action = 'created'; }
			if ( is_wp_error( $id ) ) { $result['skipped']++; continue; } update_post_meta( $id, '_schuetzen_transfer_key', $key ); update_post_meta( $id, '_schuetzen_march_order_blocks', is_array( $item['blocks'] ?? null ) ? $item['blocks'] : array() ); $map[ $key ] = (int) $id; $result[ $action ]++;
		}
		return $map;
	}

	private function merge_groups( $groups ) { $settings = get_option( 'schuetzen_app_settings', array() ); $settings['groups'] = is_array( $groups ) ? Schuetzen_App_Groups::sanitize( $groups ) : ( $settings['groups'] ?? array() ); return $settings; }
	private function import_sources( $sources, &$result ) { $settings = get_option( 'schuetzen_app_settings', array() ); $settings['calendar_sources'] = Schuetzen_App_Calendar_Sources::sanitize_sources( $sources ); update_option( 'schuetzen_app_settings', $settings, false ); $result['updated']++; }
	private function merge_blacklist( $blacklist ) { $current = get_option( self::BLACKLIST_OPTION, array( 'entries' => array(), 'rules' => array() ) ); return array( 'entries' => array_values( array_unique( array_merge( (array) ( $current['entries'] ?? array() ), (array) ( $blacklist['entries'] ?? array() ) ), SORT_REGULAR ) ), 'rules' => array_values( array_unique( array_merge( (array) ( $current['rules'] ?? array() ), (array) ( $blacklist['rules'] ?? array() ) ), SORT_REGULAR ) ) ); }
	private function march_key( $post_id ) { return hash( 'sha256', 'march|' . (int) $post_id . '|' . get_the_title( $post_id ) ); }
	private function require_admin( $message ) { if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html( $message ) ); }
	private function redirect( $status ) { wp_safe_redirect( add_query_arg( array( 'page' => 'schuetzen-app', 'tab' => 'transfer', 'transfer_status' => sanitize_key( $status ) ), admin_url( 'admin.php' ) ) ); exit; }
}
