<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Frontend {
	public function __construct() {
		add_shortcode( 'schuetzen_app', array( $this, 'render_app' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 100 );
		add_action( 'wp', array( $this, 'prevent_app_caching' ), 1 );
		add_filter( 'template_include', array( $this, 'use_standalone_template' ) );
		add_filter( 'show_admin_bar', array( $this, 'hide_admin_bar_for_app' ) );
		add_action( 'template_redirect', array( $this, 'serve_service_worker' ) );
		add_action( 'template_redirect', array( $this, 'serve_manifest' ) );
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'enqueue_login_assets' ), 100 );
		add_filter( 'login_headerurl', array( __CLASS__, 'login_header_url' ) );
		add_filter( 'login_headertext', array( __CLASS__, 'login_header_text' ) );
		add_filter( 'login_body_class', array( __CLASS__, 'login_body_class' ) );
	}

	public function prevent_app_caching() {
		if ( $this->is_app_page() ) {
			$this->disable_caching();
		}
	}

	private function is_app_page() {
		if ( ! is_singular( 'page' ) ) {
			return false;
		}

		$page = get_queried_object();
		return $page instanceof WP_Post && has_shortcode( $page->post_content, 'schuetzen_app' );
	}

	private function disable_caching() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
		nocache_headers();
		do_action( 'litespeed_control_set_nocache', 'Schuetzen-App benötigt sitzungsabhängige Inhalte.' );
	}

	public function hide_admin_bar_for_app( $show ) {
		if ( is_admin() || ! is_singular( 'page' ) ) {
			return $show;
		}

		$page = get_queried_object();
		return $page instanceof WP_Post && has_shortcode( $page->post_content, 'schuetzen_app' ) ? false : $show;
	}

	public function serve_manifest() {
		if ( ! isset( $_GET['schuetzen_app_manifest'] ) ) {
			return;
		}

		$home_url = home_url( '/' );
		$start_url = isset( $_GET['start_url'] ) ? esc_url_raw( wp_unslash( $_GET['start_url'] ) ) : $home_url;
		if ( wp_parse_url( $start_url, PHP_URL_HOST ) !== wp_parse_url( $home_url, PHP_URL_HOST ) ) {
			$start_url = $home_url;
		}

		$icon_192 = get_site_icon_url( 192 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-192.png';
		$icon_512 = get_site_icon_url( 512 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-512.png';
		$name = get_bloginfo( 'name' ) ?: 'Schützen-App';
		$settings = get_option( 'schuetzen_app_settings', array() );
		$theme_isolation_enabled = ! array_key_exists( 'disable_theme_settings', $settings ) || ! empty( $settings['disable_theme_settings'] );
		$theme_color = '#1e4d3a';
		$background_color = sanitize_hex_color( $settings['color_cream'] ?? $settings['cream'] ?? '' ) ?: '#f7f4ec';
		$primary_group = Schuetzen_App_Groups::primary_id();
		foreach ( Schuetzen_App_Groups::get() as $group ) {
			if ( $group['id'] === $primary_group ) {
				$theme_color = sanitize_hex_color( $group['color'] ?? '' ) ?: $theme_color;
				break;
			}
		}

		nocache_headers();
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		echo wp_json_encode(
			array(
				'name'             => $name,
				'short_name'       => $name,
				'start_url'        => $start_url,
				'display'          => 'standalone',
				'scope'            => '/',
				'orientation'      => 'portrait',
				'background_color' => $background_color,
				'theme_color'      => $theme_color,
				'lang'             => get_bloginfo( 'language' ) ?: 'de-DE',
				'description'      => 'Termine, Nachrichten und Informationen.',
				'icons'            => array(
					array(
						'src'     => esc_url_raw( $icon_192 ),
						'sizes'   => '192x192',
						'type'    => 'image/png',
						'purpose' => 'any',
					),
					array(
						'src'     => esc_url_raw( $icon_512 ),
						'sizes'   => '512x512',
						'type'    => 'image/png',
						'purpose' => 'any',
					),
				),
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);
		exit;
	}

	public function serve_service_worker() {
		if ( ! isset( $_GET['schuetzen_app_sw'] ) ) {
			return;
		}

		nocache_headers();
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: /' );
		readfile( plugin_dir_path( SCHUETZEN_APP_FILE ) . 'app/service-worker.js' );
		exit;
	}

	public function use_standalone_template( $template ) {
		if ( $this->is_app_page() ) {
			$this->disable_caching();
			return plugin_dir_path( SCHUETZEN_APP_FILE ) . 'app-page.php';
		}

		return $template;
	}

	public static function enqueue_assets() {
		static $enqueued = false;
		if ( $enqueued ) {
			return;
		}
		$page = get_queried_object();
		$is_app_page = is_singular( 'page' ) && $page instanceof WP_Post && has_shortcode( $page->post_content, 'schuetzen_app' );
		if ( ! $is_app_page ) {
			return;
		}
		$enqueued = true;

		$asset_url = plugin_dir_url( SCHUETZEN_APP_FILE ) . 'app/';
		$start_url = get_queried_object_id() ? get_permalink( get_queried_object_id() ) : home_url( '/' );
		$manifest_url = add_query_arg(
			array(
				'schuetzen_app_manifest' => 1,
				'start_url'              => $start_url,
				'ver'                    => SCHUETZEN_APP_VERSION,
			),
			home_url( '/' )
		);
		$api_url = add_query_arg( 'rest_route', '/schuetzen-app/v1/content', home_url( '/' ) );
		$import_horizon_end = ( (int) current_time( 'Y' ) + 1 ) . '-12-31';

		wp_enqueue_style(
			'schuetzen-app',
			$asset_url . 'app.css',
			array(),
			SCHUETZEN_APP_VERSION
		);
		$settings = get_option( 'schuetzen_app_settings', array() );
		$defaults = array(
			'background_start' => '#f7f4ec',
			'background_end'   => '#e9e5db',
			'green'      => '#1e4d3a',
			'green_dark' => '#123326',
			'gold'       => '#d6a84f',
			'cream'      => '#f7f4ec',
			'paper'      => '#fffdf8',
			'ink'        => '#1f2824',
			'muted'      => '#69736d',
			'header'     => '#f7f4ec',
			'footer'     => '#fffdf8',
		);
		$hex_to_rgba = static function ( $hex, $alpha ) {
			$hex = ltrim( $hex, '#' );
			if ( 3 === strlen( $hex ) ) {
				$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
			}
			return sprintf( 'rgba(%d,%d,%d,%.2f)', hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ), $alpha );
		};
		$css = ':root{';
		foreach ( $defaults as $key => $default ) {
			$value = sanitize_hex_color( $settings[ 'color_' . $key ] ?? $settings[ $key ] ?? '' ) ?: $default;
			$legacy_opacity = ( 'background_end' === $key ) ? ( $settings['background_end_opacity'] ?? 100 ) : 100;
			$opacity = min( 100, max( 0, absint( $settings[ 'color_' . $key . '_opacity' ] ?? $legacy_opacity ) ) ) / 100;
			$css .= '--schuetzen-' . esc_attr( str_replace( '_', '-', $key ) ) . ':' . esc_attr( $hex_to_rgba( $value, $opacity ) ) . ';';
		}
		$group_colors = Schuetzen_App_Groups::color_map();
		$group_labels = Schuetzen_App_Groups::labels();
		$primary_group = Schuetzen_App_Groups::primary_id();
		$always_visible_groups = array( $primary_group );
		foreach ( Schuetzen_App_Groups::get() as $group ) {
			if ( ! empty( $group['always_visible'] ) ) {
				$always_visible_groups[] = $group['id'];
			}
		}
		if ( isset( $group_colors[ $primary_group ] ) ) {
			$css .= '--schuetzen-primary-group:' . esc_attr( $group_colors[ $primary_group ] ) . ';';
		}
		$css .= '}';
		wp_add_inline_style( 'schuetzen-app', $css );
		wp_enqueue_script(
			'schuetzen-app',
			$asset_url . 'app.js',
			array(),
			SCHUETZEN_APP_VERSION,
			true
		);

		wp_localize_script(
			'schuetzen-app',
			'SchuetzenAppConfig',
			array(
				'apiUrl'    => esc_url_raw( $api_url ),
				'restNonce' => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
				'loginUrl'  => esc_url_raw( Schuetzen_App_Login::login_url() ),
				'logoutUrl' => esc_url_raw( wp_logout_url( Schuetzen_App_Login::app_url() ) ),
				'version'   => SCHUETZEN_APP_VERSION,
				'copyrightYear' => wp_date( 'Y' ),
				'appName'   => get_bloginfo( 'name' ),
				'iconUrl'   => esc_url( ( $settings['header_logo'] ?? '' ) ?: get_site_icon_url( 192 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-192.png' ),
				'brandLine1' => sanitize_text_field( $settings['brand_line_1'] ?? '' ),
				'brandLine2' => sanitize_text_field( $settings['brand_line_2'] ?? '' ),
				'brandLine3' => sanitize_text_field( array_key_exists( 'brand_line_3', $settings ) ? $settings['brand_line_3'] : get_bloginfo( 'description' ) ),
				'iconBase'  => esc_url( $asset_url . 'icons/' ),
				'manifest'  => esc_url( $manifest_url ),
				'workerUrl' => esc_url( add_query_arg( array( 'schuetzen_app_sw' => 1, 'ver' => SCHUETZEN_APP_VERSION ), home_url( '/' ) ) ),
				'enabledSections' => array(
					'messages' => ! array_key_exists( 'navigation_messages', $settings ) || ! empty( $settings['navigation_messages'] ),
					'info'     => ! array_key_exists( 'navigation_info', $settings ) || ! empty( $settings['navigation_info'] ),
				),
				'groupColors' => $group_colors,
				'groupLabels' => $group_labels,
				'primaryGroup' => $primary_group,
				'alwaysVisibleGroups' => array_values( array_unique( $always_visible_groups ) ),
				'collectorPriorityGroups' => Schuetzen_App_Groups::collector_priority_ids(),
				'importHorizonEnd' => $import_horizon_end,
				'sectionBackgrounds' => array(
					'events' => esc_url_raw( $settings['background_events'] ?? '' ),
					'messages' => esc_url_raw( $settings['background_messages'] ?? '' ),
					'info' => esc_url_raw( $settings['background_info'] ?? '' ),
				),
			)
		);

	}

	/**
	 * Gestaltet ausschließlich die WordPress-Anmeldeseite. Die Formulare und
	 * ihre Sicherheitslogik bleiben unverändert WordPress-Standard.
	 */
	public static function enqueue_login_assets() {
		$asset_url = plugin_dir_url( SCHUETZEN_APP_FILE ) . 'app/';
		$settings  = get_option( 'schuetzen_app_settings', array() );
		$settings  = is_array( $settings ) ? $settings : array();
		$color     = static function ( $key, $fallback ) use ( $settings ) {
			return sanitize_hex_color( $settings[ 'color_' . $key ] ?? $settings[ $key ] ?? '' ) ?: $fallback;
		};
		$logo = esc_url_raw( ( $settings['header_logo'] ?? '' ) ?: get_site_icon_url( 192 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-192.png' );

		wp_enqueue_style( 'schuetzen-app-login', $asset_url . 'login.css', array(), SCHUETZEN_APP_VERSION );
		wp_add_inline_style(
			'schuetzen-app-login',
			'.login.schuetzen-app-login{--schuetzen-login-background:' . esc_attr( $color( 'cream', '#f7f4ec' ) ) . ';--schuetzen-login-surface:' . esc_attr( $color( 'paper', '#fffdf8' ) ) . ';--schuetzen-login-primary:' . esc_attr( $color( 'green', '#1e4d3a' ) ) . ';--schuetzen-login-primary-strong:' . esc_attr( $color( 'green_dark', '#123326' ) ) . ';--schuetzen-login-text:' . esc_attr( $color( 'ink', '#1f2824' ) ) . ';--schuetzen-login-muted:' . esc_attr( $color( 'muted', '#69736d' ) ) . ';--schuetzen-login-logo:url("' . esc_url( $logo ) . '");}'
		);
	}

	public static function login_header_url() {
		return Schuetzen_App_Login::app_url();
	}

	public static function login_header_text() {
		return get_bloginfo( 'name' ) ?: 'Schützen-App';
	}

	public static function login_body_class( $classes ) {
		$classes[] = 'schuetzen-app-login';
		return $classes;
	}

	public function render_app() {
		$this->disable_caching();
		if ( ! wp_style_is( 'schuetzen-app', 'enqueued' ) && ! did_action( 'wp_head' ) ) {
			self::enqueue_assets();
		}

		$settings = get_option( 'schuetzen_app_settings', array() );
		$theme_isolation_enabled = ! array_key_exists( 'disable_theme_settings', $settings ) || ! empty( $settings['disable_theme_settings'] );
		return '<div class="schuetzen-app' . ( $theme_isolation_enabled ? ' schuetzen-app--theme-isolated' : '' ) . '" id="schuetzen-app" aria-live="polite">
			<div class="schuetzen-app__loading">App wird geladen …</div>
		</div>';
	}
}
