const CACHE_NAME = 'schuetzen-app-v2.29.0';

self.addEventListener('install', function (event) {
	event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', function (event) {
	event.waitUntil(
		caches.keys().then(function (keys) {
			return Promise.all(keys.filter(function (key) {
				return key.indexOf('schuetzen-app-') === 0 && key !== CACHE_NAME;
			}).map(function (key) { return caches.delete(key); }));
		}).then(function () { return self.clients.claim(); })
	);
});

self.addEventListener('fetch', function (event) {
	if (event.request.method !== 'GET') {
		return;
	}

	var requestUrl = new URL(event.request.url);
	if (requestUrl.pathname.indexOf('/wp-json/') !== -1 || requestUrl.searchParams.has('rest_route')) {
		event.respondWith(fetch(event.request));
		return;
	}

	event.respondWith(
		fetch(event.request).then(function (response) {
			var cacheControl = response.headers.get('cache-control') || '';
			if (response.ok && new URL(event.request.url).origin === self.location.origin && !/(?:no-store|private|no-cache)/i.test(cacheControl)) {
				var copy = response.clone();
				caches.open(CACHE_NAME).then(function (cache) {
					cache.put(event.request, copy);
				});
			}
			return response;
		}).catch(function () {
			return caches.match(event.request).then(function (cached) {
				return cached || caches.match(self.registration.scope);
			});
		})
	);
});
