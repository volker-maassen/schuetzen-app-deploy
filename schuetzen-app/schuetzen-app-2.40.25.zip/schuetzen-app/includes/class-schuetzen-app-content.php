<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Content {
	public function __construct() {
		add_action( 'init', array( $this, 'register_content_types' ) );
		add_action( 'init', array( $this, 'publish_scheduled_events' ), 20 );
		add_filter( 'wp_insert_post_data', array( $this, 'prevent_event_scheduling' ), 10, 2 );
		add_action( 'add_meta_boxes', array( $this, 'add_event_meta_box' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_person_meta_box' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_march_order_meta_box' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_info_meta_box' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_message_meta_box' ) );
		add_action( 'save_post_schuetzen_event', array( $this, 'save_event_meta' ), 10, 2 );
		add_action( 'save_post_schuetzen_person', array( $this, 'save_person_meta' ), 10, 2 );
		add_action( 'save_post_schuetzen_march', array( $this, 'save_march_order_meta' ), 10, 2 );
		add_action( 'save_post_schuetzen_info', array( $this, 'save_info_meta' ), 10, 2 );
		add_action( 'save_post_schuetzen_message', array( $this, 'save_message_meta' ), 10, 2 );
		add_filter( 'manage_schuetzen_event_posts_columns', array( $this, 'event_admin_columns' ) );
		add_action( 'manage_schuetzen_event_posts_custom_column', array( $this, 'render_event_admin_column' ), 10, 2 );
		add_action( 'restrict_manage_posts', array( $this, 'render_event_group_filter' ) );
		add_action( 'quick_edit_custom_box', array( $this, 'render_event_quick_edit' ), 10, 2 );
		add_action( 'bulk_edit_custom_box', array( $this, 'render_event_bulk_edit' ), 10, 2 );
		add_action( 'admin_footer-edit.php', array( $this, 'event_quick_edit_script' ) );
		add_action( 'admin_head-edit.php', array( $this, 'event_quick_edit_style' ) );
		add_action( 'pre_get_posts', array( $this, 'sort_event_admin_list' ) );
		add_filter( 'post_row_actions', array( $this, 'march_order_row_actions' ), 10, 2 );
		add_action( 'admin_post_schuetzen_duplicate_march', array( $this, 'duplicate_march_order' ) );
		add_action( 'save_post_schuetzen_event', array( $this, 'save_event_bulk_fields' ), 20, 2 );
	}

	/**
	 * Termine richten sich nach ihrem eigenen Termin-Datum, nie nach dem
	 * WordPress-Veröffentlichungsdatum. Eine zeitgesteuerte Veröffentlichung
	 * würde sie erst zeigen, wenn der Termin bereits begonnen hat.
	 */
	public function prevent_event_scheduling( $data, $postarr ) {
		if ( 'schuetzen_event' !== ( $data['post_type'] ?? '' ) || 'future' !== ( $data['post_status'] ?? '' ) ) {
			return $data;
		}

		$data['post_status']   = 'publish';
		$data['post_date']     = current_time( 'mysql' );
		$data['post_date_gmt'] = current_time( 'mysql', true );
		return $data;
	}

	/**
	 * Hebt einmalig alle früher zeitgesteuert veröffentlichten App-Termine auf.
	 */
	public function publish_scheduled_events() {
		if ( SCHUETZEN_APP_VERSION === get_option( 'schuetzen_app_event_publication_version' ) ) {
			return;
		}

		$event_ids = get_posts(
			array(
				'post_type'      => 'schuetzen_event',
				'post_status'    => 'future',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		$now     = current_time( 'mysql' );
		$now_gmt = current_time( 'mysql', true );
		foreach ( $event_ids as $event_id ) {
			wp_update_post(
				array(
					'ID'            => (int) $event_id,
					'post_status'   => 'publish',
					'post_date'     => $now,
					'post_date_gmt' => $now_gmt,
				)
			);
		}

		update_option( 'schuetzen_app_event_publication_version', SCHUETZEN_APP_VERSION, false );
	}

	public function march_order_row_actions( $actions, $post ) {
		if ( 'schuetzen_march' !== $post->post_type || ! current_user_can( 'edit_post', $post->ID ) ) {
			return $actions;
		}

		$url = wp_nonce_url(
			admin_url( 'admin-post.php?action=schuetzen_duplicate_march&post_id=' . $post->ID ),
			'schuetzen_duplicate_march_' . $post->ID
		);
		$actions['duplicate_march'] = '<a href="' . esc_url( $url ) . '">Kopieren</a>';
		return $actions;
	}

	public function duplicate_march_order() {
		$post_id = absint( $_GET['post_id'] ?? 0 );
		check_admin_referer( 'schuetzen_duplicate_march_' . $post_id );

		if ( ! $post_id || 'schuetzen_march' !== get_post_type( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( 'Keine Berechtigung zum Kopieren dieser Marschordnung.' );
		}

		$source = get_post( $post_id );
		$copy_id = wp_insert_post(
			wp_slash(
				array(
					'post_type'      => 'schuetzen_march',
					'post_status'    => 'draft',
					'post_title'     => $source->post_title . ' (Kopie)',
					'post_content'   => $source->post_content,
					'post_excerpt'   => $source->post_excerpt,
					'post_author'    => get_current_user_id(),
					'comment_status' => $source->comment_status,
					'ping_status'    => $source->ping_status,
				)
			),
			true
		);

		if ( is_wp_error( $copy_id ) ) {
			wp_die( esc_html( $copy_id->get_error_message() ) );
		}

		$blocks = get_post_meta( $post_id, '_schuetzen_march_order_blocks', true );
		if ( false !== $blocks && '' !== $blocks ) {
			update_post_meta( $copy_id, '_schuetzen_march_order_blocks', $blocks );
		}
		$legacy_rows = get_post_meta( $post_id, '_schuetzen_march_order_rows', true );
		if ( false !== $legacy_rows && '' !== $legacy_rows ) {
			update_post_meta( $copy_id, '_schuetzen_march_order_rows', $legacy_rows );
		}

		$thumbnail_id = get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id ) {
			set_post_thumbnail( $copy_id, $thumbnail_id );
		}

		wp_safe_redirect( admin_url( 'post.php?post=' . $copy_id . '&action=edit' ) );
		exit;
	}

	public function register_content_types() {
		register_post_type(
			'schuetzen_event',
			array(
				'labels'       => array(
					'name'          => 'Termine',
					'singular_name' => 'Termin',
					'add_new_item'  => 'Termin hinzufügen',
					'edit_item'     => 'Termin bearbeiten',
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => 'schuetzen-app',
				'menu_icon'     => 'dashicons-calendar-alt',
				'supports'      => array( 'title', 'editor', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_message',
			array(
				'labels'      => array(
					'name'          => 'Nachrichten',
					'singular_name' => 'Nachricht',
					'add_new_item'  => 'Nachricht hinzufügen',
					'edit_item'     => 'Nachricht bearbeiten',
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => 'schuetzen-app',
				'menu_icon'    => 'dashicons-megaphone',
				'supports'     => array( 'title', 'editor', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_info',
			array(
				'labels'      => array(
					'name'          => 'Infos',
					'singular_name' => 'Info',
					'add_new_item'  => 'Info hinzufügen',
					'edit_item'     => 'Info bearbeiten',
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => 'schuetzen-app',
				'menu_icon'    => 'dashicons-info-outline',
				'supports'     => array( 'title', 'editor', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_person',
			array(
				'labels'       => array(
					'name'          => 'Personen',
					'singular_name' => 'Person',
					'add_new_item'  => 'Person hinzufügen',
					'edit_item'     => 'Person bearbeiten',
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => 'schuetzen-app',
				'menu_icon'     => 'dashicons-id-alt',
				'supports'      => array( 'title', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_march',
			array(
				'labels'       => array(
					'name'          => 'Marschordnungen',
					'singular_name' => 'Marschordnung',
					'add_new_item'  => 'Marschordnung hinzufügen',
					'edit_item'     => 'Marschordnung bearbeiten',
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => 'schuetzen-app',
				'menu_icon'     => 'dashicons-grid-view',
				'supports'      => array( 'title' ),
			)
		);
	}

	public function event_admin_columns( $columns ) {
		$updated = array();
		foreach ( $columns as $key => $label ) {
			$updated[ $key ] = $label;
			if ( 'title' === $key ) {
				$updated['schuetzen_event_category'] = 'Zuordnung';
				$updated['schuetzen_event_date']     = 'Eingetragener Termin';
			}
		}
		$columns = $updated;
		if ( isset( $columns['date'] ) ) {
			$columns['date'] = 'Veröffentlicht';
		}
		return $columns;
	}

	public function render_event_admin_column( $column, $post_id ) {
		if ( 'schuetzen_event_category' === $column ) {
			$category = get_post_meta( $post_id, '_schuetzen_event_category', true );
			$labels   = Schuetzen_App_Groups::labels();
			$date     = get_post_meta( $post_id, '_schuetzen_event_date', true );
			$end_date = get_post_meta( $post_id, '_schuetzen_event_end_date', true );
			$all_day  = get_post_meta( $post_id, '_schuetzen_event_all_day', true );
			$collector_disabled = get_post_meta( $post_id, '_schuetzen_event_collector_disabled', true );
			$notice = get_post_meta( $post_id, '_schuetzen_event_notice', true );
			echo '<span class="schuetzen-event-category-value" data-value="' . esc_attr( $category ) . '" data-date="' . esc_attr( $date ) . '" data-end-date="' . esc_attr( $end_date ) . '" data-all-day="' . esc_attr( $all_day ) . '" data-collector-disabled="' . esc_attr( $collector_disabled ) . '" data-notice="' . esc_attr( $notice ) . '">' . esc_html( $labels[ $category ] ?? 'Keine Zuordnung' ) . '</span>';
			return;
		}

		if ( 'schuetzen_event_date' === $column ) {
			$date     = get_post_meta( $post_id, '_schuetzen_event_date', true );
			$end_date = get_post_meta( $post_id, '_schuetzen_event_end_date', true );
			$time     = get_post_meta( $post_id, '_schuetzen_event_time', true );
			$all_day  = get_post_meta( $post_id, '_schuetzen_event_all_day', true );
			if ( ! $date ) {
				echo '&mdash;';
				return;
			}

			$start_timestamp = strtotime( $date );
			$label            = $start_timestamp ? wp_date( 'd.m.Y', $start_timestamp ) : $date;
			if ( $end_date && $end_date !== $date ) {
				$end_timestamp = strtotime( $end_date );
				$label        .= ' – ' . ( $end_timestamp ? wp_date( 'd.m.Y', $end_timestamp ) : $end_date );
			}
			echo esc_html( $label );
			if ( '1' === $all_day ) {
				echo '<br><small>Ganztägig</small>';
			} elseif ( $time ) {
				echo '<br><small>' . esc_html( $time ) . ' Uhr</small>';
			}
			return;
		}

		if ( 'date' !== $column ) {
			return;
		}

		$date = get_post_meta( $post_id, '_schuetzen_event_date', true );
		$time = get_post_meta( $post_id, '_schuetzen_event_time', true );
		$end_date = get_post_meta( $post_id, '_schuetzen_event_end_date', true );
		$all_day = get_post_meta( $post_id, '_schuetzen_event_all_day', true );
		$collector_disabled = get_post_meta( $post_id, '_schuetzen_event_collector_disabled', true );
		$notice = get_post_meta( $post_id, '_schuetzen_event_notice', true );
		echo '<span class="schuetzen-event-quick-values" hidden data-date="' . esc_attr( $date ) . '" data-end-date="' . esc_attr( $end_date ) . '" data-all-day="' . esc_attr( $all_day ) . '" data-collector-disabled="' . esc_attr( $collector_disabled ) . '" data-notice="' . esc_attr( $notice ) . '"></span>';
		if ( ! $date ) {
			echo '&mdash;';
			return;
		}

		$timestamp = strtotime( trim( $date . ' ' . $time ) );
		echo esc_html( $timestamp ? wp_date( 'd.m.Y', $timestamp ) : $date );
		if ( $time ) {
			echo '<br>' . esc_html( $time ) . ' Uhr';
		}
	}

	public function render_event_group_filter( $post_type ) {
		if ( 'schuetzen_event' !== $post_type ) {
			return;
		}
		$current = sanitize_key( wp_unslash( $_GET['schuetzen_event_category_filter'] ?? '' ) );
		?>
		<select name="schuetzen_event_category_filter">
			<option value="">Alle Zuordnungen</option>
			<?php foreach ( Schuetzen_App_Groups::get() as $group ) : ?>
				<option value="<?php echo esc_attr( $group['id'] ); ?>" <?php selected( $current, $group['id'] ); ?>><?php echo esc_html( $group['name'] ); ?></option>
			<?php endforeach; ?>
			<option value="none" <?php selected( $current, 'none' ); ?>>Keine Zuordnung</option>
		</select>
		<?php
	}

	public function render_event_quick_edit( $column, $post_type ) {
		if ( 'schuetzen_event_category' !== $column || 'schuetzen_event' !== $post_type ) {
			return;
		}
		?>
		<fieldset class="inline-edit-col-left">
			<div class="inline-edit-col">
				<label>
					<span class="title">Startdatum</span>
					<span class="input-text-wrap"><input type="date" name="schuetzen_event_date" value=""></span>
				</label>
				<label>
					<span class="title">Enddatum</span>
					<span class="input-text-wrap"><input type="date" name="schuetzen_event_end_date" value=""></span>
				</label>
				<label>
					<span class="title">Ganztägig</span>
					<input type="checkbox" name="schuetzen_event_all_day" value="1">
				</label>
				<label>
					<span class="title">Sammelkarte</span>
					<input type="checkbox" name="schuetzen_event_collector_disabled" value="1"> Nie verwenden
				</label>
				<label>
					<span class="title">Hinweis</span>
					<span class="input-text-wrap"><input type="text" name="schuetzen_event_notice" value="" placeholder="z. B. Einlass nur mit Karte"></span>
				</label>
				<label>
					<span class="title">Zuordnung</span>
					<select name="schuetzen_event_category">
						<option value="">Keine Zuordnung</option>
						<?php foreach ( Schuetzen_App_Groups::get() as $group ) : ?>
							<option value="<?php echo esc_attr( $group['id'] ); ?>"><?php echo esc_html( $group['name'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			</div>
		</fieldset>
		<?php
	}

	public function render_event_bulk_edit( $column, $post_type ) {
		if ( 'schuetzen_event_category' !== $column || 'schuetzen_event' !== $post_type ) {
			return;
		}
		?>
		<div class="inline-edit-col">
			<label>
				<span class="title">Zuordnung</span>
				<select name="schuetzen_event_category_bulk">
					<option value="">– Keine Änderung –</option>
					<option value="none">Keine Zuordnung</option>
					<?php foreach ( Schuetzen_App_Groups::get() as $group ) : ?>
						<option value="<?php echo esc_attr( $group['id'] ); ?>"><?php echo esc_html( $group['name'] ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>
				<span class="title">Blacklist</span>
				<select name="schuetzen_event_blacklist_bulk">
					<option value="">– Keine Änderung –</option>
					<option value="blacklist">Auf Blacklist setzen</option>
					<option value="unblacklist">Aus Blacklist entfernen</option>
				</select>
			</label>
		</div>
		<?php
	}

	public function event_quick_edit_script() {
		if ( 'schuetzen_event' !== ( $_GET['post_type'] ?? '' ) ) {
			return;
		}
		?>
		<script>
		(function () {
			function populateQuickEdit(row, attempt) {
				var editRow = row && document.getElementById('edit-' + row.id.replace('post-', ''));
				var value = row && row.querySelector('.schuetzen-event-category-value');
				var values = row && row.querySelector('.schuetzen-event-quick-values');
				if (!values) {
					values = value;
				}
				if (!editRow) {
					if (attempt < 5) {
						window.setTimeout(function () { populateQuickEdit(row, attempt + 1); }, 25);
					}
					return;
				}
				var select = editRow.querySelector('select[name="schuetzen_event_category"]');
				if (select) {
					select.value = value ? value.dataset.value : '';
				}
				if (!values) {
					return;
				}
				var date = editRow.querySelector('[name="schuetzen_event_date"]');
				var endDate = editRow.querySelector('[name="schuetzen_event_end_date"]');
				var allDay = editRow.querySelector('[name="schuetzen_event_all_day"]');
				var collectorDisabled = editRow.querySelector('[name="schuetzen_event_collector_disabled"]');
				var notice = editRow.querySelector('[name="schuetzen_event_notice"]');
				if (date) date.value = values.dataset.date || '';
				if (endDate) endDate.value = values.dataset.endDate || '';
				if (allDay) allDay.checked = values.dataset.allDay === '1';
				if (collectorDisabled) collectorDisabled.checked = values.dataset.collectorDisabled === '1';
				if (notice) notice.value = values.dataset.notice || '';
			}

			document.addEventListener('click', function (event) {
				var button = event.target.closest('.editinline');
				if (!button) {
					return;
				}
				var row = button.closest('tr');
				window.setTimeout(function () { populateQuickEdit(row, 0); }, 0);
			});
		})();
		</script>
		<?php
	}

	public function event_quick_edit_style() {
		if ( 'schuetzen_event' !== ( $_GET['post_type'] ?? '' ) ) {
			return;
		}
		?>
		<style>
			/* WordPress' Veröffentlichungsdatum ist nicht das App-Termindatum. */
			.inline-edit-row .inline-edit-date {
				display: none;
			}
		</style>
		<?php
	}

	public function sort_event_admin_list( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || 'schuetzen_event' !== $query->get( 'post_type' ) ) {
			return;
		}

		$filter = sanitize_key( wp_unslash( $_GET['schuetzen_event_category_filter'] ?? '' ) );
		if ( Schuetzen_App_Groups::is_valid( $filter ) ) {
			$query->set( 'meta_query', array( array( 'key' => '_schuetzen_event_category', 'value' => $filter ) ) );
		} elseif ( 'none' === $filter ) {
			$query->set( 'meta_query', array( array( 'relation' => 'OR', array( 'key' => '_schuetzen_event_category', 'compare' => 'NOT EXISTS' ), array( 'key' => '_schuetzen_event_category', 'value' => '', 'compare' => '=' ) ) ) );
		}

		global $wpdb;
		$query->set( 'orderby', 'none' );
		$query->set( 'order', 'ASC' );
		add_filter(
			'posts_clauses',
			static function ( $clauses, $query ) use ( $wpdb ) {
				if ( ! $query->is_main_query() || 'schuetzen_event' !== $query->get( 'post_type' ) ) {
					return $clauses;
				}

				$clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS schuetzen_event_date_sort ON ({$wpdb->posts}.ID = schuetzen_event_date_sort.post_id AND schuetzen_event_date_sort.meta_key = '_schuetzen_event_date')";
				$clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS schuetzen_event_time_sort ON ({$wpdb->posts}.ID = schuetzen_event_time_sort.post_id AND schuetzen_event_time_sort.meta_key = '_schuetzen_event_time')";
				$clauses['orderby'] = "CASE WHEN schuetzen_event_date_sort.meta_value IS NULL OR schuetzen_event_date_sort.meta_value = '' THEN 1 ELSE 0 END ASC, schuetzen_event_date_sort.meta_value ASC, schuetzen_event_time_sort.meta_value ASC, {$wpdb->posts}.ID DESC";
				return $clauses;
			},
			20,
			2
		);
	}

	public function add_event_meta_box() {
		add_meta_box(
			'schuetzen-event-details',
			'Terminangaben',
			array( $this, 'render_event_meta_box' ),
			'schuetzen_event',
			'normal',
			'high'
		);
	}

	public function render_event_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_event_details', 'schuetzen_event_nonce' );
		$date     = get_post_meta( $post->ID, '_schuetzen_event_date', true );
		$end_date = get_post_meta( $post->ID, '_schuetzen_event_end_date', true );
		$time     = get_post_meta( $post->ID, '_schuetzen_event_time', true );
		$all_day  = get_post_meta( $post->ID, '_schuetzen_event_all_day', true );
		$collector_disabled = get_post_meta( $post->ID, '_schuetzen_event_collector_disabled', true );
		$notice = get_post_meta( $post->ID, '_schuetzen_event_notice', true );
		$time_approx = get_post_meta( $post->ID, '_schuetzen_event_time_approx', true );
		$time_after = get_post_meta( $post->ID, '_schuetzen_event_time_after', true );
		$time_after_text = get_post_meta( $post->ID, '_schuetzen_event_time_after_text', true );
		$location = get_post_meta( $post->ID, '_schuetzen_event_location', true );
		$meeting_point = get_post_meta( $post->ID, '_schuetzen_event_meeting_point', true );
		$category = get_post_meta( $post->ID, '_schuetzen_event_category', true );
		$source_name = get_post_meta( $post->ID, '_schuetzen_event_source_name', true );
		$march_order = get_post_meta( $post->ID, '_schuetzen_event_march_order', true );
		$orders = get_posts( array( 'post_type' => 'schuetzen_march', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		?>
		<p>
			<label for="schuetzen_event_date"><strong>Startdatum</strong></label><br>
			<input type="date" id="schuetzen_event_date" name="schuetzen_event_date" value="<?php echo esc_attr( $date ); ?>">
		</p>
		<p>
			<label for="schuetzen_event_end_date"><strong>Enddatum</strong></label><br>
			<input type="date" id="schuetzen_event_end_date" name="schuetzen_event_end_date" value="<?php echo esc_attr( $end_date ); ?>"><br>
			<small>Optional. Das Ende bezeichnet den letzten sichtbaren Kalendertag.</small>
		</p>
		<p>
			<label><input type="checkbox" name="schuetzen_event_all_day" value="1" <?php checked( $all_day, '1' ); ?>> <strong>Ganztagestermin</strong></label><br>
			<small>Ganztägige Termine ohne Ende gelten für genau einen Tag.</small>
		</p>
		<p>
			<label><input type="checkbox" name="schuetzen_event_collector_disabled" value="1" <?php checked( $collector_disabled, '1' ); ?>> <strong>Nie als Sammelkarte verwenden</strong></label><br>
			<small>Der Termin bleibt eine eigene Card, auch wenn am selben Tag weitere zeitlich definierte Termine stattfinden.</small>
		</p>
		<p>
			<label for="schuetzen_event_notice"><strong>Zusatzinformation</strong></label><br>
			<input type="text" class="widefat" id="schuetzen_event_notice" name="schuetzen_event_notice" value="<?php echo esc_attr( $notice ); ?>" placeholder="z. B. Einlass nur mit Karte, Nähere Infos durch Klick oder Private Veranstaltung">
			<small>Wird in der App oberhalb von Ort und Treffpunkt angezeigt.</small>
		</p>
		<p>
			<label for="schuetzen_event_time"><strong>Uhrzeit</strong></label><br>
			<input type="time" id="schuetzen_event_time" name="schuetzen_event_time" value="<?php echo esc_attr( $time ); ?>">
		</p>
		<p>
			<label>
				<input type="checkbox" name="schuetzen_event_time_approx" value="1" <?php checked( $time_approx, '1' ); ?>>
				<strong>ca.</strong> vor der Uhrzeit anzeigen
			</label>
		</p>
		<p>
			<label>
				<input type="checkbox" name="schuetzen_event_time_after" value="1" <?php checked( $time_after, '1' ); ?>>
				<strong>Danach:</strong> statt der konkreten Uhrzeit einen freien Text anzeigen
			</label>
		</p>
		<p>
			<label for="schuetzen_event_time_after_text"><strong>Alternative Zeitangabe</strong></label><br>
			<input type="text" class="widefat" id="schuetzen_event_time_after_text" name="schuetzen_event_time_after_text" value="<?php echo esc_attr( $time_after_text ); ?>" placeholder="z. B. Im Anschluss oder Nach dem vorherigen Umzug">
			<small>Wird nur verwendet, wenn „Danach“ aktiviert ist. Eine eingetragene Uhrzeit bleibt für die Sortierung erhalten, wird aber nicht angezeigt.</small>
		</p>
		<p>
			<label for="schuetzen_event_location"><strong>Ort</strong></label><br>
			<input type="text" class="widefat" id="schuetzen_event_location" name="schuetzen_event_location" value="<?php echo esc_attr( $location ); ?>">
		</p>
		<p>
			<label for="schuetzen_event_meeting_point"><strong>Treffpunkt</strong></label><br>
			<input type="text" class="widefat" id="schuetzen_event_meeting_point" name="schuetzen_event_meeting_point" value="<?php echo esc_attr( $meeting_point ); ?>">
		</p>
		<p>
			<label for="schuetzen_event_category"><strong>Gruppe</strong></label><br>
			<select class="widefat" id="schuetzen_event_category" name="schuetzen_event_category">
				<option value="" <?php selected( $category, '' ); ?>>Keine Zuordnung</option>
				<?php foreach ( Schuetzen_App_Groups::get() as $group ) : ?>
					<option value="<?php echo esc_attr( $group['id'] ); ?>" <?php selected( $category, $group['id'] ); ?>><?php echo esc_html( $group['name'] ); ?></option>
				<?php endforeach; ?>
			</select>
			<small>Die Gruppe bestimmt die Farbe des linken Randes der Termin-Card.</small>
		</p>
		<?php if ( $source_name ) : ?>
			<p><strong>Externe Kalenderquelle</strong><br><?php echo esc_html( $source_name ); ?><br><small>Die importierten Termindaten werden bei der nächsten Synchronisierung wieder mit der Quelle abgeglichen. Der Text im WordPress-Editor ist eine lokale Ergänzung und bleibt dabei erhalten.</small></p>
		<?php endif; ?>
		<p>
			<label for="schuetzen_event_march_order"><strong>Marschordnung</strong></label><br>
			<select class="widefat" id="schuetzen_event_march_order" name="schuetzen_event_march_order">
				<option value="">Keine Marschordnung</option>
				<?php foreach ( $orders as $order ) : ?>
					<option value="<?php echo esc_attr( $order->ID ); ?>" <?php selected( (int) $march_order, $order->ID ); ?>><?php echo esc_html( $order->post_title ); ?></option>
				<?php endforeach; ?>
			</select>
			<small>Die Marschordnung wird auf der Termin-Detailseite angezeigt.</small>
		</p>
		<?php
	}

	public function add_person_meta_box() {
		add_meta_box( 'schuetzen-person-role', 'Rolle', array( $this, 'render_person_meta_box' ), 'schuetzen_person', 'side', 'high' );
	}

	public function render_person_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_person_details', 'schuetzen_person_nonce' );
		$role = get_post_meta( $post->ID, '_schuetzen_person_role', true );
		?>
		<label for="schuetzen_person_role">Rolle (optional)</label>
		<input type="text" class="widefat" id="schuetzen_person_role" name="schuetzen_person_role" value="<?php echo esc_attr( $role ); ?>">
		<p class="description">Zum Beispiel Hauptmann oder Fahnenschwenker.</p>
		<?php
	}

	public function add_march_order_meta_box() {
		add_meta_box( 'schuetzen-march-order-rows', 'Reihenfolge', array( $this, 'render_march_order_meta_box' ), 'schuetzen_march', 'normal', 'high' );
	}

	public function render_march_order_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_march_order_details', 'schuetzen_march_order_nonce' );
		$blocks = get_post_meta( $post->ID, '_schuetzen_march_order_blocks', true );
		if ( ! is_array( $blocks ) || ! $blocks ) {
			$legacy_rows = get_post_meta( $post->ID, '_schuetzen_march_order_rows', true );
			$blocks      = is_array( $legacy_rows ) && $legacy_rows ? array( $legacy_rows ) : array();
		}
		$blocks = array_pad( array_slice( $blocks, 0, 5 ), 5, array() );
		$people = get_posts( array( 'post_type' => 'schuetzen_person', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		?>
		<p>Der Zug kann in bis zu fünf Marschblöcke aufgeteilt werden. Jede Zeile kann eine, zwei oder drei Personen enthalten. Leere Felder bleiben frei.</p>
		<?php for ( $block_index = 0; $block_index < 5; $block_index++ ) : ?>
			<fieldset style="margin:1.5rem 0;padding:1rem;border:1px solid #ccd0d4;">
				<legend style="padding:0 .5rem;font-weight:600;">Marschblock <?php echo esc_html( $block_index + 1 ); ?></legend>
				<table class="widefat striped">
					<thead><tr><th>Links</th><th>Mitte</th><th>Rechts</th></tr></thead>
					<tbody>
					<?php for ( $row_index = 0; $row_index < 20; $row_index++ ) : ?>
						<tr>
						<?php for ( $slot = 0; $slot < 3; $slot++ ) : ?>
							<td><select class="widefat" name="schuetzen_march_blocks[<?php echo esc_attr( $block_index ); ?>][<?php echo esc_attr( $row_index ); ?>][<?php echo esc_attr( $slot ); ?>]"><option value="">— frei —</option><?php foreach ( $people as $person ) : ?><option value="<?php echo esc_attr( $person->ID ); ?>" <?php selected( (int) ( $blocks[ $block_index ][ $row_index ][ $slot ] ?? 0 ), $person->ID ); ?>><?php echo esc_html( $person->post_title ); ?></option><?php endforeach; ?></select></td>
						<?php endfor; ?>
						</tr>
					<?php endfor; ?>
					</tbody>
				</table>
			</fieldset>
		<?php endfor; ?>
		<?php
	}

	public function add_info_meta_box() {
		wp_enqueue_media();
		add_meta_box( 'schuetzen-info-category', 'Info-Zuordnung', array( $this, 'render_info_meta_box' ), 'schuetzen_info', 'side', 'high' );
	}

	public function add_message_meta_box() {
		add_meta_box( 'schuetzen-message-category', 'Nachrichten-Zuordnung', array( $this, 'render_message_meta_box' ), 'schuetzen_message', 'side', 'high' );
	}

	public function render_message_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_message_category', 'schuetzen_message_nonce' );
		$category = get_post_meta( $post->ID, '_schuetzen_message_category', true );
		?>
		<label for="schuetzen_message_category">Zuordnung</label>
		<select class="widefat" id="schuetzen_message_category" name="schuetzen_message_category">
			<option value="" <?php selected( $category, '' ); ?>>Keine Zuordnung</option>
			<?php foreach ( Schuetzen_App_Groups::get() as $group ) : ?>
				<option value="<?php echo esc_attr( $group['id'] ); ?>" <?php selected( $category, $group['id'] ); ?>><?php echo esc_html( $group['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	public function save_message_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_message_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_message_nonce'] ) ), 'schuetzen_message_category' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$category = sanitize_key( wp_unslash( $_POST['schuetzen_message_category'] ?? '' ) );
		update_post_meta( $post_id, '_schuetzen_message_category', Schuetzen_App_Groups::is_valid( $category ) ? $category : '' );
	}

	public function render_info_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_info_category', 'schuetzen_info_nonce' );
		$category = get_post_meta( $post->ID, '_schuetzen_info_category', true );
		$pdf_id = absint( get_post_meta( $post->ID, '_schuetzen_info_pdf', true ) );
		$pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
		?>
		<label for="schuetzen_info_category">Zuordnung</label>
		<select class="widefat" id="schuetzen_info_category" name="schuetzen_info_category">
			<option value="" <?php selected( $category, '' ); ?>>Keine Zuordnung</option>
			<?php foreach ( Schuetzen_App_Groups::get() as $group ) : ?>
				<option value="<?php echo esc_attr( $group['id'] ); ?>" <?php selected( $category, $group['id'] ); ?>><?php echo esc_html( $group['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<p style="margin-top:16px;"><label for="schuetzen_info_pdf"><strong>PDF-Dokument</strong></label></p>
		<input type="hidden" id="schuetzen_info_pdf" name="schuetzen_info_pdf" value="<?php echo esc_attr( $pdf_id ); ?>">
		<input type="text" class="widefat" id="schuetzen_info_pdf_url" value="<?php echo esc_attr( $pdf_url ); ?>" readonly>
		<p><button type="button" class="button" id="schuetzen_info_pdf_select">PDF auswählen</button> <button type="button" class="button" id="schuetzen_info_pdf_remove" <?php disabled( ! $pdf_id ); ?>>Entfernen</button></p>
		<script>
		jQuery(function ($) {
			var frame;
			$('#schuetzen_info_pdf_select').on('click', function () {
				if (frame) { frame.open(); return; }
				frame = wp.media({ title: 'PDF auswählen', button: { text: 'PDF verwenden' }, library: { type: 'application/pdf' }, multiple: false });
				frame.on('select', function () {
					var attachment = frame.state().get('selection').first().toJSON();
					$('#schuetzen_info_pdf').val(attachment.id);
					$('#schuetzen_info_pdf_url').val(attachment.url);
					$('#schuetzen_info_pdf_remove').prop('disabled', false);
				});
				frame.open();
			});
			$('#schuetzen_info_pdf_remove').on('click', function () {
				$('#schuetzen_info_pdf').val('');
				$('#schuetzen_info_pdf_url').val('');
				$(this).prop('disabled', true);
			});
		});
		</script>
		<?php
	}

	public function save_info_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_info_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_info_nonce'] ) ), 'schuetzen_info_category' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$category = sanitize_key( wp_unslash( $_POST['schuetzen_info_category'] ?? '' ) );
		update_post_meta( $post_id, '_schuetzen_info_category', Schuetzen_App_Groups::is_valid( $category ) ? $category : '' );
		$pdf_id = absint( $_POST['schuetzen_info_pdf'] ?? 0 );
		if ( $pdf_id && 'application/pdf' === get_post_mime_type( $pdf_id ) ) {
			update_post_meta( $post_id, '_schuetzen_info_pdf', $pdf_id );
		} else {
			delete_post_meta( $post_id, '_schuetzen_info_pdf' );
		}
	}

	private function sanitize_event_date( $value ) {
		$value = sanitize_text_field( wp_unslash( $value ) );
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $matches ) || ! checkdate( (int) $matches[2], (int) $matches[3], (int) $matches[1] ) ) {
			return '';
		}
		return $value;
	}

	public function save_event_meta( $post_id, $post ) {
		if ( isset( $_POST['_inline_edit'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_inline_edit'] ) ), 'inlineeditnonce' ) ) {
			if ( current_user_can( 'edit_post', $post_id ) && isset( $_POST['schuetzen_event_category'] ) ) {
				$category = sanitize_key( wp_unslash( $_POST['schuetzen_event_category'] ) );
				update_post_meta( $post_id, '_schuetzen_event_category', Schuetzen_App_Groups::is_valid( $category ) ? $category : '' );
				$date = $this->sanitize_event_date( $_POST['schuetzen_event_date'] ?? '' );
				$end_date = $this->sanitize_event_date( $_POST['schuetzen_event_end_date'] ?? '' );
				if ( $end_date && ( ! $date || $end_date < $date ) ) {
					$end_date = '';
				}
				update_post_meta( $post_id, '_schuetzen_event_date', $date );
				update_post_meta( $post_id, '_schuetzen_event_end_date', $end_date );
				$all_day = isset( $_POST['schuetzen_event_all_day'] );
				update_post_meta( $post_id, '_schuetzen_event_all_day', $all_day ? '1' : '' );
				if ( $all_day ) {
					update_post_meta( $post_id, '_schuetzen_event_time', '' );
					update_post_meta( $post_id, '_schuetzen_event_time_approx', '' );
					update_post_meta( $post_id, '_schuetzen_event_time_after', '' );
				}
				update_post_meta( $post_id, '_schuetzen_event_collector_disabled', isset( $_POST['schuetzen_event_collector_disabled'] ) ? '1' : '' );
				update_post_meta( $post_id, '_schuetzen_event_notice', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_notice'] ?? '' ) ) );
			}
			return;
		}

		if ( ! isset( $_POST['schuetzen_event_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_event_nonce'] ) ), 'schuetzen_event_details' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$date = $this->sanitize_event_date( $_POST['schuetzen_event_date'] ?? '' );
		$end_date = $this->sanitize_event_date( $_POST['schuetzen_event_end_date'] ?? '' );
		if ( $end_date && ( ! $date || $end_date < $date ) ) {
			$end_date = '';
		}
		$all_day = isset( $_POST['schuetzen_event_all_day'] );
		$time = $all_day ? '' : sanitize_text_field( wp_unslash( $_POST['schuetzen_event_time'] ?? '' ) );
		update_post_meta( $post_id, '_schuetzen_event_date', $date );
		update_post_meta( $post_id, '_schuetzen_event_end_date', $end_date );
		update_post_meta( $post_id, '_schuetzen_event_all_day', $all_day ? '1' : '' );
		update_post_meta( $post_id, '_schuetzen_event_collector_disabled', isset( $_POST['schuetzen_event_collector_disabled'] ) ? '1' : '' );
		update_post_meta( $post_id, '_schuetzen_event_notice', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_notice'] ?? '' ) ) );
		update_post_meta( $post_id, '_schuetzen_event_time', $time );
		update_post_meta( $post_id, '_schuetzen_event_time_approx', ! $all_day && isset( $_POST['schuetzen_event_time_approx'] ) ? '1' : '' );
		update_post_meta( $post_id, '_schuetzen_event_time_after', $time && isset( $_POST['schuetzen_event_time_after'] ) ? '1' : '' );
		update_post_meta( $post_id, '_schuetzen_event_time_after_text', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_time_after_text'] ?? '' ) ) );
		update_post_meta( $post_id, '_schuetzen_event_location', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_location'] ?? '' ) ) );
		update_post_meta( $post_id, '_schuetzen_event_meeting_point', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_meeting_point'] ?? '' ) ) );
		$category = sanitize_key( wp_unslash( $_POST['schuetzen_event_category'] ?? '' ) );
		update_post_meta( $post_id, '_schuetzen_event_category', Schuetzen_App_Groups::is_valid( $category ) ? $category : '' );
		update_post_meta( $post_id, '_schuetzen_event_march_order', absint( $_POST['schuetzen_event_march_order'] ?? 0 ) );
	}

	public function save_event_bulk_fields( $post_id, $post ) {
		if ( 'schuetzen_event' !== $post->post_type || empty( $_REQUEST['bulk_edit'] ) || defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( isset( $_REQUEST['schuetzen_event_category_bulk'] ) ) {
			$category = sanitize_key( wp_unslash( $_REQUEST['schuetzen_event_category_bulk'] ) );
			if ( 'none' === $category ) {
				$category = '';
			}
			if ( '' === $category || Schuetzen_App_Groups::is_valid( $category ) ) {
				update_post_meta( $post_id, '_schuetzen_event_category', $category );
			}
		}

		if ( isset( $_REQUEST['schuetzen_event_blacklist_bulk'] ) ) {
			$blacklist_action = sanitize_key( wp_unslash( $_REQUEST['schuetzen_event_blacklist_bulk'] ) );
			if ( 'blacklist' === $blacklist_action ) {
				Schuetzen_App_Blacklist::add_event( $post_id );
			} elseif ( 'unblacklist' === $blacklist_action ) {
				Schuetzen_App_Blacklist::remove_event( $post_id );
			}
		}
	}

	public function save_person_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_person_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_person_nonce'] ) ), 'schuetzen_person_details' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_schuetzen_person_role', sanitize_text_field( wp_unslash( $_POST['schuetzen_person_role'] ?? '' ) ) );
	}

	public function save_march_order_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_march_order_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_march_order_nonce'] ) ), 'schuetzen_march_order_details' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$blocks = array();
		foreach ( array_slice( (array) ( $_POST['schuetzen_march_blocks'] ?? array() ), 0, 5 ) as $block ) {
			$clean_rows = array();
			foreach ( array_slice( (array) $block, 0, 20 ) as $row ) {
				$clean_row = array_map( 'absint', array_slice( (array) $row, 0, 3 ) );
				if ( array_filter( $clean_row ) ) {
					$clean_rows[] = $clean_row;
				}
			}
			$blocks[] = $clean_rows;
		}
		update_post_meta( $post_id, '_schuetzen_march_order_blocks', $blocks );
	}
}
