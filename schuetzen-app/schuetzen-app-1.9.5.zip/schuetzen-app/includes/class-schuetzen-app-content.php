<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Content {
	public function __construct() {
		add_action( 'init', array( $this, 'register_content_types' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_event_meta_box' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_info_meta_box' ) );
		add_action( 'save_post_schuetzen_event', array( $this, 'save_event_meta' ), 10, 2 );
		add_action( 'save_post_schuetzen_info', array( $this, 'save_info_meta' ), 10, 2 );
	}

	public function register_content_types() {
		register_post_type(
			'schuetzen_event',
			array(
				'labels'       => array(
					'name'          => 'Termine',
					'singular_name' => 'Termin',
					'add_new_item'  => 'Termin hinzufügen',
					'edit_item'     => 'Termin bearbeiten',
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => true,
				'menu_icon'     => 'dashicons-calendar-alt',
				'supports'      => array( 'title', 'editor', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_message',
			array(
				'labels'      => array(
					'name'          => 'Nachrichten',
					'singular_name' => 'Nachricht',
					'add_new_item'  => 'Nachricht hinzufügen',
					'edit_item'     => 'Nachricht bearbeiten',
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => true,
				'menu_icon'    => 'dashicons-megaphone',
				'supports'     => array( 'title', 'editor', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_info',
			array(
				'labels'      => array(
					'name'          => 'Infos',
					'singular_name' => 'Info',
					'add_new_item'  => 'Info hinzufügen',
					'edit_item'     => 'Info bearbeiten',
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => true,
				'menu_icon'    => 'dashicons-info-outline',
				'supports'     => array( 'title', 'editor', 'thumbnail' ),
			)
		);
	}

	public function add_event_meta_box() {
		add_meta_box(
			'schuetzen-event-details',
			'Terminangaben',
			array( $this, 'render_event_meta_box' ),
			'schuetzen_event',
			'normal',
			'high'
		);
	}

	public function render_event_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_event_details', 'schuetzen_event_nonce' );
		$date     = get_post_meta( $post->ID, '_schuetzen_event_date', true );
		$time     = get_post_meta( $post->ID, '_schuetzen_event_time', true );
		$location = get_post_meta( $post->ID, '_schuetzen_event_location', true );
		?>
		<p>
			<label for="schuetzen_event_date"><strong>Datum</strong></label><br>
			<input type="date" id="schuetzen_event_date" name="schuetzen_event_date" value="<?php echo esc_attr( $date ); ?>">
		</p>
		<p>
			<label for="schuetzen_event_time"><strong>Uhrzeit</strong></label><br>
			<input type="time" id="schuetzen_event_time" name="schuetzen_event_time" value="<?php echo esc_attr( $time ); ?>">
		</p>
		<p>
			<label for="schuetzen_event_location"><strong>Ort</strong></label><br>
			<input type="text" class="widefat" id="schuetzen_event_location" name="schuetzen_event_location" value="<?php echo esc_attr( $location ); ?>">
		</p>
		<?php
	}

	public function add_info_meta_box() {
		add_meta_box( 'schuetzen-info-category', 'Info-Kategorie', array( $this, 'render_info_meta_box' ), 'schuetzen_info', 'side', 'high' );
	}

	public function render_info_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_info_category', 'schuetzen_info_nonce' );
		$category = get_post_meta( $post->ID, '_schuetzen_info_category', true );
		?>
		<label for="schuetzen_info_category">Kategorie</label>
		<select class="widefat" id="schuetzen_info_category" name="schuetzen_info_category">
			<option value="" <?php selected( $category, '' ); ?>>Alle</option>
			<option value="regiment" <?php selected( $category, 'regiment' ); ?>>Regiment</option>
			<option value="korps" <?php selected( $category, 'korps' ); ?>>Korps</option>
			<option value="zug" <?php selected( $category, 'zug' ); ?>>Zug</option>
		</select>
		<?php
	}

	public function save_info_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_info_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_info_nonce'] ) ), 'schuetzen_info_category' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$category = sanitize_key( wp_unslash( $_POST['schuetzen_info_category'] ?? '' ) );
		update_post_meta( $post_id, '_schuetzen_info_category', in_array( $category, array( 'regiment', 'korps', 'zug' ), true ) ? $category : '' );
	}

	public function save_event_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_event_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_event_nonce'] ) ), 'schuetzen_event_details' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_schuetzen_event_date', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_date'] ?? '' ) ) );
		update_post_meta( $post_id, '_schuetzen_event_time', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_time'] ?? '' ) ) );
		update_post_meta( $post_id, '_schuetzen_event_location', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_location'] ?? '' ) ) );
	}
}
