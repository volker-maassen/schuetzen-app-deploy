<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_REST {
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			'schuetzen-app/v1',
			'/content',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_content' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function get_content() {
		$event_data   = $this->get_entries( 'schuetzen_event', true );
		$message_data = $this->get_entries( 'schuetzen_message' );
		$info_data    = $this->get_entries( 'schuetzen_info' );

		return rest_ensure_response(
			array(
				'app_name' => get_bloginfo( 'name' ),
				'app_description' => get_bloginfo( 'description' ),
				'events'   => $event_data,
				'messages' => $message_data,
				'info'     => $info_data,
			)
		);
	}

	private function get_entries( $post_type, $events = false ) {
		$query_args = array(
			'post_type'      => $post_type,
			'post_status'    => 'publish',
			'posts_per_page' => 20,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( $events ) {
			$query_args['orderby']  = 'meta_value';
			$query_args['meta_key'] = '_schuetzen_event_date';
			$query_args['order']    = 'ASC';
			$query_args['meta_query'] = array(
				array(
					'key'     => '_schuetzen_event_date',
					'value'   => current_time( 'Y-m-d' ),
					'compare' => '>=',
					'type'    => 'DATE',
				),
			);
		}

		$posts = get_posts( $query_args );

		return array_map(
			function ( $post ) use ( $events, $post_type ) {
				$data = array(
					'id'          => $post->ID,
					'title'       => get_the_title( $post ),
					'date'        => get_the_date( 'Y-m-d', $post ),
					'description' => wpautop( wp_kses_post( $post->post_content ) ),
					'image'       => get_the_post_thumbnail_url( $post, 'large' ) ?: '',
					'category'    => $post_type === 'schuetzen_info' ? get_post_meta( $post->ID, '_schuetzen_info_category', true ) : '',
				);

				if ( $events ) {
					$data['date']     = get_post_meta( $post->ID, '_schuetzen_event_date', true );
					$data['time']     = get_post_meta( $post->ID, '_schuetzen_event_time', true );
					$data['location'] = get_post_meta( $post->ID, '_schuetzen_event_location', true );
				}

				return $data;
			},
			$posts
		);
	}
}
