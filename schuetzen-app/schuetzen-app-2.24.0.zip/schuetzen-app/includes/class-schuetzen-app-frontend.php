<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Frontend {
	public function __construct() {
		add_shortcode( 'schuetzen_app', array( $this, 'render_app' ) );
		add_filter( 'template_include', array( $this, 'use_standalone_template' ) );
		add_action( 'template_redirect', array( $this, 'serve_service_worker' ) );
		add_action( 'template_redirect', array( $this, 'serve_manifest' ) );
	}

	public function serve_manifest() {
		if ( ! isset( $_GET['schuetzen_app_manifest'] ) ) {
			return;
		}

		$home_url = home_url( '/' );
		$start_url = isset( $_GET['start_url'] ) ? esc_url_raw( wp_unslash( $_GET['start_url'] ) ) : $home_url;
		if ( wp_parse_url( $start_url, PHP_URL_HOST ) !== wp_parse_url( $home_url, PHP_URL_HOST ) ) {
			$start_url = $home_url;
		}

		$icon_192 = get_site_icon_url( 192 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-192.png';
		$icon_512 = get_site_icon_url( 512 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-512.png';
		$name = get_bloginfo( 'name' ) ?: 'Schützen-App';

		nocache_headers();
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		echo wp_json_encode(
			array(
				'name'             => $name,
				'short_name'       => $name,
				'start_url'        => $start_url,
				'display'          => 'standalone',
				'scope'            => '/',
				'orientation'      => 'portrait',
				'background_color' => '#f7f4ec',
				'theme_color'      => '#1e4d3a',
				'lang'             => get_bloginfo( 'language' ) ?: 'de-DE',
				'description'      => 'Termine, Nachrichten und Informationen.',
				'icons'            => array(
					array(
						'src'     => esc_url_raw( $icon_192 ),
						'sizes'   => '192x192',
						'type'    => 'image/png',
						'purpose' => 'any',
					),
					array(
						'src'     => esc_url_raw( $icon_512 ),
						'sizes'   => '512x512',
						'type'    => 'image/png',
						'purpose' => 'any',
					),
				),
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);
		exit;
	}

	public function serve_service_worker() {
		if ( ! isset( $_GET['schuetzen_app_sw'] ) ) {
			return;
		}

		nocache_headers();
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: /' );
		readfile( plugin_dir_path( SCHUETZEN_APP_FILE ) . 'app/service-worker.js' );
		exit;
	}

	public function use_standalone_template( $template ) {
		if ( ! is_singular( 'page' ) ) {
			return $template;
		}

		$page = get_queried_object();
		if ( $page instanceof WP_Post && has_shortcode( $page->post_content, 'schuetzen_app' ) ) {
			return plugin_dir_path( SCHUETZEN_APP_FILE ) . 'app-page.php';
		}

		return $template;
	}

	public function render_app() {
		$asset_url = plugin_dir_url( SCHUETZEN_APP_FILE ) . 'app/';
		$start_url = get_queried_object_id() ? get_permalink( get_queried_object_id() ) : home_url( '/' );
		$manifest_url = add_query_arg(
			array(
				'schuetzen_app_manifest' => 1,
				'start_url'              => $start_url,
				'ver'                    => SCHUETZEN_APP_VERSION,
			),
			home_url( '/' )
		);

		wp_enqueue_style(
			'schuetzen-app',
			$asset_url . 'app.css',
			array(),
			SCHUETZEN_APP_VERSION
		);
		$settings = get_option( 'schuetzen_app_settings', array() );
		$defaults = array(
			'background_start' => '#f7f4ec',
			'background_end'   => '#e9e5db',
			'green'      => '#1e4d3a',
			'green_dark' => '#123326',
			'gold'       => '#d6a84f',
			'cream'      => '#f7f4ec',
			'paper'      => '#fffdf8',
			'ink'        => '#1f2824',
			'muted'      => '#69736d',
			'header'     => '#f7f4ec',
			'footer'     => '#fffdf8',
		);
		$hex_to_rgba = static function ( $hex, $alpha ) {
			$hex = ltrim( $hex, '#' );
			if ( 3 === strlen( $hex ) ) {
				$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
			}
			return sprintf( 'rgba(%d,%d,%d,%.2f)', hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ), $alpha );
		};
		$css = ':root{';
		foreach ( $defaults as $key => $default ) {
			$value = sanitize_hex_color( $settings[ 'color_' . $key ] ?? $settings[ $key ] ?? '' ) ?: $default;
			$legacy_opacity = ( 'background_end' === $key ) ? ( $settings['background_end_opacity'] ?? 100 ) : 100;
			$opacity = min( 100, max( 0, absint( $settings[ 'color_' . $key . '_opacity' ] ?? $legacy_opacity ) ) ) / 100;
			$css .= '--schuetzen-' . esc_attr( str_replace( '_', '-', $key ) ) . ':' . esc_attr( $hex_to_rgba( $value, $opacity ) ) . ';';
		}
		$group_colors = Schuetzen_App_Groups::color_map();
		$group_labels = Schuetzen_App_Groups::labels();
		$primary_group = Schuetzen_App_Groups::primary_id();
		if ( isset( $group_colors[ $primary_group ] ) ) {
			$css .= '--schuetzen-primary-group:' . esc_attr( $group_colors[ $primary_group ] ) . ';';
		}
		$css .= '}';
		wp_add_inline_style( 'schuetzen-app', $css );
		wp_enqueue_script(
			'schuetzen-app',
			$asset_url . 'app.js',
			array(),
			SCHUETZEN_APP_VERSION,
			true
		);

		wp_localize_script(
			'schuetzen-app',
			'SchuetzenAppConfig',
			array(
				'apiUrl'    => esc_url_raw( rest_url( 'schuetzen-app/v1/content' ) ),
				'appName'   => get_bloginfo( 'name' ),
				'iconUrl'   => esc_url( ( $settings['header_logo'] ?? '' ) ?: get_site_icon_url( 192 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-192.png' ),
				'brandLine1' => sanitize_text_field( $settings['brand_line_1'] ?? '' ),
				'brandLine2' => sanitize_text_field( $settings['brand_line_2'] ?? '' ),
				'brandLine3' => sanitize_text_field( array_key_exists( 'brand_line_3', $settings ) ? $settings['brand_line_3'] : get_bloginfo( 'description' ) ),
				'iconBase'  => esc_url( $asset_url . 'icons/' ),
				'manifest'  => esc_url( $manifest_url ),
				'workerUrl' => esc_url( home_url( '/?schuetzen_app_sw=1' ) ),
				'enabledSections' => array(
					'messages' => ! array_key_exists( 'navigation_messages', $settings ) || ! empty( $settings['navigation_messages'] ),
					'info'     => ! array_key_exists( 'navigation_info', $settings ) || ! empty( $settings['navigation_info'] ),
				),
				'groupColors' => $group_colors,
				'groupLabels' => $group_labels,
				'sectionBackgrounds' => array(
					'events' => esc_url_raw( $settings['background_events'] ?? '' ),
					'messages' => esc_url_raw( $settings['background_messages'] ?? '' ),
					'info' => esc_url_raw( $settings['background_info'] ?? '' ),
				),
			)
		);

		return '<div class="schuetzen-app" id="schuetzen-app" aria-live="polite">
			<div class="schuetzen-app__loading">App wird geladen …</div>
		</div>';
	}
}
