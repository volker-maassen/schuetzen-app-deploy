<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Calendar_Sources {
	const CRON_HOOK = 'schuetzen_app_sync_calendars';

	public function __construct() {
		add_action( 'init', array( $this, 'schedule_sync' ) );
		add_action( self::CRON_HOOK, array( $this, 'sync_active_sources' ) );
		add_action( 'admin_post_schuetzen_app_sync_calendars', array( $this, 'manual_sync' ) );
	}

	public static function sanitize_sources( $sources, $available_groups = null ) {
		$clean  = array();
		$used   = array();
		$groups = array();
		if ( is_array( $available_groups ) ) {
			foreach ( $available_groups as $group ) {
				$groups[ $group['id'] ] = $group['name'];
			}
		} else {
			$groups = Schuetzen_App_Groups::labels();
		}

		foreach ( array_slice( (array) $sources, 0, 20 ) as $source ) {
			$name = sanitize_text_field( $source['name'] ?? '' );
			$url  = esc_url_raw( $source['url'] ?? '', array( 'http', 'https' ) );
			$id   = sanitize_key( $source['id'] ?? '' );
			if ( '' === $name && '' === $url ) {
				continue;
			}
			if ( '' === $id ) {
				$id = sanitize_key( 'quelle-' . wp_generate_uuid4() );
			}
			if ( isset( $used[ $id ] ) ) {
				continue;
			}

			$group = sanitize_key( $source['group'] ?? '' );
			$used[ $id ] = true;
			$clean[] = array(
				'id'      => $id,
				'name'    => $name ?: $url,
				'url'     => $url,
				'group'   => isset( $groups[ $group ] ) ? $group : '',
				'status'  => 'publish' === ( $source['status'] ?? '' ) ? 'publish' : 'draft',
				'active'  => ! empty( $source['active'] ) ? 1 : 0,
			);
		}

		return $clean;
	}

	public function schedule_sync() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 300, 'twicedaily', self::CRON_HOOK );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	public function manual_sync() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Keine Berechtigung für die Kalendersynchronisierung.' );
		}
		check_admin_referer( 'schuetzen_app_sync_calendars' );

		$result = $this->sync_active_sources();
		set_transient( 'schuetzen_app_calendar_notice_' . get_current_user_id(), $result, 120 );
		wp_safe_redirect( add_query_arg( array( 'page' => 'schuetzen-app', 'tab' => 'calendars' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function sync_active_sources() {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$sources  = self::sanitize_sources( is_array( $settings ) ? ( $settings['calendar_sources'] ?? array() ) : array() );
		$result   = array( 'sources' => 0, 'created' => 0, 'updated' => 0, 'errors' => array() );

		foreach ( $sources as $source ) {
			if ( empty( $source['active'] ) || empty( $source['url'] ) ) {
				continue;
			}
			$result['sources']++;
			$source_result = $this->sync_source( $source );
			if ( is_wp_error( $source_result ) ) {
				$result['errors'][] = $source['name'] . ': ' . $source_result->get_error_message();
				$this->save_status( $source['id'], 0, 0, $source_result->get_error_message() );
				continue;
			}
			$result['created'] += $source_result['created'];
			$result['updated'] += $source_result['updated'];
			$error = empty( $source_result['failed'] ) ? '' : sprintf( '%d Termin(e) konnten nicht gespeichert werden.', $source_result['failed'] );
			if ( $error ) {
				$result['errors'][] = $source['name'] . ': ' . $error;
			}
			$this->save_status( $source['id'], $source_result['created'], $source_result['updated'], $error );
		}

		return $result;
	}

	private function sync_source( $source ) {
		$calendar = $this->fetch_calendar( $source['url'] );
		if ( is_wp_error( $calendar ) ) {
			return $calendar;
		}

		$events = $this->parse_calendar( $calendar );
		if ( ! $events ) {
			return new WP_Error( 'schuetzen_calendar_empty', 'Die Quelle enthält keine lesbaren Termine.' );
		}

		$result = array( 'created' => 0, 'updated' => 0, 'failed' => 0 );
		foreach ( array_slice( $events, 0, 500 ) as $event ) {
			$action = $this->upsert_event( $source, $event );
			if ( is_wp_error( $action ) ) {
				$result['failed']++;
			} elseif ( isset( $result[ $action ] ) ) {
				$result[ $action ]++;
			}
		}

		return $result;
	}

	private function fetch_calendar( $url ) {
		$response = $this->fetch_url( $url );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( false !== stripos( $response, 'BEGIN:VCALENDAR' ) ) {
			return $response;
		}

		if ( preg_match_all( '/<link\b[^>]*>/i', $response, $links ) ) {
			foreach ( $links[0] as $link ) {
				if ( ! preg_match( '/\btype=["\']text\/calendar["\']/i', $link ) || ! preg_match( '/\bhref=["\']([^"\']+)["\']/i', $link, $href ) ) {
					continue;
				}
				$feed_url = $this->resolve_feed_url( $url, html_entity_decode( $href[1], ENT_QUOTES, 'UTF-8' ) );
				if ( ! wp_http_validate_url( $feed_url ) ) {
					continue;
				}
				$feed = $this->fetch_url( $feed_url );
				if ( ! is_wp_error( $feed ) && false !== stripos( $feed, 'BEGIN:VCALENDAR' ) ) {
					return $feed;
				}
			}
		}

		return new WP_Error( 'schuetzen_calendar_missing', 'Unter dieser URL wurde kein iCalendar-Feed gefunden.' );
	}

	private function resolve_feed_url( $page_url, $feed_url ) {
		$feed_url = trim( (string) $feed_url );
		if ( wp_http_validate_url( $feed_url ) ) {
			return $feed_url;
		}

		$base = wp_parse_url( $page_url );
		if ( empty( $base['scheme'] ) || empty( $base['host'] ) ) {
			return '';
		}
		$origin = $base['scheme'] . '://' . $base['host'] . ( isset( $base['port'] ) ? ':' . absint( $base['port'] ) : '' );
		if ( 0 === strpos( $feed_url, '//' ) ) {
			return $base['scheme'] . ':' . $feed_url;
		}
		if ( 0 === strpos( $feed_url, '/' ) ) {
			return $origin . $feed_url;
		}
		$path = $base['path'] ?? '/';
		if ( 0 === strpos( $feed_url, '?' ) ) {
			return $origin . $path . $feed_url;
		}
		$directory = trailingslashit( dirname( $path ) );
		return $origin . $directory . $feed_url;
	}

	private function fetch_url( $url ) {
		if ( ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'schuetzen_calendar_url', 'Die URL ist ungültig oder nicht öffentlich erreichbar.' );
		}
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 20,
				'redirection'         => 5,
				'limit_response_size' => 5 * MB_IN_BYTES,
				'user-agent'          => 'Schuetzen-App/' . SCHUETZEN_APP_VERSION . '; ' . home_url( '/' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'schuetzen_calendar_http', 'Die Quelle antwortet mit HTTP ' . $code . '.' );
		}
		return (string) wp_remote_retrieve_body( $response );
	}

	private function parse_calendar( $body ) {
		$lines    = preg_split( "/\r\n|\n|\r/", (string) $body );
		$unfolded = array();
		foreach ( $lines as $line ) {
			if ( isset( $line[0] ) && ( ' ' === $line[0] || "\t" === $line[0] ) && $unfolded ) {
				$unfolded[ count( $unfolded ) - 1 ] .= substr( $line, 1 );
			} else {
				$unfolded[] = $line;
			}
		}

		$events  = array();
		$current = null;
		foreach ( $unfolded as $line ) {
			if ( 'BEGIN:VEVENT' === strtoupper( trim( $line ) ) ) {
				$current = array();
				continue;
			}
			if ( 'END:VEVENT' === strtoupper( trim( $line ) ) ) {
				$event = $this->normalize_event( $current );
				if ( $event ) {
					$events[] = $event;
				}
				$current = null;
				continue;
			}
			if ( null === $current || ! preg_match( '/^([A-Z][A-Z0-9-]*)(;[^:]*)?:(.*)$/i', $line, $match ) ) {
				continue;
			}
			$current[ strtoupper( $match[1] ) ] = array(
				'params' => $match[2] ?? '',
				'value'  => $match[3],
			);
		}

		return $events;
	}

	private function normalize_event( $data ) {
		if ( ! is_array( $data ) || empty( $data['UID']['value'] ) || empty( $data['SUMMARY']['value'] ) || empty( $data['DTSTART']['value'] ) ) {
			return null;
		}
		$start = $this->parse_date( $data['DTSTART'] );
		if ( ! $start['date'] ) {
			return null;
		}
		$end = ! empty( $data['DTEND'] ) ? $this->parse_date( $data['DTEND'] ) : array( 'date' => '', 'time' => '', 'all_day' => false );
		if ( $start['all_day'] && $end['date'] ) {
			$end_date = DateTimeImmutable::createFromFormat( '!Y-m-d', $end['date'], wp_timezone() );
			$end['date'] = $end_date ? $end_date->modify( '-1 day' )->format( 'Y-m-d' ) : '';
		}

		return array(
			'uid'         => sanitize_text_field( $this->unescape( $data['UID']['value'] ) ),
			'title'       => sanitize_text_field( $this->unescape( $data['SUMMARY']['value'] ) ),
			'description' => isset( $data['DESCRIPTION']['value'] ) ? $this->unescape( $data['DESCRIPTION']['value'] ) : '',
			'date'        => $start['date'],
			'time'        => $start['time'],
			'end_date'    => $end['date'],
			'all_day'     => $start['all_day'],
			'location'    => isset( $data['LOCATION']['value'] ) ? sanitize_text_field( $this->unescape( $data['LOCATION']['value'] ) ) : '',
			'url'         => isset( $data['URL']['value'] ) ? esc_url_raw( $this->unescape( $data['URL']['value'] ) ) : '',
		);
	}

	private function parse_date( $property ) {
		$value   = trim( $property['value'] ?? '' );
		$params  = $property['params'] ?? '';
		$all_day = false !== stripos( $params, 'VALUE=DATE' ) || preg_match( '/^\d{8}$/', $value );
		if ( $all_day && preg_match( '/^(\d{4})(\d{2})(\d{2})$/', $value, $match ) ) {
			return array( 'date' => $match[1] . '-' . $match[2] . '-' . $match[3], 'time' => '', 'all_day' => true );
		}
		if ( ! preg_match( '/^(\d{8})T(\d{6})(Z)?$/', $value, $match ) ) {
			return array( 'date' => '', 'time' => '', 'all_day' => false );
		}

		$timezone = wp_timezone();
		if ( ! empty( $match[3] ) ) {
			$timezone = new DateTimeZone( 'UTC' );
		} elseif ( preg_match( '/TZID=([^;:]+)/i', $params, $timezone_match ) ) {
			try {
				$timezone = new DateTimeZone( trim( $timezone_match[1], '"' ) );
			} catch ( Exception $exception ) {
				$timezone = wp_timezone();
			}
		}
		$date = DateTimeImmutable::createFromFormat( '!Ymd\THis', $match[1] . 'T' . $match[2], $timezone );
		if ( ! $date ) {
			return array( 'date' => '', 'time' => '', 'all_day' => false );
		}
		$date = $date->setTimezone( wp_timezone() );
		return array( 'date' => $date->format( 'Y-m-d' ), 'time' => $date->format( 'H:i' ), 'all_day' => false );
	}

	private function unescape( $value ) {
		return str_replace( array( '\\n', '\\N', '\\,', '\\;', '\\\\' ), array( "\n", "\n", ',', ';', '\\' ), (string) $value );
	}

	private function upsert_event( $source, $event ) {
		$external_key = hash( 'sha256', $source['id'] . '|' . $event['uid'] );
		$existing = get_posts(
			array(
				'post_type'      => 'schuetzen_event',
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_schuetzen_event_external_key',
				'meta_value'     => $external_key,
			)
		);
		$post_data = array(
			'post_type'    => 'schuetzen_event',
			'post_title'   => $event['title'],
			'post_content' => wp_kses_post( $event['description'] ),
		);
		if ( $existing ) {
			$post_id = (int) $existing[0];
			$post_data['ID'] = $post_id;
			$result = wp_update_post( wp_slash( $post_data ), true );
			$action = 'updated';
		} else {
			$post_data['post_status'] = $source['status'];
			$result = wp_insert_post( wp_slash( $post_data ), true );
			$post_id = is_wp_error( $result ) ? 0 : (int) $result;
			$action = 'created';
		}
		if ( is_wp_error( $result ) || ! $post_id ) {
			return is_wp_error( $result ) ? $result : new WP_Error( 'schuetzen_calendar_save', 'Der Termin konnte nicht gespeichert werden.' );
		}

		$meta = array(
			'_schuetzen_event_date'         => $event['date'],
			'_schuetzen_event_time'         => $event['time'],
			'_schuetzen_event_end_date'     => $event['end_date'],
			'_schuetzen_event_all_day'      => $event['all_day'] ? '1' : '',
			'_schuetzen_event_location'     => $event['location'],
			'_schuetzen_event_category'     => $source['group'],
			'_schuetzen_event_external_key' => $external_key,
			'_schuetzen_event_external_uid' => $event['uid'],
			'_schuetzen_event_source_id'    => $source['id'],
			'_schuetzen_event_source_name'  => $source['name'],
			'_schuetzen_event_source_url'   => $event['url'] ?: $source['url'],
		);
		foreach ( $meta as $key => $value ) {
			update_post_meta( $post_id, $key, $value );
		}

		return $action;
	}

	private function save_status( $source_id, $created, $updated, $error ) {
		$status = get_option( 'schuetzen_app_calendar_status', array() );
		$status = is_array( $status ) ? $status : array();
		$status[ $source_id ] = array(
			'time'    => time(),
			'created' => absint( $created ),
			'updated' => absint( $updated ),
			'error'   => sanitize_text_field( $error ),
		);
		update_option( 'schuetzen_app_calendar_status', $status, false );
	}
}
