<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Capabilities {
	public const VIEW_INTERNAL_EVENTS = 'schuetzen_view_internal_events';
	public const VIEW_SHOOTING_RANGE = 'schuetzen_view_shooting_range_schedule';
	public const MANAGE_SHOOTING_RANGE = 'schuetzen_manage_shooting_range_schedule';

	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'ensure_roles' ), 2 );
	}

	public static function definitions() {
		return array(
			self::VIEW_INTERNAL_EVENTS => array(
				'label'       => 'Interne Termine sehen',
				'description' => 'Termine, die nur für Vereinsmitglieder bestimmt sind.',
			),
			self::VIEW_SHOOTING_RANGE => array(
				'label'       => 'Schießstandbelegung sehen',
				'description' => 'Nicht öffentliche Termine und Belegungen des Schießstands.',
			),
			self::MANAGE_SHOOTING_RANGE => array(
				'label'       => 'Schießstandbelegung verwalten',
				'description' => 'Für eine spätere Bearbeitungsfunktion innerhalb der App vorbereitet.',
			),
		);
	}

	public static function default_role_map() {
		return array(
			self::VIEW_INTERNAL_EVENTS => array(),
			self::VIEW_SHOOTING_RANGE => array( 'schuetzen_shooting_leader' ),
			self::MANAGE_SHOOTING_RANGE => array( 'schuetzen_shooting_leader' ),
		);
	}

	public function ensure_roles() {
		add_role( 'schuetzen_member', 'Schütze', array( 'read' => true ) );
		add_role(
			'schuetzen_shooting_leader',
			'Schießleiter',
			array(
				'read'                       => true,
				self::VIEW_SHOOTING_RANGE    => true,
				self::MANAGE_SHOOTING_RANGE  => true,
			)
		);

		$administrator = get_role( 'administrator' );
		if ( $administrator ) {
			foreach ( array_keys( self::definitions() ) as $capability ) {
				$administrator->add_cap( $capability );
			}
		}
	}

	public static function editable_roles() {
		$roles = wp_roles()->roles;
		unset( $roles['administrator'] );
		return $roles;
	}

	public static function sanitize_role_map( $input ) {
		$input = is_array( $input ) ? $input : array();
		$roles = self::editable_roles();
		$output = array();
		foreach ( array_keys( self::definitions() ) as $capability ) {
			$output[ $capability ] = array_values(
				array_filter(
					array_map( 'sanitize_key', (array) ( $input[ $capability ] ?? array() ) ),
					static function ( $role ) use ( $roles ) {
						return isset( $roles[ $role ] );
					}
				)
			);
		}
		return $output;
	}

	public static function sync_role_map( $map ) {
		$map = self::sanitize_role_map( $map );
		foreach ( self::editable_roles() as $role_slug => $role_data ) {
			$role = get_role( $role_slug );
			if ( ! $role ) {
				continue;
			}
			foreach ( array_keys( self::definitions() ) as $capability ) {
				$role->remove_cap( $capability );
				if ( in_array( $role_slug, $map[ $capability ], true ) ) {
					$role->add_cap( $capability );
				}
			}
		}
	}

	public static function can( $capability, $user_id = 0 ) {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		return $user_id ? user_can( $user_id, $capability ) : current_user_can( $capability );
	}

	public static function event_visibility_options() {
		return array(
			'public' => 'Öffentlich',
			'internal' => 'Nur mit Fähigkeit „Interne Termine sehen“',
			'shooting_range' => 'Nur mit Fähigkeit „Schießstandbelegung sehen“',
		);
	}

	public static function event_capability( $visibility ) {
		$map = array(
			'internal'       => self::VIEW_INTERNAL_EVENTS,
			'shooting_range' => self::VIEW_SHOOTING_RANGE,
		);
		return $map[ $visibility ] ?? '';
	}
}
