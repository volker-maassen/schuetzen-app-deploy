<?php
/**
 * Plugin Name: Schützen-App
 * Description: Schlanke Vereins-App für Termine, Nachrichten und Informationen.
 * Version: 2.21.6
 * Author: Volker Maaßen
 * Text Domain: schuetzen-app
 * Update URI: https://www.maassen.de/my-plugins/schuetzen-app
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

defined( 'ABSPATH' ) || exit;

define( 'SCHUETZEN_APP_VERSION', '2.21.6' );
define( 'SCHUETZEN_APP_FILE', __FILE__ );

require_once __DIR__ . '/includes/class-schuetzen-app-updater.php';
require_once __DIR__ . '/includes/class-schuetzen-app-groups.php';
require_once __DIR__ . '/includes/class-schuetzen-app-rest.php';
require_once __DIR__ . '/includes/class-schuetzen-app-frontend.php';
require_once __DIR__ . '/includes/class-schuetzen-app-content.php';
require_once __DIR__ . '/includes/class-schuetzen-app-settings.php';
require_once __DIR__ . '/includes/class-schuetzen-app-calendar-sources.php';
require_once __DIR__ . '/includes/class-schuetzen-app-admin-access.php';

function schuetzen_app_remove_legacy_mail_data() {
	if ( version_compare( (string) get_option( 'schuetzen_app_mail_cleanup_version', '0' ), '2.16.0', '>=' ) ) {
		return;
	}

	wp_clear_scheduled_hook( 'schuetzen_app_import_mail' );
	delete_option( 'schuetzen_app_import_log' );

	$settings = get_option( 'schuetzen_app_settings', array() );
	if ( is_array( $settings ) ) {
		$mail_keys = array(
			'email_events',
			'email_messages',
			'email_info',
			'whitelist',
			'imap_host',
			'imap_port',
			'imap_user',
			'imap_password',
			'imap_events_user',
			'imap_events_password',
			'imap_messages_user',
			'imap_messages_password',
			'imap_info_user',
			'imap_info_password',
			'max_image_mb',
		);

		foreach ( $mail_keys as $key ) {
			unset( $settings[ $key ] );
		}

		update_option( 'schuetzen_app_settings', $settings, false );
	}

	update_option( 'schuetzen_app_mail_cleanup_version', '2.16.0', false );
}
add_action( 'plugins_loaded', 'schuetzen_app_remove_legacy_mail_data', 1 );

new Schuetzen_App_Updater(
	SCHUETZEN_APP_FILE,
	SCHUETZEN_APP_VERSION,
	'https://raw.githubusercontent.com/volker-maassen/schuetzen-app-deploy/main/schuetzen-app/update.json'
);

new Schuetzen_App_REST();
new Schuetzen_App_Frontend();
new Schuetzen_App_Content();
new Schuetzen_App_Settings();
new Schuetzen_App_Calendar_Sources();
new Schuetzen_App_Admin_Access();

register_deactivation_hook( SCHUETZEN_APP_FILE, array( 'Schuetzen_App_Calendar_Sources', 'deactivate' ) );
