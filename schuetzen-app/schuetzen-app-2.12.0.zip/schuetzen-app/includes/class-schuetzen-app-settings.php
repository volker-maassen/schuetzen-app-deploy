<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Settings {
	private $option_name = 'schuetzen_app_settings';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	public function add_menu() {
		add_menu_page( 'Schützen-App', 'Schützen-App', 'manage_options', 'schuetzen-app', array( $this, 'render_page' ), 'dashicons-smartphone', 26 );
	}

	public function register_settings() {
		register_setting( 'schuetzen_app_settings_group', $this->option_name, array( $this, 'sanitize_settings' ) );
	}

	public function sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();
		$colors = array( 'background_start', 'background_end', 'green', 'green_dark', 'gold', 'cream', 'paper', 'ink', 'muted', 'header', 'footer', 'zug', 'korps', 'regiment' );
		$output = array(
			'brand_line_1'   => sanitize_text_field( $input['brand_line_1'] ?? '' ),
			'brand_line_2'   => sanitize_text_field( $input['brand_line_2'] ?? '' ),
			'email_events'   => sanitize_email( $input['email_events'] ?? '' ),
			'email_messages' => sanitize_email( $input['email_messages'] ?? '' ),
			'email_info'     => sanitize_email( $input['email_info'] ?? '' ),
			'whitelist'      => implode( "\n", array_filter( array_map( 'sanitize_email', preg_split( '/\r\n|\r|\n/', $input['whitelist'] ?? '' ) ) ) ),
			'imap_host'     => sanitize_text_field( $input['imap_host'] ?? '' ),
			'imap_port'     => absint( $input['imap_port'] ?? 993 ),
			'imap_user'     => sanitize_text_field( $input['imap_user'] ?? '' ),
			'imap_password' => sanitize_text_field( $input['imap_password'] ?? '' ),
			'imap_events_user' => sanitize_text_field( $input['imap_events_user'] ?? '' ),
			'imap_events_password' => sanitize_text_field( $input['imap_events_password'] ?? '' ),
			'imap_messages_user' => sanitize_text_field( $input['imap_messages_user'] ?? '' ),
			'imap_messages_password' => sanitize_text_field( $input['imap_messages_password'] ?? '' ),
			'imap_info_user' => sanitize_text_field( $input['imap_info_user'] ?? '' ),
			'imap_info_password' => sanitize_text_field( $input['imap_info_password'] ?? '' ),
			'max_image_mb'  => min( 20, max( 1, absint( $input['max_image_mb'] ?? 5 ) ) ),
		);
		foreach ( $colors as $color ) {
			$value = sanitize_hex_color( $input[ 'color_' . $color ] ?? '' );
			$output[ 'color_' . $color ] = $value ?: '';
			$default_opacity = ( 'background_end' === $color ) ? ( $input['background_end_opacity'] ?? 100 ) : 100;
			$output[ 'color_' . $color . '_opacity' ] = min( 100, max( 0, absint( $input[ 'color_' . $color . '_opacity' ] ?? $default_opacity ) ) );
		}
		return $output;
	}

	public function render_page() {
		$settings = get_option( $this->option_name, array() );
		$import_log = get_option( 'schuetzen_app_import_log', array() );
		$fields = array(
			'email_events'   => 'Termine',
			'email_messages' => 'Nachrichten',
			'email_info'     => 'Infos',
		);
		$colors = array(
			'background_start' => 'Verlaufsfarbe oben',
			'background_end'   => 'Verlaufsfarbe unten',
			'green'      => 'Hauptfarbe',
			'green_dark' => 'Dunkle Hauptfarbe',
			'gold'       => 'Akzentfarbe',
			'cream'      => 'App-Hintergrund',
			'paper'      => 'Card-Hintergrund',
			'ink'        => 'Textfarbe',
			'muted'      => 'Gedämpfte Textfarbe',
			'header'     => 'Header-Hintergrund',
			'footer'     => 'Footer-Hintergrund',
			'zug'        => 'Zugfarbe',
			'korps'      => 'Korpsfarbe',
			'regiment'   => 'Regimentsfarbe',
		);
		$color_defaults = array(
			'background_start' => '#f7f4ec',
			'background_end'   => '#e9e5db',
			'green'      => '#1e4d3a',
			'green_dark' => '#123326',
			'gold'       => '#d6a84f',
			'cream'      => '#f7f4ec',
			'paper'      => '#fffdf8',
			'ink'        => '#1f2824',
			'muted'      => '#69736d',
			'header'     => '#f7f4ec',
			'footer'     => '#fffdf8',
			'zug'        => '#d6a84f',
			'korps'      => '#008037',
			'regiment'   => '#D2071F',
		);
		?>
		<div class="wrap">
			<h1>Schützen-App</h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'schuetzen_app_settings_group' ); ?>
				<h2>Kopfzeile</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="schuetzen_app_brand_line_1">Erste Zeile</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_1" name="<?php echo esc_attr( $this->option_name . '[brand_line_1]' ); ?>" value="<?php echo esc_attr( $settings['brand_line_1'] ?? 'ST. HUBERTUS' ); ?>"></td></tr>
					<tr><th scope="row"><label for="schuetzen_app_brand_line_2">Zweite Zeile</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_2" name="<?php echo esc_attr( $this->option_name . '[brand_line_2]' ); ?>" value="<?php echo esc_attr( $settings['brand_line_2'] ?? 'Fahnenzug' ); ?>"></td></tr>
				</table>
				<p class="description">Icon und Begrüßungstext der App werden aus den allgemeinen WordPress-Einstellungen übernommen.</p>
				<h2>Mailimport testen</h2>
				<p><a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=schuetzen_app_import_now' ), 'schuetzen_app_import_now' ) ); ?>">Mailimport jetzt ausführen</a></p>
				<?php if ( ! empty( $import_log ) ) : ?><pre style="max-width:760px; padding:12px; background:#fff; border:1px solid #ccd0d4; white-space:pre-wrap;"><?php echo esc_textarea( implode( "\n", $import_log ) ); ?></pre><?php endif; ?>
				<h2>Mail-Eingang</h2>
				<p>Die Adressen werden für den späteren automatischen Import verwendet.</p>
				<table class="form-table" role="presentation">
					<?php foreach ( $fields as $key => $label ) : ?>
						<tr><th scope="row"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th><td><input type="email" class="regular-text" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $this->option_name . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $settings[ $key ] ?? '' ); ?>"></td></tr>
					<?php endforeach; ?>
				</table>
				<table class="form-table" role="presentation"><tr><th scope="row"><label for="schuetzen_app_whitelist">Berechtigte Absender</label></th><td><textarea class="large-text" rows="6" id="schuetzen_app_whitelist" name="<?php echo esc_attr( $this->option_name . '[whitelist]' ); ?>"><?php echo esc_textarea( $settings['whitelist'] ?? '' ); ?></textarea><p class="description">Eine Mailadresse pro Zeile. Nur diese Absender dürfen Inhalte einstellen.</p></td></tr></table>
				<table class="form-table" role="presentation"><tr><th scope="row"><label for="schuetzen_app_max_image_mb">Maximale Bildgröße</label></th><td><input type="number" min="1" max="20" class="small-text" id="schuetzen_app_max_image_mb" name="<?php echo esc_attr( $this->option_name . '[max_image_mb]' ); ?>" value="<?php echo esc_attr( $settings['max_image_mb'] ?? 5 ); ?>"> MB<p class="description">Größere Bildanhänge werden beim Mailimport abgewiesen. Erlaubt sind 1 bis 20 MB.</p></td></tr></table>
				<h2>Struktur der Mailinhalte</h2>
				<div style="max-width: 760px; padding: 16px; background: #fff; border-left: 4px solid #1e4d3a;">
					<p><strong>Nachrichten</strong><br>Betreff = Überschrift. Der Mailtext wird als kurze Einleitung und vollständiger Inhalt übernommen. Das erste Bild im Anhang wird als Beitragsbild verwendet.</p>
					<pre style="white-space: pre-wrap;">Betreff: Neuer Treffpunkt

Wir treffen uns am Samstag um 16:00 Uhr am Vereinsheim.</pre>
					<p><strong>Termine</strong><br>Termine werden ausschließlich als Kalenderdatei (<code>.ics</code>) verarbeitet. Normale Text-Mails ohne <code>.ics</code>-Anhang werden ignoriert.</p>
					<p><strong>Termin aus dem iPhone-Kalender</strong><br>Den einzelnen Kalendereintrag als Einladung per E-Mail an die hinterlegte Termine-Adresse senden. Die App übernimmt Titel, Beschreibung, Beginn, Ende und Ort. Die Kalender-UID sorgt dafür, dass ein erneut gesendeter geänderter Termin aktualisiert wird.</p>
					<pre style="white-space: pre-wrap;">Apple Kalender → Termin teilen/exportieren → Mail
Empfänger: die hinterlegte Termine-Adresse
Anhang: Kalenderdatei (.ics)</pre>
					<p><strong>Infos</strong><br>Für die Filterung kann zusätzlich eine Kategorie angegeben werden:</p>
					<pre style="white-space: pre-wrap;">Betreff: Marschordnung

Kategorie: Zug

Die Marschordnung für unser Schützenfest.</pre>
				</div>
				<h2>App-Farben</h2>
				<h2>IMAP-Verbindung</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="schuetzen_app_imap_host">Mailserver</label></th><td><input type="text" class="regular-text" id="schuetzen_app_imap_host" name="<?php echo esc_attr( $this->option_name . '[imap_host]' ); ?>" value="<?php echo esc_attr( $settings['imap_host'] ?? 'mail.hubertus-fahnenzug.de' ); ?>"></td></tr>
					<tr><th scope="row"><label for="schuetzen_app_imap_port">Port</label></th><td><input type="number" class="small-text" id="schuetzen_app_imap_port" name="<?php echo esc_attr( $this->option_name . '[imap_port]' ); ?>" value="<?php echo esc_attr( $settings['imap_port'] ?? 993 ); ?>"><p class="description">SSL/TLS wird verwendet.</p></td></tr>
					<?php foreach ( array( 'events' => 'Termine', 'messages' => 'Nachrichten', 'info' => 'Infos' ) as $mail_key => $mail_label ) : ?>
					<tr><th scope="row"><?php echo esc_html( $mail_label ); ?> – Benutzer</th><td><input type="text" class="regular-text" name="<?php echo esc_attr( $this->option_name . '[imap_' . $mail_key . '_user]' ); ?>" value="<?php echo esc_attr( $settings[ 'imap_' . $mail_key . '_user' ] ?? '' ); ?>"></td></tr>
					<tr><th scope="row"><?php echo esc_html( $mail_label ); ?> – Passwort</th><td><input type="password" class="regular-text" name="<?php echo esc_attr( $this->option_name . '[imap_' . $mail_key . '_password]' ); ?>" value="<?php echo esc_attr( $settings[ 'imap_' . $mail_key . '_password' ] ?? '' ); ?>"></td></tr>
					<?php endforeach; ?>
				</table>
				<table class="form-table" role="presentation">
					<?php foreach ( $colors as $key => $label ) : ?>
						<?php $opacity = $settings[ 'color_' . $key . '_opacity' ] ?? ( 'background_end' === $key ? ( $settings['background_end_opacity'] ?? 100 ) : 100 ); ?>
						<tr><th scope="row"><label for="schuetzen_app_color_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th><td><input type="color" id="schuetzen_app_color_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $this->option_name . '[color_' . $key . ']' ); ?>" value="<?php echo esc_attr( $settings[ 'color_' . $key ] ?? $settings[ $key ] ?? $color_defaults[ $key ] ); ?>"> <label for="schuetzen_app_color_<?php echo esc_attr( $key ); ?>_opacity">Deckkraft</label> <input type="range" min="0" max="100" step="1" id="schuetzen_app_color_<?php echo esc_attr( $key ); ?>_opacity" name="<?php echo esc_attr( $this->option_name . '[color_' . $key . '_opacity]' ); ?>" value="<?php echo esc_attr( $opacity ); ?>" oninput="this.nextElementSibling.value = this.value + '%'"> <output><?php echo esc_html( $opacity . '%' ); ?></output></td></tr>
					<?php endforeach; ?>
				</table>
				<?php submit_button( 'Einstellungen speichern' ); ?>
			</form>
		</div>
		<?php
	}
}
