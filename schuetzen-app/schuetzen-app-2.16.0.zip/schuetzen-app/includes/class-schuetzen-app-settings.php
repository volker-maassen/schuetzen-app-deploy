<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Settings {
	private $option_name = 'schuetzen_app_settings';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	public function add_menu() {
		add_menu_page( 'Schützen-App', 'Schützen-App', 'manage_options', 'schuetzen-app', array( $this, 'render_page' ), 'dashicons-smartphone', 26 );
	}

	public function register_settings() {
		register_setting( 'schuetzen_app_settings_group', $this->option_name, array( $this, 'sanitize_settings' ) );
	}

	public function sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();
		$colors = array( 'background_start', 'background_end', 'green', 'green_dark', 'gold', 'cream', 'paper', 'ink', 'muted', 'header', 'footer', 'zug', 'korps', 'regiment' );
		$output = array(
			'brand_line_1'   => sanitize_text_field( $input['brand_line_1'] ?? '' ),
			'brand_line_2'   => sanitize_text_field( $input['brand_line_2'] ?? '' ),
			'background_events' => esc_url_raw( $input['background_events'] ?? '' ),
			'background_messages' => esc_url_raw( $input['background_messages'] ?? '' ),
			'background_info' => esc_url_raw( $input['background_info'] ?? '' ),
		);
		foreach ( $colors as $color ) {
			$value = sanitize_hex_color( $input[ 'color_' . $color ] ?? '' );
			$output[ 'color_' . $color ] = $value ?: '';
			$default_opacity = ( 'background_end' === $color ) ? ( $input['background_end_opacity'] ?? 100 ) : 100;
			$output[ 'color_' . $color . '_opacity' ] = min( 100, max( 0, absint( $input[ 'color_' . $color . '_opacity' ] ?? $default_opacity ) ) );
		}
		return $output;
	}

	public function render_page() {
		wp_enqueue_media();
		$settings = get_option( $this->option_name, array() );
		$section_backgrounds = array(
			'background_events' => 'Termine',
			'background_messages' => 'Nachrichten',
			'background_info' => 'Infos',
		);
		$colors = array(
			'background_start' => 'Verlaufsfarbe oben',
			'background_end'   => 'Verlaufsfarbe unten',
			'green'      => 'Hauptfarbe',
			'green_dark' => 'Dunkle Hauptfarbe',
			'gold'       => 'Akzentfarbe',
			'cream'      => 'App-Hintergrund',
			'paper'      => 'Card-Hintergrund',
			'ink'        => 'Textfarbe',
			'muted'      => 'Gedämpfte Textfarbe',
			'header'     => 'Header-Hintergrund',
			'footer'     => 'Footer-Hintergrund',
			'zug'        => 'Zugfarbe',
			'korps'      => 'Korpsfarbe',
			'regiment'   => 'Regimentsfarbe',
		);
		$color_defaults = array(
			'background_start' => '#f7f4ec',
			'background_end'   => '#e9e5db',
			'green'      => '#1e4d3a',
			'green_dark' => '#123326',
			'gold'       => '#d6a84f',
			'cream'      => '#f7f4ec',
			'paper'      => '#fffdf8',
			'ink'        => '#1f2824',
			'muted'      => '#69736d',
			'header'     => '#f7f4ec',
			'footer'     => '#fffdf8',
			'zug'        => '#d6a84f',
			'korps'      => '#008037',
			'regiment'   => '#D2071F',
		);
		?>
		<div class="wrap schuetzen-app-settings">
			<h1>Schützen-App</h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'schuetzen_app_settings_group' ); ?>
				<nav class="nav-tab-wrapper" aria-label="Schützen-App Einstellungen">
					<button type="button" class="nav-tab nav-tab-active" data-schuetzen-tab="design">Design</button>
					<button type="button" class="nav-tab" data-schuetzen-tab="help">Hilfe</button>
				</nav>

				<section data-schuetzen-panel="design">
					<h2>Kopfzeile</h2>
					<table class="form-table" role="presentation">
						<tr><th scope="row"><label for="schuetzen_app_brand_line_1">Erste Zeile</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_1" name="<?php echo esc_attr( $this->option_name . '[brand_line_1]' ); ?>" value="<?php echo esc_attr( $settings['brand_line_1'] ?? '' ); ?>"></td></tr>
						<tr><th scope="row"><label for="schuetzen_app_brand_line_2">Zweite Zeile</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_2" name="<?php echo esc_attr( $this->option_name . '[brand_line_2]' ); ?>" value="<?php echo esc_attr( $settings['brand_line_2'] ?? '' ); ?>"></td></tr>
					</table>
					<p class="description">Icon und Begrüßungstext der App werden aus den allgemeinen WordPress-Einstellungen übernommen.</p>

					<h2>Bereichs-Hintergrundbilder</h2>
					<p class="description">Die Bilder erscheinen als dezenter Hintergrund im jeweiligen Hauptbereich der App.</p>
					<table class="form-table" role="presentation">
						<?php foreach ( $section_backgrounds as $key => $label ) : ?>
							<tr>
								<th scope="row"><label for="schuetzen_app_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
								<td>
									<input type="url" class="regular-text" id="schuetzen_app_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $this->option_name . '[' . $key . ']' ); ?>" value="<?php echo esc_url( $settings[ $key ] ?? '' ); ?>" data-schuetzen-media-field>
									<button type="button" class="button" data-schuetzen-media-button="<?php echo esc_attr( $key ); ?>">Bild auswählen</button>
									<?php if ( ! empty( $settings[ $key ] ) ) : ?><button type="button" class="button-link-delete" data-schuetzen-media-clear="<?php echo esc_attr( $key ); ?>">Bild entfernen</button><?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>

					<h2>App-Farben</h2>
					<table class="form-table" role="presentation">
						<?php foreach ( $colors as $key => $label ) : ?>
							<?php $opacity = $settings[ 'color_' . $key . '_opacity' ] ?? ( 'background_end' === $key ? ( $settings['background_end_opacity'] ?? 100 ) : 100 ); ?>
							<tr><th scope="row"><label for="schuetzen_app_color_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th><td><input type="color" id="schuetzen_app_color_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $this->option_name . '[color_' . $key . ']' ); ?>" value="<?php echo esc_attr( $settings[ 'color_' . $key ] ?? $settings[ $key ] ?? $color_defaults[ $key ] ); ?>"> <label for="schuetzen_app_color_<?php echo esc_attr( $key ); ?>_opacity">Deckkraft</label> <input type="range" min="0" max="100" step="1" id="schuetzen_app_color_<?php echo esc_attr( $key ); ?>_opacity" name="<?php echo esc_attr( $this->option_name . '[color_' . $key . '_opacity]' ); ?>" value="<?php echo esc_attr( $opacity ); ?>" oninput="this.nextElementSibling.value = this.value + '%'"> <output><?php echo esc_html( $opacity . '%' ); ?></output></td></tr>
						<?php endforeach; ?>
					</table>
				</section>

				<section data-schuetzen-panel="help" hidden>
					<h2>Inhalte pflegen</h2>
					<div style="max-width: 760px; padding: 16px; background: #fff; border-left: 4px solid #1e4d3a;">
						<p><strong>Termine</strong><br>Datum, Uhrzeit, Ort, Treffpunkt und Zuordnung werden direkt beim Termin gepflegt. Ein Termin ohne Uhrzeit dient als Tageskarte für weitere Termine desselben Tages.</p>
						<p><strong>Nachrichten und Infos</strong><br>Die Inhalte werden über die jeweiligen Menüpunkte angelegt. Die Zuordnung zu Zug, Korps oder Regiment bestimmt die farbliche Kennzeichnung in der App.</p>
						<p><strong>Personen und Marschordnungen</strong><br>Personen werden einmalig angelegt und können anschließend in den Marschordnungen verwendet werden. Eine Marschordnung lässt sich einem Termin zuweisen.</p>
					</div>
				</section>

				<?php submit_button( 'Einstellungen speichern' ); ?>
			</form>
		</div>
		<script>
		(function () {
			var tabs = document.querySelectorAll('[data-schuetzen-tab]');
			var panels = document.querySelectorAll('[data-schuetzen-panel]');
			tabs.forEach(function (tab) {
				tab.addEventListener('click', function () {
					tabs.forEach(function (item) { item.classList.toggle('nav-tab-active', item === tab); });
					panels.forEach(function (panel) { panel.hidden = panel.getAttribute('data-schuetzen-panel') !== tab.getAttribute('data-schuetzen-tab'); });
				});
			});
			document.querySelectorAll('[data-schuetzen-media-button]').forEach(function (button) {
				button.addEventListener('click', function () {
					var key = button.getAttribute('data-schuetzen-media-button');
					var field = document.getElementById('schuetzen_app_' + key);
					var frame = wp.media({ title: 'Bild für ' + key + ' auswählen', button: { text: 'Bild übernehmen' }, multiple: false });
					frame.on('select', function () { var attachment = frame.state().get('selection').first().toJSON(); field.value = attachment.url; });
					frame.open();
				});
			});
			document.querySelectorAll('[data-schuetzen-media-clear]').forEach(function (button) {
				button.addEventListener('click', function () { document.getElementById('schuetzen_app_' + button.getAttribute('data-schuetzen-media-clear')).value = ''; button.remove(); });
			});
		}());
		</script>
		<?php
	}
}
