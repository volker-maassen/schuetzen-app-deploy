(function () {
	'use strict';

	var root = document.getElementById('schuetzen-app');
	var config = window.SchuetzenAppConfig || {};
	var currentView = { section: 0, category: '', detailId: null };
	var activeHeader = null;
	var lastScrollY = window.scrollY;

if (!root) {
    return;
}

window.addEventListener('scroll', function () {
		var currentScrollY = window.scrollY;
		if (activeHeader) {
			activeHeader.classList.toggle('is-scrolling-up', currentScrollY > 0 && currentScrollY < lastScrollY);
		}
		lastScrollY = currentScrollY;
	}, { passive: true });

function requestPortrait() {
    if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('portrait').catch(function () {
            // Einige Browser erlauben die Sperre nur im installierten App-Modus.
        });
    }
}

requestPortrait();
document.addEventListener('click', requestPortrait, { once: true });

	function escapeHtml(value) {
		return String(value || '').replace(/[&<>'"]/g, function (character) {
			return {
				'&': '&amp;',
				'<': '&lt;',
				'>': '&gt;',
				"'": '&#039;',
				'"': '&quot;'
			}[character];
		});
	}

	function formatDate(value) {
		var parts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || '');
		if (!parts) {
			return value || '';
		}

		var date = new Date(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3]));
		return new Intl.DateTimeFormat('de-DE', {
			weekday: 'long',
			day: '2-digit',
			month: 'long',
			year: 'numeric'
		}).format(date);
	}

	function parseDate(value) {
		var parts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || '');
		return parts ? new Date(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3])) : null;
	}

	function dateBadge(value) {
		var date = parseDate(value);
		if (!date) {
			return '';
		}
		return '<span class="schuetzen-app__date-badge"><strong>' +
			escapeHtml(new Intl.DateTimeFormat('de-DE', { day: '2-digit' }).format(date)) +
			'</strong><small>' + escapeHtml(new Intl.DateTimeFormat('de-DE', { month: 'short' }).format(date).replace('.', '').toUpperCase()) + '</small></span>';
	}

	function weekKey(value) {
		var date = parseDate(value);
		if (!date) {
			return 'Weitere Termine';
		}
		var firstDay = new Date(date.getFullYear(), 0, 1);
		var week = Math.ceil((((date - firstDay) / 86400000) + firstDay.getDay() + 1) / 7);
		return 'Woche ' + week;
	}

	function excerpt(value) {
		var text = String(value || '').replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
		return text.length > 50 ? text.slice(0, 50).trim() + '...' : text;
	}

	function eventMeta(entry) {
		var html = '';
		if (entry.time) {
			html += '<span><img src="' + escapeHtml((config.iconBase || '') + 'clock-regular.svg') + '" alt="" aria-hidden="true">' + escapeHtml(entry.time) + ' Uhr</span>';
		}
		if (entry.location) {
			html += '<span><img src="' + escapeHtml((config.iconBase || '') + 'map-regular.svg') + '" alt="" aria-hidden="true">' + escapeHtml(entry.location) + '</span>';
		}
		return html;
	}

	function filterCurrentEvents(events) {
		var today = new Date();
		var todayKey = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
		return (events || []).filter(function (event) { return !event.date || event.date >= todayKey; });
	}

	function showDetail(content, entry, section) {
		currentView = { section: section, category: '', detailId: entry.id };
		var meta = section === 0 ? eventMeta(entry) : formatDate(entry.date);
		content.innerHTML = '<article class="schuetzen-app__detail"><div class="schuetzen-app__detail-background"' + (entry.image ? ' style="background-image: url(&quot;' + escapeHtml(entry.image) + '&quot;)"' : '') + '></div><div class="schuetzen-app__detail-content"><h2>' + escapeHtml(entry.title) + '</h2>' +
			(section === 0 ? '<p class="schuetzen-app__event-meta">' + meta + '</p>' : '') + (entry.description || '') + '</div></article>';
	}

	function render(data) {
		data.events = filterCurrentEvents(data.events);
		window.SchuetzenAppData = data;
		root.innerHTML = '';

		var header = document.createElement('header');
		header.className = 'schuetzen-app__topbar';
		activeHeader = header;
		header.innerHTML = '<img class="schuetzen-app__logo" src="' + escapeHtml(config.iconUrl || '') + '" alt="" />' +
			'<span class="schuetzen-app__brand"><small>' + escapeHtml(config.brandLine1 || '') + '</small><strong>' + escapeHtml(config.brandLine2 || '') + '</strong></span>';
		root.appendChild(header);

		var hero = document.createElement('section');
		hero.className = 'schuetzen-app__hero';
		hero.innerHTML = '<p class="schuetzen-app__eyebrow">Willkommen</p>' +
			'<h1>' + escapeHtml(data.app_name || config.appName || 'Schützen-App') + '</h1>' +
			'<p class="schuetzen-app__subtitle">' + escapeHtml(data.app_description || '') + '</p>';
		root.appendChild(hero);

		var filters = document.createElement('div');
		filters.className = 'schuetzen-app__filters';
		filters.hidden = true;
		if ( 2 === currentView.section && ! currentView.category ) {
			currentView.category = 'zug';
		}
		[['Zug', 'zug'], ['Korps', 'korps'], ['Regiment', 'regiment'], ['Alle', '']].forEach(function (item, index) {
			var filter = document.createElement('button');
			filter.type = 'button';
			filter.textContent = item[0];
			filter.dataset.category = item[1];
			filter.setAttribute('aria-pressed', item[1] === currentView.category ? 'true' : 'false');
				filter.addEventListener('click', function () {
					currentView.category = item[1];
				filters.querySelectorAll('button').forEach(function (button) { button.setAttribute('aria-pressed', button === filter ? 'true' : 'false'); });
				navButtons[2].click();
				renderSection(content, 2, data, item[1]);
			});
			filters.appendChild(filter);
		});
		root.appendChild(filters);

		var nav = document.createElement('nav');
		nav.className = 'schuetzen-app__nav';
		nav.setAttribute('aria-label', 'App-Navigation');
		var content = document.createElement('main');
		content.className = 'schuetzen-app__content';
		var navButtons = [];

		[['Termine', 'calendar-alt-regular.svg'], ['Nachrichten', 'paper-plane-regular.svg'], ['Infos', 'lightbulb-regular.svg']].forEach(function (item, index) {
			var label = item[0];
			var button = document.createElement('button');
			button.type = 'button';
			button.innerHTML = '<img src="' + escapeHtml((config.iconBase || '') + item[1]) + '" alt="" aria-hidden="true"><span>' + escapeHtml(label) + '</span>';
			button.setAttribute('aria-current', index === 0 ? 'page' : 'false');
			button.addEventListener('click', function () {
				currentView = { section: index, category: index === 2 ? (currentView.category || 'zug') : '', detailId: null };
				filters.hidden = index !== 2;
				filters.querySelectorAll('button').forEach(function (filterButton) {
					filterButton.setAttribute('aria-pressed', filterButton.dataset.category === currentView.category ? 'true' : 'false');
				});
				nav.querySelectorAll('button').forEach(function (navButton) {
					navButton.setAttribute('aria-current', navButton === button ? 'page' : 'false');
				});
				renderSection(content, index, data, currentView.category);
			});
			nav.appendChild(button);
			navButtons.push(button);
		});
		root.appendChild(nav);
		root.appendChild(content);
		if (currentView.detailId !== null) {
			var detailEntries = currentView.section === 0 ? data.events : (currentView.section === 1 ? data.messages : data.info);
			var detailEntry = detailEntries.find(function (entry) { return String(entry.id) === String(currentView.detailId); });
			if (detailEntry) {
				showDetail(content, detailEntry, currentView.section);
			} else {
				currentView.detailId = null;
				renderSection(content, currentView.section, data, currentView.category);
			}
		} else {
			renderSection(content, currentView.section, data, currentView.category);
		}
		filters.hidden = currentView.section !== 2 || currentView.detailId !== null;
		navButtons.forEach(function (button, index) {
			button.setAttribute('aria-current', index === currentView.section ? 'page' : 'false');
		});
	}

	function renderSection(content, section, data, infoCategory) {
		if (section === 0) {
			if (!data.events || !data.events.length) {
				content.innerHTML = '<h2>Termine</h2><p class="schuetzen-app__empty">Noch keine Termine vorhanden.</p>';
				return;
			}

			var grouped = {};
			data.events.forEach(function (event) {
				var key = weekKey(event.date);
				grouped[key] = grouped[key] || [];
				grouped[key].push(event);
			});
			content.innerHTML = '<h2>Termine</h2>' + Object.keys(grouped).map(function (key) {
				return '<h3 class="schuetzen-app__week">' + escapeHtml(key) + '</h3>' + grouped[key].map(function (event) {
					var meta = eventMeta(event);
					return '<article tabindex="0" role="button" class="schuetzen-app__event"><div class="schuetzen-app__event-date">' + (event.image ? '<span class="schuetzen-app__date-image" style="background-image:url(&quot;' + escapeHtml(event.image) + '&quot;)">' + dateBadge(event.date) + '</span>' : dateBadge(event.date)) + '</div><div class="schuetzen-app__event-body"><h3>' + escapeHtml(event.title) + '</h3>' +
						'<p class="schuetzen-app__event-day">' + escapeHtml(formatDate(event.date)) + '</p>' +
						(meta ? '<p class="schuetzen-app__event-meta">' + meta + '</p>' : '') +
						'' + '</div></article>';
				}).join('');
			}).join('');
			content.querySelectorAll('.schuetzen-app__event').forEach(function (card, index) {
				card.addEventListener('click', function () { showDetail(content, data.events[index], 0); });
			});
			return;
		}

		var title = section === 1 ? 'Nachrichten' : 'Infos';
		var entries = section === 1 ? data.messages : data.info.filter(function (entry) { return !infoCategory || entry.category === infoCategory; });

		if (!entries || !entries.length) {
			content.innerHTML = '<h2>' + title + '</h2><p class="schuetzen-app__empty">Noch keine Inhalte vorhanden.</p>';
			return;
		}

		content.innerHTML = '<h2>' + title + '</h2>' + entries.map(function (entry) {
			entry.type = section === 1 ? 'message' : 'info';
			return '<article tabindex="0" role="button" class="schuetzen-app__event"><div class="schuetzen-app__event-body"><h3>' + escapeHtml(entry.title) + '</h3>' +
				(section === 1 && excerpt(entry.description) ? '<p class="schuetzen-app__event-excerpt">' + escapeHtml(excerpt(entry.description)) + '</p>' : '') + '</div></article>';
		}).join('');
		content.querySelectorAll('.schuetzen-app__event').forEach(function (card, index) {
			card.addEventListener('click', function () { showDetail(content, entries[index], section); });
		});
	}

	function renderError() {
		root.innerHTML = '<div class="schuetzen-app__error">Die App-Inhalte konnten gerade nicht geladen werden.</div>';
	}

	function loadContent(showLoader) {
		if (showLoader) {
			root.classList.add('is-refreshing');
		}
		return fetch(config.apiUrl, { credentials: 'same-origin', cache: 'no-store' })
			.then(function (response) {
			if (!response.ok) {
				throw new Error('API request failed');
			}
			return response.json();
			})
			.then(render)
			.catch(renderError)
			.finally(function () { root.classList.remove('is-refreshing'); });
	}

	loadContent();
	var touchStartY = 0;
	var refreshTriggered = false;
	document.addEventListener('touchstart', function (event) {
		if (window.scrollY === 0 && event.touches.length === 1) {
			touchStartY = event.touches[0].clientY;
			refreshTriggered = false;
		}
	}, { passive: true });
	document.addEventListener('touchmove', function (event) {
		if (touchStartY && event.touches.length === 1 && event.touches[0].clientY - touchStartY > 70) {
			refreshTriggered = true;
			root.classList.add('pull-to-refresh');
		}
	}, { passive: true });
	document.addEventListener('touchend', function () {
		if (refreshTriggered) {
			loadContent(true);
		}
		touchStartY = 0;
		refreshTriggered = false;
		root.classList.remove('pull-to-refresh');
	}, { passive: true });
	document.addEventListener('visibilitychange', function () {
		if (document.visibilityState === 'visible') {
			loadContent();
		}
	});

	if (config.manifest && !document.querySelector('link[rel="manifest"]')) {
		var manifest = document.createElement('link');
		manifest.rel = 'manifest';
		manifest.href = config.manifest;
		document.head.appendChild(manifest);
	}

	if ('serviceWorker' in navigator && config.workerUrl) {
		navigator.serviceWorker.register(config.workerUrl, { scope: '/' }).catch(function () {
			// Offline support is optional; the online app remains usable.
		});
	}
})();
