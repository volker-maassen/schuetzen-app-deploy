<?php

defined( 'ABSPATH' ) || exit;

/**
 * Stellt einen bewusst getrennten Zugangsweg für bereits vorhandene
 * WordPress-Benutzer bereit. Die öffentliche App selbst bleibt ohne Login
 * erreichbar; der Zugangsweg verwendet die WordPress-Standard-Sitzung.
 */
final class Schuetzen_App_Login {
	private const QUERY_VAR = 'schuetzen_app_login';

	public function __construct() {
		add_action( 'init', array( $this, 'register_rewrite_rule' ) );
		add_filter( 'query_vars', array( $this, 'add_query_var' ) );
		add_action( 'template_redirect', array( $this, 'serve_login_page' ), 0 );
		add_action( 'update_option_schuetzen_app_settings', array( $this, 'flush_rules_when_slug_changes' ), 10, 2 );
		add_action( 'add_option_schuetzen_app_settings', array( $this, 'flush_rules_after_settings_created' ) );
	}

	public static function slug() {
		$settings = get_option( 'schuetzen_app_settings', array() );
		return sanitize_title( is_array( $settings ) ? ( $settings['login_slug'] ?? '' ) : '' );
	}

	public static function app_url() {
		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);
		foreach ( $pages as $page ) {
			if ( has_shortcode( $page->post_content, 'schuetzen_app' ) ) {
				return get_permalink( $page );
			}
		}
		return home_url( '/' );
	}

	public static function login_url() {
		$slug = self::slug();
		return $slug ? home_url( '/' . $slug . '/' ) : '';
	}

	public static function is_login_request() {
		return (bool) get_query_var( self::QUERY_VAR );
	}

	public function register_rewrite_rule() {
		$slug = self::slug();
		if ( $slug ) {
			add_rewrite_rule( '^' . preg_quote( $slug, '/' ) . '/?$', 'index.php?' . self::QUERY_VAR . '=1', 'top' );
		}
	}

	public function add_query_var( $vars ) {
		$vars[] = self::QUERY_VAR;
		return $vars;
	}

	public function flush_rules_when_slug_changes( $old_value, $value ) {
		$old_slug = sanitize_title( is_array( $old_value ) ? ( $old_value['login_slug'] ?? '' ) : '' );
		$new_slug = sanitize_title( is_array( $value ) ? ( $value['login_slug'] ?? '' ) : '' );
		if ( $old_slug !== $new_slug ) {
			$this->register_rewrite_rule();
			flush_rewrite_rules();
		}
	}

	public function flush_rules_after_settings_created() {
		$this->register_rewrite_rule();
		flush_rewrite_rules();
	}

	public function serve_login_page() {
		if ( ! get_query_var( self::QUERY_VAR ) ) {
			return;
		}

		nocache_headers();
		do_action( 'litespeed_control_set_nocache', 'Schuetzen-App-Zugang darf nicht zwischengespeichert werden.' );

		if ( is_user_logged_in() ) {
			wp_safe_redirect( self::app_url() );
			exit;
		}

		$error = '';
		if ( 'POST' === strtoupper( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			$error = $this->process_login();
		}

		$this->render_login_page( $error );
		exit;
	}

	private function process_login() {
		if ( ! isset( $_POST['schuetzen_app_login_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_app_login_nonce'] ) ), 'schuetzen_app_login' ) ) {
			return 'Die Anmeldung konnte nicht geprüft werden. Bitte versuche es erneut.';
		}

		$login    = sanitize_text_field( wp_unslash( $_POST['log'] ?? '' ) );
		$password = (string) wp_unslash( $_POST['pwd'] ?? '' );
		if ( '' === $login || '' === $password ) {
			return 'Bitte Benutzername oder E-Mail-Adresse und Passwort eingeben.';
		}
		$ip        = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) );
		$limit_key = 'schuetzen_app_login_' . md5( $ip );
		$attempts  = absint( get_transient( $limit_key ) );
		if ( $attempts >= 5 ) {
			return 'Zu viele Anmeldeversuche. Bitte versuche es in 15 Minuten erneut.';
		}
		if ( is_email( $login ) ) {
			$user = get_user_by( 'email', $login );
			if ( $user ) {
				$login = $user->user_login;
			}
		}

		$user = wp_signon(
			array(
				'user_login'    => $login,
				'user_password' => $password,
				'remember'      => ! empty( $_POST['rememberme'] ),
			),
			is_ssl()
		);
		if ( is_wp_error( $user ) ) {
			set_transient( $limit_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );
			return 'Benutzername, E-Mail-Adresse oder Passwort ist nicht korrekt.';
		}
		delete_transient( $limit_key );

		wp_safe_redirect( self::app_url() );
		exit;
	}

	private function render_login_page( $error ) {
		Schuetzen_App_Frontend::enqueue_assets();
		?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<?php wp_head(); ?>
</head>
<body class="schuetzen-app-standalone schuetzen-app-login-page">
	<main class="schuetzen-app-login" aria-labelledby="schuetzen-app-login-title">
		<h1 id="schuetzen-app-login-title">Vereinszugang</h1>
		<p>Bitte melde dich mit deinem vorhandenen Benutzerkonto an.</p>
		<?php if ( $error ) : ?><p class="schuetzen-app-login__error" role="alert"><?php echo esc_html( $error ); ?></p><?php endif; ?>
		<form method="post" action="<?php echo esc_url( self::login_url() ); ?>">
			<?php wp_nonce_field( 'schuetzen_app_login', 'schuetzen_app_login_nonce' ); ?>
			<label>Benutzername oder E-Mail-Adresse<input type="text" name="log" autocomplete="username" required></label>
			<label>Passwort<input type="password" name="pwd" autocomplete="current-password" required></label>
			<label class="schuetzen-app-login__remember"><input type="checkbox" name="rememberme" value="forever" checked> Angemeldet bleiben</label>
			<button type="submit">Anmelden</button>
		</form>
		<p class="schuetzen-app-login__back"><a href="<?php echo esc_url( self::app_url() ); ?>">Zur öffentlichen App</a></p>
	</main>
	<?php wp_footer(); ?>
</body>
</html><?php
	}
}
