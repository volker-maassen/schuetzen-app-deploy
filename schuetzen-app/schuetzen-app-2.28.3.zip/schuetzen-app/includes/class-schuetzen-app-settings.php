<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Settings {
	private $option_name = 'schuetzen_app_settings';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_post_schuetzen_app_export_settings', array( $this, 'export_settings' ) );
		add_action( 'admin_post_schuetzen_app_import_settings', array( $this, 'import_settings' ) );
		add_action( 'admin_post_schuetzen_app_create_page', array( $this, 'create_app_page' ) );
		add_filter( 'upload_mimes', array( $this, 'allow_admin_svg_uploads' ) );
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'recognize_admin_svg_uploads' ), 10, 5 );
		add_filter( 'wp_handle_upload_prefilter', array( $this, 'validate_svg_upload' ) );
	}

	public function allow_admin_svg_uploads( $mimes ) {
		if ( current_user_can( 'manage_options' ) ) {
			$mimes['svg'] = 'image/svg+xml';
		}
		return $mimes;
	}

	public function recognize_admin_svg_uploads( $data, $file, $filename, $mimes, $real_mime = '' ) {
		if ( current_user_can( 'manage_options' ) && 'svg' === strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) ) {
			$data['ext']             = 'svg';
			$data['type']            = 'image/svg+xml';
			$data['proper_filename'] = $filename;
		}
		return $data;
	}

	public function validate_svg_upload( $file ) {
		if ( 'svg' !== strtolower( pathinfo( $file['name'] ?? '', PATHINFO_EXTENSION ) ) ) {
			return $file;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			$file['error'] = 'SVG-Dateien dürfen nur von Administratoren hochgeladen werden.';
			return $file;
		}

		$contents = isset( $file['tmp_name'] ) && is_readable( $file['tmp_name'] ) ? file_get_contents( $file['tmp_name'] ) : false;
		if ( false === $contents || strlen( $contents ) > MB_IN_BYTES || ! preg_match( '/<svg\b/i', $contents ) ) {
			$file['error'] = 'Die SVG-Datei ist ungültig oder größer als 1 MB.';
			return $file;
		}

		$unsafe_patterns = array(
			'/<!DOCTYPE|<!ENTITY/i',
			'/<(?:script|foreignObject|iframe|object|embed|audio|video|style)\b/i',
			'/\son[a-z]+\s*=/i',
			'/\s(?:href|xlink:href)\s*=\s*["\']\s*(?:javascript:|data:|https?:|\/\/)/i',
			'/url\(\s*["\']?\s*(?:javascript:|data:|https?:|\/\/)/i',
		);
		foreach ( $unsafe_patterns as $pattern ) {
			if ( preg_match( $pattern, $contents ) ) {
				$file['error'] = 'Die SVG-Datei enthält aus Sicherheitsgründen nicht erlaubte aktive oder externe Inhalte.';
				break;
			}
		}

		return $file;
	}

	public function add_menu() {
		add_menu_page( 'Schützen-App', 'Schützen-App', 'manage_options', 'schuetzen-app', array( $this, 'render_page' ), 'dashicons-smartphone', 26 );
		add_submenu_page( 'schuetzen-app', 'Schützen-App Einstellungen', 'Einstellungen', 'manage_options', 'schuetzen-app', array( $this, 'render_page' ) );
	}

	public function register_settings() {
		register_setting( 'schuetzen_app_settings_group', $this->option_name, array( $this, 'sanitize_settings' ) );
	}

	public function export_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Keine Berechtigung für den Export der Einstellungen.' );
		}
		check_admin_referer( 'schuetzen_app_export_settings' );

		$payload = array(
			'type'           => 'schuetzen-app-settings',
			'schema_version' => 1,
			'plugin_version' => SCHUETZEN_APP_VERSION,
			'exported_at'    => gmdate( 'c' ),
			'settings'       => $this->sanitize_settings( get_option( $this->option_name, array() ) ),
		);

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="schuetzen-app-einstellungen-' . gmdate( 'Y-m-d' ) . '.json"' );
		echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	public function import_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Keine Berechtigung für den Import der Einstellungen.' );
		}
		check_admin_referer( 'schuetzen_app_import_settings' );

		$file = $_FILES['schuetzen_app_settings_file'] ?? array();
		if ( ! is_array( $file ) || ! is_string( $file['tmp_name'] ?? null ) || ! is_uploaded_file( $file['tmp_name'] ) || UPLOAD_ERR_OK !== (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) || (int) ( $file['size'] ?? 0 ) > MB_IN_BYTES ) {
			$this->redirect_after_transfer( 'import-error' );
		}

		$contents = file_get_contents( $file['tmp_name'] );
		$payload  = json_decode( (string) $contents, true );
		if ( false === $contents || ! is_array( $payload ) || 'schuetzen-app-settings' !== ( $payload['type'] ?? '' ) || 1 !== (int) ( $payload['schema_version'] ?? 0 ) || ! is_array( $payload['settings'] ?? null ) ) {
			$this->redirect_after_transfer( 'import-invalid' );
		}

		update_option( $this->option_name, $this->sanitize_settings( $payload['settings'] ), false );
		$this->redirect_after_transfer( 'imported' );
	}

	private function redirect_after_transfer( $status ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'            => 'schuetzen-app',
					'tab'             => 'transfer',
					'transfer_status' => sanitize_key( $status ),
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	private function find_app_page() {
		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		foreach ( $pages as $page ) {
			if ( has_shortcode( $page->post_content, 'schuetzen_app' ) ) {
				return $page;
			}
		}

		return null;
	}

	public function create_app_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Keine Berechtigung zum Anlegen der App-Seite.' );
		}
		check_admin_referer( 'schuetzen_app_create_page' );

		$page = $this->find_app_page();
		if ( $page ) {
			$this->redirect_after_page_creation( 'exists', $page->ID );
		}

		$page_id = wp_insert_post(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'post_title'     => 'Schützen-App',
				'post_content'   => '[schuetzen_app]',
				'comment_status' => 'closed',
			),
			true
		);

		if ( is_wp_error( $page_id ) ) {
			$this->redirect_after_page_creation( 'error' );
		}

		$this->redirect_after_page_creation( 'created', $page_id );
	}

	private function redirect_after_page_creation( $status, $page_id = 0 ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'            => 'schuetzen-app',
					'tab'             => 'help',
					'app_page_status' => sanitize_key( $status ),
					'app_page_id'     => absint( $page_id ),
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	private function render_color_control( $key, $label, $settings, $default ) {
		$value = sanitize_hex_color( $settings[ 'color_' . $key ] ?? $settings[ $key ] ?? '' ) ?: $default;
		$legacy_opacity = ( 'background_end' === $key ) ? ( $settings['background_end_opacity'] ?? 100 ) : 100;
		$opacity = min( 100, max( 0, absint( $settings[ 'color_' . $key . '_opacity' ] ?? $legacy_opacity ) ) );
		?>
		<div class="schuetzen-color-control" data-schuetzen-color-control data-color-key="<?php echo esc_attr( $key ); ?>" data-default-color="<?php echo esc_attr( $default ); ?>">
			<label class="schuetzen-color-control__label" for="schuetzen_app_color_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
			<div class="schuetzen-color-control__fields">
				<input type="color" id="schuetzen_app_color_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $this->option_name . '[color_' . $key . ']' ); ?>" value="<?php echo esc_attr( $value ); ?>" data-schuetzen-color-picker aria-label="<?php echo esc_attr( $label . ' auswählen' ); ?>">
				<input type="text" class="schuetzen-color-control__hex" value="<?php echo esc_attr( strtoupper( $value ) ); ?>" data-schuetzen-color-hex aria-label="<?php echo esc_attr( $label . ' als Hexadezimalwert' ); ?>" maxlength="7" spellcheck="false">
				<label class="schuetzen-color-control__opacity"><span>Deckkraft</span><input type="number" min="0" max="100" step="1" name="<?php echo esc_attr( $this->option_name . '[color_' . $key . '_opacity]' ); ?>" value="<?php echo esc_attr( $opacity ); ?>" data-schuetzen-color-opacity><span>%</span></label>
				<button type="button" class="button-link" data-schuetzen-color-reset title="Standardwert wiederherstellen" aria-label="<?php echo esc_attr( $label . ' auf Standard zurücksetzen' ); ?>">↺</button>
			</div>
		</div>
		<?php
	}

	public function sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();
		$colors = array( 'background_start', 'background_end', 'green', 'green_dark', 'gold', 'cream', 'paper', 'ink', 'muted', 'header', 'footer' );
		$groups = Schuetzen_App_Groups::sanitize( $input['groups'] ?? array() );
		if ( ! $groups ) {
			$groups = Schuetzen_App_Groups::defaults();
		}
		$group_ids = wp_list_pluck( $groups, 'id' );
		$primary_group = sanitize_key( $input['primary_group'] ?? '' );
		$output = array(
			'brand_line_1'   => sanitize_text_field( $input['brand_line_1'] ?? '' ),
			'brand_line_2'   => sanitize_text_field( $input['brand_line_2'] ?? '' ),
			'brand_line_3'   => sanitize_text_field( $input['brand_line_3'] ?? '' ),
			'header_logo'    => esc_url_raw( $input['header_logo'] ?? '' ),
			'disable_theme_settings' => array_key_exists( 'disable_theme_settings', $input ) ? (int) ! empty( $input['disable_theme_settings'] ) : 1,
			'navigation_messages' => array_key_exists( 'navigation_messages', $input ) ? (int) ! empty( $input['navigation_messages'] ) : 1,
			'navigation_info' => array_key_exists( 'navigation_info', $input ) ? (int) ! empty( $input['navigation_info'] ) : 1,
			'background_events' => esc_url_raw( $input['background_events'] ?? '' ),
			'background_messages' => esc_url_raw( $input['background_messages'] ?? '' ),
			'background_info' => esc_url_raw( $input['background_info'] ?? '' ),
			'groups' => $groups,
			'primary_group' => in_array( $primary_group, $group_ids, true ) ? $primary_group : $group_ids[0],
			'calendar_sources' => Schuetzen_App_Calendar_Sources::sanitize_sources( $input['calendar_sources'] ?? array(), $groups ),
		);
		foreach ( $colors as $color ) {
			$value = sanitize_hex_color( $input[ 'color_' . $color ] ?? '' );
			$output[ 'color_' . $color ] = $value ?: '';
			$default_opacity = ( 'background_end' === $color ) ? ( $input['background_end_opacity'] ?? 100 ) : 100;
			$output[ 'color_' . $color . '_opacity' ] = min( 100, max( 0, absint( $input[ 'color_' . $color . '_opacity' ] ?? $default_opacity ) ) );
		}
		return $output;
	}

	public function render_page() {
		wp_enqueue_media();
		$settings = get_option( $this->option_name, array() );
		$settings = is_array( $settings ) ? $settings : array();
		$brand_line_3 = array_key_exists( 'brand_line_3', $settings ) ? $settings['brand_line_3'] : get_bloginfo( 'description' );
		$header_logo = esc_url( $settings['header_logo'] ?? '' );
		$header_logo_fallback = get_site_icon_url( 192 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-192.png';
		$header_logo_preview = $header_logo ?: $header_logo_fallback;
		$preview_heading_font = 'Georgia, "Times New Roman", serif';
		if ( function_exists( 'wp_get_global_settings' ) ) {
			$global_settings = wp_get_global_settings();
			$font_families   = $global_settings['typography']['fontFamilies']['theme'] ?? array();
			$heading_styles  = function_exists( 'wp_get_global_styles' ) ? wp_get_global_styles( array( 'blocks', 'core/heading' ) ) : array();
			$heading_font    = $heading_styles['typography']['fontFamily'] ?? '';
			if ( is_string( $heading_font ) && str_starts_with( $heading_font, 'var:preset|font-family|' ) ) {
				$heading_slug = substr( $heading_font, strlen( 'var:preset|font-family|' ) );
				foreach ( $font_families as $font_family ) {
					if ( ( $font_family['slug'] ?? '' ) === $heading_slug && ! empty( $font_family['fontFamily'] ) ) {
						$preview_heading_font = $font_family['fontFamily'];
						break;
					}
				}
			} elseif ( is_string( $heading_font ) && '' !== trim( $heading_font ) ) {
				$preview_heading_font = $heading_font;
			}
		}
		$groups = Schuetzen_App_Groups::get();
		$primary_group = Schuetzen_App_Groups::primary_id();
		$sources = Schuetzen_App_Calendar_Sources::sanitize_sources( $settings['calendar_sources'] ?? array() );
		$source_status = get_option( 'schuetzen_app_calendar_status', array() );
		$source_status = is_array( $source_status ) ? $source_status : array();
		$sync_notice = get_transient( 'schuetzen_app_calendar_notice_' . get_current_user_id() );
		if ( false !== $sync_notice ) {
			delete_transient( 'schuetzen_app_calendar_notice_' . get_current_user_id() );
		}
		$transfer_status = isset( $_GET['transfer_status'] ) && is_string( $_GET['transfer_status'] ) ? sanitize_key( wp_unslash( $_GET['transfer_status'] ) ) : '';
		$app_page_status = isset( $_GET['app_page_status'] ) && is_string( $_GET['app_page_status'] ) ? sanitize_key( wp_unslash( $_GET['app_page_status'] ) ) : '';
		$app_page = $this->find_app_page();
		$section_backgrounds = array(
			'background_events' => 'Termine',
			'background_messages' => 'Nachrichten',
			'background_info' => 'Infos',
		);
		$colors = array(
			'background_start' => 'Verlaufsfarbe oben',
			'background_end'   => 'Verlaufsfarbe unten',
			'green'      => 'Hauptfarbe',
			'green_dark' => 'Dunkle Hauptfarbe',
			'gold'       => 'Akzentfarbe',
			'cream'      => 'App-Hintergrund',
			'paper'      => 'Kartenfarbe',
			'ink'        => 'Textfarbe',
			'muted'      => 'Gedämpfte Textfarbe',
			'header'     => 'Header-Hintergrund',
			'footer'     => 'Footer-Hintergrund',
		);
		$basic_color_keys = array( 'cream', 'paper', 'ink', 'muted' );
		$advanced_color_keys = array();
		$color_defaults = array(
			'background_start' => '#f7f4ec',
			'background_end'   => '#e9e5db',
			'green'      => '#1e4d3a',
			'green_dark' => '#123326',
			'gold'       => '#d6a84f',
			'cream'      => '#f7f4ec',
			'paper'      => '#fffdf8',
			'ink'        => '#1f2824',
			'muted'      => '#69736d',
			'header'     => '#f7f4ec',
			'footer'     => '#fffdf8',
		);
		$primary_group_data = null;
		foreach ( $groups as $group ) {
			if ( $primary_group === $group['id'] ) {
				$primary_group_data = $group;
				break;
			}
		}
		?>
		<style>
			.schuetzen-source-group { min-width: 190px; }
			.schuetzen-source-group > select { width: 100%; }
			.schuetzen-source-group__toggle { display: inline-block; margin-top: 6px; }
			.schuetzen-source-group__new { display: grid; grid-template-columns: minmax(120px, 1fr) 44px; gap: 7px; align-items: center; margin-top: 8px; padding: 10px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; }
			.schuetzen-source-group__new[hidden] { display: none; }
			.schuetzen-source-group__new input[type="text"] { width: 100%; }
			.schuetzen-source-group__new input[type="color"] { width: 44px; height: 32px; padding: 2px; }
			.schuetzen-source-group__actions { grid-column: 1 / -1; display: flex; align-items: center; gap: 9px; }
			.schuetzen-source-group__status { color: #008a20; }
			.schuetzen-design-layout { display: grid; grid-template-columns: minmax(520px, 760px) minmax(260px, 340px); gap: 32px; align-items: start; max-width: 1160px; }
			.schuetzen-color-panel { margin-top: 16px; padding: 20px; background: #fff; border: 1px solid #dcdcde; border-radius: 8px; }
			.schuetzen-color-panel h3 { margin-top: 0; }
			.schuetzen-primary-color { display: flex; align-items: center; gap: 10px; padding: 12px 14px; margin-bottom: 16px; background: #f6f7f7; border-radius: 6px; }
			.schuetzen-primary-color__swatch { width: 30px; height: 30px; flex: 0 0 30px; border: 1px solid rgba(0,0,0,.18); border-radius: 50%; }
			.schuetzen-color-list { display: grid; gap: 4px; }
			.schuetzen-color-control { display: grid; grid-template-columns: minmax(165px, 1fr) auto; gap: 16px; align-items: center; min-height: 42px; padding: 7px 0; border-bottom: 1px solid #f0f0f1; }
			.schuetzen-color-control:last-child { border-bottom: 0; }
			.schuetzen-color-control__label { font-weight: 600; }
			.schuetzen-color-control__fields { display: flex; align-items: center; gap: 7px; }
			.schuetzen-color-control input[type="color"] { width: 36px; height: 32px; padding: 2px; border: 1px solid #8c8f94; border-radius: 4px; cursor: pointer; }
			.schuetzen-color-control__hex { width: 78px; font-family: monospace; text-transform: uppercase; }
			.schuetzen-color-control__hex--invalid { border-color: #d63638; box-shadow: 0 0 0 1px #d63638; }
			.schuetzen-color-control__opacity { display: inline-flex; align-items: center; gap: 5px; color: #50575e; }
			.schuetzen-color-control__opacity input { width: 62px; }
			.schuetzen-color-control .button-link { width: 28px; min-height: 28px; padding: 0; color: #50575e; font-size: 18px; text-decoration: none; }
			.schuetzen-advanced-colors { margin-top: 14px; }
			.schuetzen-advanced-colors summary { cursor: pointer; font-weight: 600; color: #2271b1; }
			.schuetzen-advanced-colors[open] summary { margin-bottom: 10px; }
			.schuetzen-design-preview { position: sticky; top: 42px; }
			.schuetzen-design-preview > h2 { margin-top: 0; }
			.schuetzen-preview-app { padding: 0 16px 14px; background: var(--preview-cream); border: 1px solid #dcdcde; border-radius: 22px; color: var(--preview-ink); box-shadow: 0 12px 28px rgba(0,0,0,.12); font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
			.schuetzen-preview-header, .schuetzen-preview-nav { padding: 13px; background: var(--preview-paper); border-radius: 14px; }
			.schuetzen-preview-header { display: flex; align-items: center; min-height: 100px; margin-bottom: 19px; padding: 20px 16px 18px; border-radius: 0 0 19px 19px; }
			.schuetzen-preview-brand { display: flex; align-items: center; gap: 12px; min-width: 0; }
			.schuetzen-preview-logo { display: block; flex: 0 0 auto; width: auto; max-width: 112px; height: auto; max-height: 64px; object-fit: contain; }
			.schuetzen-preview-brand > span { display: flex; flex-direction: column; min-width: 0; line-height: 1.1; }
			.schuetzen-preview-brand small { color: var(--preview-muted); font-size: 11.5px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
			.schuetzen-preview-brand h1 { margin: 4px 0 0; color: var(--preview-green-dark); font-family: var(--preview-heading-font); font-size: 22.4px; font-weight: 400; line-height: 1.05; letter-spacing: normal; }
			.schuetzen-preview-brand span span { margin-top: 3px; color: var(--preview-muted); font-size: 12.5px; line-height: 1.25; font-weight: 400; }
			.schuetzen-preview-card { padding: 14px; background: var(--preview-paper); border-left: 4px solid var(--preview-primary); border-radius: 12px; box-shadow: 0 6px 15px rgba(0,0,0,.08); }
			.schuetzen-preview-card h3 { margin: 0 0 5px; color: var(--preview-green-dark); font-family: var(--preview-heading-font); font-weight: 400; }
			.schuetzen-preview-card p { margin: 3px 0; }
			.schuetzen-preview-muted { color: var(--preview-muted); }
			.schuetzen-preview-nav { display: flex; justify-content: space-around; margin-top: 12px; background: var(--preview-footer); font-weight: 600; }
			.schuetzen-preview-nav span:first-child { padding: 6px 12px; color: #fff; background: var(--preview-primary); border-radius: 9px; }
			@media (max-width: 1050px) { .schuetzen-design-layout { grid-template-columns: 1fr; } .schuetzen-design-preview { position: static; max-width: 420px; } }
			@media (max-width: 700px) { .schuetzen-design-layout { display: block; } .schuetzen-color-control { grid-template-columns: 1fr; gap: 4px; } .schuetzen-color-control__fields { flex-wrap: wrap; } }
		</style>
		<div class="wrap schuetzen-app-settings">
			<h1>Schützen-App</h1>
			<?php if ( 'imported' === $transfer_status ) : ?>
				<div class="notice notice-success is-dismissible"><p>Die Schützen-App-Einstellungen wurden erfolgreich importiert.</p></div>
			<?php elseif ( 'import-invalid' === $transfer_status ) : ?>
				<div class="notice notice-error is-dismissible"><p>Die ausgewählte Datei ist kein gültiger Schützen-App-Einstellungsexport.</p></div>
			<?php elseif ( 'import-error' === $transfer_status ) : ?>
				<div class="notice notice-error is-dismissible"><p>Die JSON-Datei konnte nicht hochgeladen oder gelesen werden. Die maximale Dateigröße beträgt 1 MB.</p></div>
			<?php endif; ?>
			<?php if ( 'created' === $app_page_status ) : ?>
				<div class="notice notice-success is-dismissible"><p>Die App-Seite wurde angelegt und veröffentlicht.</p></div>
			<?php elseif ( 'exists' === $app_page_status ) : ?>
				<div class="notice notice-info is-dismissible"><p>Eine App-Seite ist bereits vorhanden. Es wurde keine weitere Seite angelegt.</p></div>
			<?php elseif ( 'error' === $app_page_status ) : ?>
				<div class="notice notice-error is-dismissible"><p>Die App-Seite konnte nicht angelegt werden.</p></div>
			<?php endif; ?>
			<?php if ( is_array( $sync_notice ) ) : ?>
				<div class="notice <?php echo empty( $sync_notice['errors'] ) ? 'notice-success' : 'notice-warning'; ?> is-dismissible"><p>
					<?php echo esc_html( sprintf( '%d Quelle(n) geprüft, %d Termin(e) angelegt, %d aktualisiert, %d vergangene übersprungen, %d alte externe Termine gelöscht.', absint( $sync_notice['sources'] ?? 0 ), absint( $sync_notice['created'] ?? 0 ), absint( $sync_notice['updated'] ?? 0 ), absint( $sync_notice['skipped'] ?? 0 ), absint( $sync_notice['deleted'] ?? 0 ) ) ); ?>
					<?php if ( ! empty( $sync_notice['errors'] ) ) : ?><br><?php echo esc_html( implode( ' | ', $sync_notice['errors'] ) ); ?><?php endif; ?>
				</p></div>
			<?php endif; ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'schuetzen_app_settings_group' ); ?>
				<nav class="nav-tab-wrapper" aria-label="Schützen-App Einstellungen">
					<button type="button" class="nav-tab nav-tab-active" data-schuetzen-tab="design">Design</button>
					<button type="button" class="nav-tab" data-schuetzen-tab="groups">Gruppen</button>
					<button type="button" class="nav-tab" data-schuetzen-tab="calendars">Kalenderquellen</button>
					<button type="button" class="nav-tab" data-schuetzen-tab="transfer">Import/Export</button>
					<button type="button" class="nav-tab" data-schuetzen-tab="help">Hilfe</button>
				</nav>

				<section data-schuetzen-panel="design">
					<h2>Kopfzeile</h2>
					<table class="form-table" role="presentation">
						<tr><th scope="row"><label for="schuetzen_app_header_logo">Logo</label></th><td><input type="url" class="regular-text" id="schuetzen_app_header_logo" name="<?php echo esc_attr( $this->option_name . '[header_logo]' ); ?>" value="<?php echo esc_url( $header_logo ); ?>" data-schuetzen-media-field><button type="button" class="button" data-schuetzen-media-button="header_logo">Logo auswählen</button> <button type="button" class="button-link-delete" data-schuetzen-media-clear="header_logo"<?php echo $header_logo ? '' : ' hidden'; ?>>Logo entfernen</button><p class="description">PNG, JPG, WebP oder geprüftes SVG. Ohne eigenes Logo wird das WordPress-Favicon verwendet.</p></td></tr>
						<tr><th scope="row"><label for="schuetzen_app_brand_line_1">Kleine obere Zeile</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_1" name="<?php echo esc_attr( $this->option_name . '[brand_line_1]' ); ?>" value="<?php echo esc_attr( $settings['brand_line_1'] ?? '' ); ?>"></td></tr>
						<tr><th scope="row"><label for="schuetzen_app_brand_line_2">Hauptüberschrift</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_2" name="<?php echo esc_attr( $this->option_name . '[brand_line_2]' ); ?>" value="<?php echo esc_attr( $settings['brand_line_2'] ?? '' ); ?>"><p class="description">Bleibt das Feld leer, wird der WordPress-Websitetitel verwendet.</p></td></tr>
						<tr><th scope="row"><label for="schuetzen_app_brand_line_3">Unterzeile</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_3" name="<?php echo esc_attr( $this->option_name . '[brand_line_3]' ); ?>" value="<?php echo esc_attr( $brand_line_3 ); ?>"><p class="description">Optional. Ein leeres Feld blendet die Unterzeile aus.</p></td></tr>
						<tr><th scope="row">Theme-Einstellungen</th><td><label><input type="hidden" name="<?php echo esc_attr( $this->option_name . '[disable_theme_settings]' ); ?>" value="0"><input type="checkbox" name="<?php echo esc_attr( $this->option_name . '[disable_theme_settings]' ); ?>" value="1" <?php checked( ! array_key_exists( 'disable_theme_settings', $settings ) || ! empty( $settings['disable_theme_settings'] ) ); ?>> Theme-Einstellungen deaktivieren</label><p class="description">Schützt die App vor zusätzlichen Abständen des aktiven Themes, zum Beispiel Divi. Die Schriftfamilie des Themes bleibt trotzdem wirksam.</p></td></tr>
					</table>

					<h2>Navigation</h2>
					<p class="description">Lege fest, welche Bereiche in der unteren App-Navigation erscheinen. Termine und Einstellungen bleiben immer sichtbar.</p>
					<fieldset>
						<p><label><input type="checkbox" checked disabled> <strong>Termine</strong> <span class="description">– immer sichtbar</span></label></p>
						<input type="hidden" name="<?php echo esc_attr( $this->option_name . '[navigation_messages]' ); ?>" value="0">
						<p><label><input type="checkbox" name="<?php echo esc_attr( $this->option_name . '[navigation_messages]' ); ?>" value="1" <?php checked( ! array_key_exists( 'navigation_messages', $settings ) || ! empty( $settings['navigation_messages'] ) ); ?>> Nachrichten</label></p>
						<input type="hidden" name="<?php echo esc_attr( $this->option_name . '[navigation_info]' ); ?>" value="0">
						<p><label><input type="checkbox" name="<?php echo esc_attr( $this->option_name . '[navigation_info]' ); ?>" value="1" <?php checked( ! array_key_exists( 'navigation_info', $settings ) || ! empty( $settings['navigation_info'] ) ); ?>> Infos</label></p>
						<p><label><input type="checkbox" checked disabled> <strong>Einstellungen</strong> <span class="description">– immer sichtbar</span></label></p>
					</fieldset>

					<h2>Bereichs-Hintergrundbilder</h2>
					<p class="description">Die Bilder erscheinen als dezenter Hintergrund im jeweiligen Hauptbereich der App.</p>
					<table class="form-table" role="presentation">
						<?php foreach ( $section_backgrounds as $key => $label ) : ?>
							<tr>
								<th scope="row"><label for="schuetzen_app_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
								<td>
									<input type="url" class="regular-text" id="schuetzen_app_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $this->option_name . '[' . $key . ']' ); ?>" value="<?php echo esc_url( $settings[ $key ] ?? '' ); ?>" data-schuetzen-media-field>
									<button type="button" class="button" data-schuetzen-media-button="<?php echo esc_attr( $key ); ?>">Bild auswählen</button>
									<?php if ( ! empty( $settings[ $key ] ) ) : ?><button type="button" class="button-link-delete" data-schuetzen-media-clear="<?php echo esc_attr( $key ); ?>">Bild entfernen</button><?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>

					<h2>App-Farben</h2>
					<div class="schuetzen-design-layout">
						<div class="schuetzen-color-panel">
							<?php if ( $primary_group_data ) : ?>
								<div class="schuetzen-primary-color">
									<span class="schuetzen-primary-color__swatch" style="background: <?php echo esc_attr( $primary_group_data['color'] ); ?>"></span>
									<span><strong>Führende Designfarbe: <?php echo esc_html( $primary_group_data['name'] ); ?></strong><br><button type="button" class="button-link" data-schuetzen-open-tab="groups">Bei den Gruppen ändern</button></span>
								</div>
							<?php endif; ?>
							<div class="schuetzen-color-list">
								<?php foreach ( $basic_color_keys as $key ) : ?>
									<?php $this->render_color_control( $key, $colors[ $key ], $settings, $color_defaults[ $key ] ); ?>
								<?php endforeach; ?>
							</div>
							<?php if ( $advanced_color_keys ) : ?><details class="schuetzen-advanced-colors">
								<summary>Erweiterte Farben</summary>
								<p class="description">Diese Werte steuern zusätzliche Flächen und sekundäre Texte. Die vorhandenen Einstellungen bleiben erhalten.</p>
								<div class="schuetzen-color-list">
									<?php foreach ( $advanced_color_keys as $key ) : ?>
										<?php $this->render_color_control( $key, $colors[ $key ], $settings, $color_defaults[ $key ] ); ?>
									<?php endforeach; ?>
								</div>
							</details><?php endif; ?>
						</div>
						<aside class="schuetzen-design-preview" aria-label="Live-Vorschau">
							<h2>Live-Vorschau</h2>
			<div class="schuetzen-preview-app" data-schuetzen-design-preview style="--preview-heading-font: <?php echo esc_attr( $preview_heading_font ); ?>;">
								<div class="schuetzen-preview-header"><div class="schuetzen-preview-brand"><?php if ( $header_logo_preview ) : ?><img class="schuetzen-preview-logo" src="<?php echo esc_url( $header_logo_preview ); ?>" alt="" data-schuetzen-preview-logo><?php endif; ?><span><small data-schuetzen-preview-brand-line-1><?php echo esc_html( $settings['brand_line_1'] ?? '' ); ?></small><h1 data-schuetzen-preview-brand-line-2><?php echo esc_html( ! empty( $settings['brand_line_2'] ) ? $settings['brand_line_2'] : get_bloginfo( 'name' ) ); ?></h1><span data-schuetzen-preview-brand-line-3><?php echo esc_html( $brand_line_3 ); ?></span></span></div></div>
								<div class="schuetzen-preview-card"><h3>Beispieltermin</h3><p>Samstag, 12. September</p><p class="schuetzen-preview-muted">19:00 Uhr · Treffpunkt</p></div>
								<div class="schuetzen-preview-nav"><span>Termine</span><?php if ( ! array_key_exists( 'navigation_messages', $settings ) || ! empty( $settings['navigation_messages'] ) ) : ?><span>Nachrichten</span><?php endif; ?><?php if ( ! array_key_exists( 'navigation_info', $settings ) || ! empty( $settings['navigation_info'] ) ) : ?><span>Infos</span><?php endif; ?><span>Einstellungen</span></div>
							</div>
						</aside>
					</div>
				</section>

				<section data-schuetzen-panel="groups" hidden>
					<h2>Gruppen und Farben</h2>
					<p>Die Hauptgruppe liefert die führende Designfarbe für Navigation, Willkommen und aktive Schaltflächen. Die interne ID bleibt beim Umbenennen unverändert. Mit „Immer sichtbar“ markierte Gruppen können im Frontend nicht ausgeblendet werden.</p>
					<table class="widefat striped" data-schuetzen-groups-table>
					<thead><tr><th>Hauptgruppe</th><th>Name</th><th>Farbe</th><th>Deckkraft</th><th>Immer sichtbar</th><th></th></tr></thead>
						<tbody>
						<?php foreach ( $groups as $index => $group ) : ?>
							<tr>
								<td><input type="radio" name="<?php echo esc_attr( $this->option_name . '[primary_group]' ); ?>" value="<?php echo esc_attr( $group['id'] ); ?>" <?php checked( $primary_group, $group['id'] ); ?>></td>
								<td><input type="hidden" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][id]' ); ?>" value="<?php echo esc_attr( $group['id'] ); ?>"><input type="text" class="regular-text" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][name]' ); ?>" value="<?php echo esc_attr( $group['name'] ); ?>" required><br><small>ID: <?php echo esc_html( $group['id'] ); ?></small></td>
								<td><input type="color" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][color]' ); ?>" value="<?php echo esc_attr( $group['color'] ); ?>"></td>
								<td><input type="range" min="0" max="100" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][opacity]' ); ?>" value="<?php echo esc_attr( $group['opacity'] ); ?>" oninput="this.nextElementSibling.value=this.value+'%'"> <output><?php echo esc_html( $group['opacity'] . '%' ); ?></output></td>
								<td><label><input type="checkbox" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][always_visible]' ); ?>" value="1" <?php checked( ! empty( $group['always_visible'] ) ); ?>> dauerhaft anzeigen</label></td>
								<td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p><button type="button" class="button" data-schuetzen-add-group>Gruppe hinzufügen</button></p>
					<p class="description">Wird eine verwendete Gruppe entfernt, bleiben die Inhalte erhalten, erscheinen aber bis zu einer neuen Zuordnung in Dunkelgrau.</p>
				</section>

				<section data-schuetzen-panel="calendars" hidden>
					<h2>Externe Kalenderquellen</h2>
					<p>Trage eine Webseite mit verknüpftem iCalendar-Feed oder direkt eine öffentliche ICS-URL ein. Aktive Quellen werden zweimal täglich synchronisiert. Eine noch fehlende Gruppe kannst du direkt an der Kalenderquelle anlegen.</p>
					<table class="widefat striped" data-schuetzen-sources-table>
						<thead><tr><th>Aktiv</th><th>Name und URL</th><th>Gruppe</th><th>Zugriff</th><th>Neue Termine</th><th>Vergangene</th><th>Status</th><th></th></tr></thead>
						<tbody>
						<?php foreach ( $sources as $index => $source ) : ?>
							<?php $status = $source_status[ $source['id'] ] ?? array(); ?>
							<tr>
								<td><input type="hidden" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][id]' ); ?>" value="<?php echo esc_attr( $source['id'] ); ?>"><input type="checkbox" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][active]' ); ?>" value="1" <?php checked( $source['active'], 1 ); ?>></td>
								<td><input type="text" class="regular-text" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][name]' ); ?>" value="<?php echo esc_attr( $source['name'] ); ?>" placeholder="z. B. Bezirksverband Neuss"><br><input type="url" class="large-text" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][url]' ); ?>" value="<?php echo esc_attr( $source['url'] ); ?>" placeholder="https://…" required></td>
								<td>
									<div class="schuetzen-source-group">
										<select name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][group]' ); ?>" data-schuetzen-source-group><option value="">Keine Zuordnung</option><?php foreach ( $groups as $group ) : ?><option value="<?php echo esc_attr( $group['id'] ); ?>" <?php selected( $source['group'], $group['id'] ); ?>><?php echo esc_html( $group['name'] ); ?></option><?php endforeach; ?></select>
										<button type="button" class="button-link schuetzen-source-group__toggle" data-schuetzen-new-source-group>+ Neue Gruppe anlegen</button>
										<div class="schuetzen-source-group__new" data-schuetzen-inline-group hidden>
											<input type="text" placeholder="Gruppenname" data-schuetzen-inline-group-name aria-label="Name der neuen Gruppe">
											<input type="color" value="#4b5563" data-schuetzen-inline-group-color aria-label="Farbe der neuen Gruppe">
											<div class="schuetzen-source-group__actions"><button type="button" class="button button-secondary" data-schuetzen-create-source-group>Übernehmen</button><button type="button" class="button-link" data-schuetzen-cancel-source-group>Abbrechen</button></div>
										</div>
										<small class="schuetzen-source-group__status" data-schuetzen-source-group-status></small>
									</div>
								</td>
								<td><label><input type="checkbox" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][restricted]' ); ?>" value="1" <?php checked( ! empty( $source['restricted'] ) ); ?>> Zugriff begrenzen</label><br><small>Freigabe je Benutzer unter Benutzer.</small></td>
								<td><select name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][status]' ); ?>"><option value="draft" <?php selected( $source['status'], 'draft' ); ?>>Als Entwurf</option><option value="publish" <?php selected( $source['status'], 'publish' ); ?>>Automatisch veröffentlichen</option></select></td>
								<td><label><input type="checkbox" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][include_past]' ); ?>" value="1" <?php checked( $source['include_past'], 1 ); ?>> importieren</label></td>
								<td><?php if ( $status ) : ?><?php echo esc_html( wp_date( 'd.m.Y H:i', absint( $status['time'] ?? 0 ) ) ); ?><br><small><?php echo ! empty( $status['error'] ) ? esc_html( $status['error'] ) : esc_html( sprintf( '%d neu, %d aktualisiert, %d vergangene übersprungen', absint( $status['created'] ?? 0 ), absint( $status['updated'] ?? 0 ), absint( $status['skipped'] ?? 0 ) ) ); ?></small><?php else : ?>Noch nicht synchronisiert<?php endif; ?></td>
								<td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p><button type="button" class="button" data-schuetzen-add-source>Kalenderquelle hinzufügen</button></p>
					<p><a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=schuetzen_app_sync_calendars' ), 'schuetzen_app_sync_calendars' ) ); ?>">Aktive Quellen jetzt synchronisieren</a> <span class="description">Änderungen vorher speichern.</span></p>
				</section>

				<section data-schuetzen-panel="transfer" hidden>
					<h2>Einstellungen exportieren</h2>
					<p>Der Export enthält Design, Gruppen, Kalenderquellen und die übrigen Einstellungen der Schützen-App.</p>
					<p><a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=schuetzen_app_export_settings' ), 'schuetzen_app_export_settings' ) ); ?>">JSON-Datei herunterladen</a></p>
					<hr>
					<h2>Einstellungen importieren</h2>
					<p>Der Import ersetzt die aktuellen Plugin-Einstellungen vollständig. Termine, Nachrichten, Infos, Personen, Marschordnungen und Mediendateien werden weder importiert noch verändert.</p>
					<p><input type="file" name="schuetzen_app_settings_file" accept="application/json,.json" required form="schuetzen-app-import-form"></p>
					<p><button type="submit" class="button button-primary" form="schuetzen-app-import-form" onclick="return window.confirm('Die aktuellen Schützen-App-Einstellungen werden ersetzt. Import fortsetzen?');">Einstellungen importieren</button></p>
					<p class="description">Hintergrundbilder werden als URLs übertragen. Die eigentlichen Bilddateien sind nicht Bestandteil des Exports.</p>
				</section>

				<section data-schuetzen-panel="help" hidden>
					<h2>App auf einer Seite einfügen</h2>
					<div style="max-width: 760px; padding: 16px; background: #fff; border-left: 4px solid #1e4d3a;">
						<p>Die App verwendet automatisch eine eigene Vollbildvorlage ohne Header und Footer des WordPress-Themes.</p>
						<?php if ( $app_page ) : ?>
							<p><strong>App-Seite vorhanden:</strong> <?php echo esc_html( get_the_title( $app_page ) ); ?></p>
							<p><a class="button button-primary" href="<?php echo esc_url( get_edit_post_link( $app_page->ID ) ); ?>">App-Seite bearbeiten</a><?php if ( 'publish' === $app_page->post_status ) : ?> <a class="button" href="<?php echo esc_url( get_permalink( $app_page->ID ) ); ?>" target="_blank" rel="noopener noreferrer">App öffnen</a><?php endif; ?></p>
						<?php else : ?>
							<p><a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=schuetzen_app_create_page' ), 'schuetzen_app_create_page' ) ); ?>">App-Seite automatisch anlegen</a></p>
							<p class="description">Die Seite „Schützen-App“ wird mit dem benötigten Shortcode angelegt und direkt veröffentlicht.</p>
						<?php endif; ?>
						<hr>
						<p>Alternativ kannst du eine Seite selbst anlegen und dort diesen Shortcode einfügen:</p>
						<p><code style="display: inline-block; padding: 8px 12px; font-size: 14px; user-select: all;">[schuetzen_app]</code></p>
						<p class="description">Ein besonderes Seiten-Template muss nicht ausgewählt werden.</p>
					</div>
					<h2>Inhalte pflegen</h2>
					<div style="max-width: 760px; padding: 16px; background: #fff; border-left: 4px solid #1e4d3a;">
						<p><strong>Termine</strong><br>Datum, Uhrzeit, Ort, Treffpunkt und Zuordnung werden direkt beim Termin gepflegt. Ein Termin ohne Uhrzeit dient als Tageskarte für weitere Termine desselben Tages.</p>
						<p><strong>Nachrichten und Infos</strong><br>Die Inhalte werden über die jeweiligen Menüpunkte angelegt. Die Gruppenzuordnung bestimmt die farbliche Kennzeichnung in der App.</p>
						<p><strong>Kalenderquellen</strong><br>Externe iCalendar-Termine können als Entwurf oder automatisch veröffentlicht importiert werden. Vergangene Termine werden standardmäßig übersprungen. Der Import reicht vom aktuellen Tag bis zum 31. Dezember des kommenden Jahres; wiederkehrende Termine außerhalb dieses Zeitraums werden übersprungen. Bereits importierte externe Termine außerhalb des Zeitraums werden in der App ausgeblendet und nicht gelöscht. Laufende mehrtägige Termine bleiben bis einschließlich ihres Enddatums erhalten. Bereits importierte Termine werden über ihre eindeutige Kalender-ID aktualisiert und nicht dupliziert.</p>
						<p><strong>Personen und Marschordnungen</strong><br>Personen werden einmalig angelegt und können anschließend in den Marschordnungen verwendet werden. Eine Marschordnung lässt sich einem Termin zuweisen.</p>
					</div>
					<h2>WordPress und Darstellung</h2>
					<div style="max-width: 760px; padding: 16px; background: #fff; border-left: 4px solid #1e4d3a;">
						<p><strong>Zeitzone</strong><br>Damit Termine mit der richtigen Uhrzeit erscheinen, muss unter <em>WordPress → Einstellungen → Allgemein</em> die Zeitzone des Vereinsstandorts ausgewählt sein, zum Beispiel <strong>Berlin</strong>. „UTC+0“ ist für deutsche Standorte normalerweise nicht passend. Nach einer Änderung die Kalenderquellen erneut synchronisieren.</p>
						<p><strong>Typografie</strong><br>Die App übernimmt die Schrift für Überschriften aus dem aktiven WordPress-Design. Eine im Customizer oder Site Editor festgelegte Überschriftenschrift wirkt deshalb auch auf „Termine“, die Terminüberschriften und die Hauptüberschrift im Header. Für ein stimmiges Ergebnis sollten Schriftgröße, Zeilenhöhe und Kontrast im Theme geprüft werden – besonders auf kleinen Bildschirmen.</p>
						<p><strong>Farben und Stil</strong><br>Die Farben der App werden hier unter <em>Design</em> eingestellt. Die Überschriftenschrift kommt dagegen aus WordPress. So lassen sich Farbe und Typografie unabhängig voneinander an das Erscheinungsbild des Vereins anpassen.</p>
					</div>
				</section>

				<?php submit_button( 'Einstellungen speichern' ); ?>
			</form>
			<form id="schuetzen-app-import-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden>
				<input type="hidden" name="action" value="schuetzen_app_import_settings">
				<?php wp_nonce_field( 'schuetzen_app_import_settings' ); ?>
			</form>
		</div>
		<script>
		(function () {
			var tabs = document.querySelectorAll('[data-schuetzen-tab]');
			var panels = document.querySelectorAll('[data-schuetzen-panel]');
			var groupOptions = <?php echo wp_json_encode( array_map( static function ( $group ) { return array( 'id' => $group['id'], 'name' => $group['name'] ); }, $groups ) ); ?>;
			var rowIndex = Date.now();
			var escapeHtml = function (value) {
				return String(value || '').replace(/[&<>"']/g, function (character) {
					return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[character];
				});
			};
			var sourceGroupHtml = function (sourceIndex, options) {
				return '<div class="schuetzen-source-group"><select name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][group]" data-schuetzen-source-group>' + options + '</select><button type="button" class="button-link schuetzen-source-group__toggle" data-schuetzen-new-source-group>+ Neue Gruppe anlegen</button><div class="schuetzen-source-group__new" data-schuetzen-inline-group hidden><input type="text" placeholder="Gruppenname" data-schuetzen-inline-group-name aria-label="Name der neuen Gruppe"><input type="color" value="#4b5563" data-schuetzen-inline-group-color aria-label="Farbe der neuen Gruppe"><div class="schuetzen-source-group__actions"><button type="button" class="button button-secondary" data-schuetzen-create-source-group>Übernehmen</button><button type="button" class="button-link" data-schuetzen-cancel-source-group>Abbrechen</button></div></div><small class="schuetzen-source-group__status" data-schuetzen-source-group-status></small></div>';
			};
			var appendGroup = function (id, name, color) {
				var groupIndex = rowIndex++;
				var body = document.querySelector('[data-schuetzen-groups-table] tbody');
				body.insertAdjacentHTML('beforeend', '<tr><td><input type="radio" name="schuetzen_app_settings[primary_group]" value="' + escapeHtml(id) + '"></td><td><input type="hidden" name="schuetzen_app_settings[groups][' + groupIndex + '][id]" value="' + escapeHtml(id) + '"><input type="text" class="regular-text" name="schuetzen_app_settings[groups][' + groupIndex + '][name]" value="' + escapeHtml(name) + '" required><br><small>ID: ' + escapeHtml(id) + '</small></td><td><input type="color" name="schuetzen_app_settings[groups][' + groupIndex + '][color]" value="' + escapeHtml(color) + '"></td><td><input type="range" min="0" max="100" name="schuetzen_app_settings[groups][' + groupIndex + '][opacity]" value="100" oninput="this.nextElementSibling.value=this.value+\'%\'"> <output>100%</output></td><td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td></tr>');
				groupOptions.push({ id: id, name: name });
				document.querySelectorAll('[data-schuetzen-source-group]').forEach(function (select) {
					var option = document.createElement('option');
					option.value = id;
					option.textContent = name;
					select.appendChild(option);
				});
			};
			var activateTab = function (name) {
				if (['design', 'groups', 'calendars', 'transfer', 'help'].indexOf(name) === -1) name = 'design';
				tabs.forEach(function (item) { item.classList.toggle('nav-tab-active', item.getAttribute('data-schuetzen-tab') === name); });
				panels.forEach(function (panel) { panel.hidden = panel.getAttribute('data-schuetzen-panel') !== name; });
				var url = new URL(window.location.href);
				url.searchParams.set('tab', name);
				window.history.replaceState({}, '', url.toString());
				var referer = document.querySelector('input[name="_wp_http_referer"]');
				if (referer) referer.value = url.pathname + url.search;
			};
			tabs.forEach(function (tab) {
				tab.addEventListener('click', function () {
					activateTab(tab.getAttribute('data-schuetzen-tab'));
				});
			});
			document.querySelectorAll('[data-schuetzen-open-tab]').forEach(function (button) {
				button.addEventListener('click', function () { activateTab(button.getAttribute('data-schuetzen-open-tab')); });
			});
			activateTab(new URLSearchParams(window.location.search).get('tab') || 'design');
			document.addEventListener('click', function (event) {
				var removeButton = event.target.closest('[data-schuetzen-remove-row]');
				if (removeButton) {
					removeButton.closest('tr').remove();
					return;
				}
				if (event.target.closest('[data-schuetzen-add-group]')) {
					var index = rowIndex++;
					var id = 'gruppe-' + index;
					var body = document.querySelector('[data-schuetzen-groups-table] tbody');
					body.insertAdjacentHTML('beforeend', '<tr><td><input type="radio" name="schuetzen_app_settings[primary_group]" value="' + id + '"></td><td><input type="hidden" name="schuetzen_app_settings[groups][' + index + '][id]" value="' + id + '"><input type="text" class="regular-text" name="schuetzen_app_settings[groups][' + index + '][name]" required><br><small>ID: ' + id + '</small></td><td><input type="color" name="schuetzen_app_settings[groups][' + index + '][color]" value="#4b5563"></td><td><input type="range" min="0" max="100" name="schuetzen_app_settings[groups][' + index + '][opacity]" value="100" oninput="this.nextElementSibling.value=this.value+\'%\'"> <output>100%</output></td><td><label><input type="checkbox" name="schuetzen_app_settings[groups][' + index + '][always_visible]" value="1"> dauerhaft anzeigen</label></td><td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td></tr>');
					return;
				}
				var newGroupButton = event.target.closest('[data-schuetzen-new-source-group]');
				if (newGroupButton) {
					var newGroupBox = newGroupButton.parentElement.querySelector('[data-schuetzen-inline-group]');
					newGroupBox.hidden = false;
					newGroupButton.hidden = true;
					newGroupBox.querySelector('[data-schuetzen-inline-group-name]').focus();
					return;
				}
				var cancelGroupButton = event.target.closest('[data-schuetzen-cancel-source-group]');
				if (cancelGroupButton) {
					var cancelGroup = cancelGroupButton.closest('.schuetzen-source-group');
					cancelGroup.querySelector('[data-schuetzen-inline-group]').hidden = true;
					cancelGroup.querySelector('[data-schuetzen-new-source-group]').hidden = false;
					return;
				}
				var createGroupButton = event.target.closest('[data-schuetzen-create-source-group]');
				if (createGroupButton) {
					var sourceGroup = createGroupButton.closest('.schuetzen-source-group');
					var groupNameField = sourceGroup.querySelector('[data-schuetzen-inline-group-name]');
					var groupName = groupNameField.value.trim();
					if (!groupName) {
						groupNameField.setCustomValidity('Bitte einen Gruppennamen eingeben.');
						groupNameField.reportValidity();
						return;
					}
					groupNameField.setCustomValidity('');
					var groupColor = sourceGroup.querySelector('[data-schuetzen-inline-group-color]').value;
					var groupId = 'gruppe-' + rowIndex++;
					appendGroup(groupId, groupName, groupColor);
					sourceGroup.querySelector('[data-schuetzen-source-group]').value = groupId;
					sourceGroup.querySelector('[data-schuetzen-inline-group]').hidden = true;
					sourceGroup.querySelector('[data-schuetzen-new-source-group]').hidden = false;
					sourceGroup.querySelector('[data-schuetzen-source-group-status]').textContent = 'Neue Gruppe wird beim Speichern angelegt.';
					return;
				}
				if (event.target.closest('[data-schuetzen-add-source]')) {
					var sourceIndex = rowIndex++;
					var sourceId = 'quelle-' + sourceIndex;
					var options = '<option value="">Keine Zuordnung</option>' + groupOptions.map(function (group) { return '<option value="' + escapeHtml(group.id) + '">' + escapeHtml(group.name) + '</option>'; }).join('');
					var sourceBody = document.querySelector('[data-schuetzen-sources-table] tbody');
					sourceBody.insertAdjacentHTML('beforeend', '<tr><td><input type="hidden" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][id]" value="' + sourceId + '"><input type="checkbox" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][active]" value="1" checked></td><td><input type="text" class="regular-text" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][name]" placeholder="z. B. Bezirksverband Neuss"><br><input type="url" class="large-text" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][url]" placeholder="https://…" required></td><td>' + sourceGroupHtml(sourceIndex, options) + '</td><td><label><input type="checkbox" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][restricted]" value="1"> Zugriff begrenzen</label><br><small>Freigabe je Benutzer unter Benutzer.</small></td><td><select name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][status]"><option value="draft">Als Entwurf</option><option value="publish">Automatisch veröffentlichen</option></select></td><td><label><input type="checkbox" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][include_past]" value="1"> importieren</label></td><td>Noch nicht synchronisiert</td><td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td></tr>');
				}
			});
			document.querySelectorAll('[data-schuetzen-media-button]').forEach(function (button) {
				button.addEventListener('click', function () {
					var key = button.getAttribute('data-schuetzen-media-button');
					var field = document.getElementById('schuetzen_app_' + key);
					var frame = wp.media({ title: key === 'header_logo' ? 'Logo auswählen' : 'Bild auswählen', button: { text: 'Übernehmen' }, multiple: false, library: { type: 'image' } });
					frame.on('select', function () {
						var attachment = frame.state().get('selection').first().toJSON();
						field.value = attachment.url;
						if (key === 'header_logo') {
							document.querySelector('[data-schuetzen-preview-logo]').src = attachment.url;
							var clearButton = document.querySelector('[data-schuetzen-media-clear="header_logo"]');
							if (clearButton) clearButton.hidden = false;
						}
					});
					frame.open();
				});
			});
			document.querySelectorAll('[data-schuetzen-media-clear]').forEach(function (button) {
				button.addEventListener('click', function () {
					var key = button.getAttribute('data-schuetzen-media-clear');
					document.getElementById('schuetzen_app_' + key).value = '';
					if (key === 'header_logo') {
						document.querySelector('[data-schuetzen-preview-logo]').src = <?php echo wp_json_encode( esc_url( $header_logo_fallback ) ); ?>;
						button.hidden = true;
					} else {
						button.remove();
					}
				});
			});

			var preview = document.querySelector('[data-schuetzen-design-preview]');
			var colorControls = document.querySelectorAll('[data-schuetzen-color-control]');
			var normalizeHex = function (value) {
				value = String(value || '').trim().toUpperCase();
				if (/^[0-9A-F]{6}$/.test(value)) value = '#' + value;
				return /^#[0-9A-F]{6}$/.test(value) ? value : '';
			};
			var toRgba = function (hex, opacity) {
				var normalized = normalizeHex(hex) || '#000000';
				return 'rgba(' + parseInt(normalized.slice(1, 3), 16) + ',' + parseInt(normalized.slice(3, 5), 16) + ',' + parseInt(normalized.slice(5, 7), 16) + ',' + Math.min(100, Math.max(0, Number(opacity) || 0)) / 100 + ')';
			};
			var updatePreview = function () {
				if (!preview) return;
				colorControls.forEach(function (control) {
					var picker = control.querySelector('[data-schuetzen-color-picker]');
					var opacity = control.querySelector('[data-schuetzen-color-opacity]');
					preview.style.setProperty('--preview-' + control.getAttribute('data-color-key').replace(/_/g, '-'), toRgba(picker.value, opacity.value));
				});
				var primary = document.querySelector('[data-schuetzen-groups-table] input[type="radio"]:checked');
				if (primary) {
					var row = primary.closest('tr');
					var groupColor = row.querySelector('input[type="color"]');
					var groupOpacity = row.querySelector('input[type="range"], input[type="number"]');
					preview.style.setProperty('--preview-primary', toRgba(groupColor.value, groupOpacity ? groupOpacity.value : 100));
				}
			};
			colorControls.forEach(function (control) {
				var picker = control.querySelector('[data-schuetzen-color-picker]');
				var hex = control.querySelector('[data-schuetzen-color-hex]');
				var opacity = control.querySelector('[data-schuetzen-color-opacity]');
				picker.addEventListener('input', function () { hex.value = picker.value.toUpperCase(); updatePreview(); });
				hex.addEventListener('input', function () {
					var value = normalizeHex(hex.value);
					if (value) { picker.value = value; hex.classList.remove('schuetzen-color-control__hex--invalid'); updatePreview(); }
				});
				hex.addEventListener('blur', function () {
					var value = normalizeHex(hex.value);
					hex.value = value || picker.value.toUpperCase();
					hex.classList.toggle('schuetzen-color-control__hex--invalid', !value);
				});
				opacity.addEventListener('input', updatePreview);
				control.querySelector('[data-schuetzen-color-reset]').addEventListener('click', function () {
					picker.value = control.getAttribute('data-default-color');
					hex.value = picker.value.toUpperCase();
					opacity.value = 100;
					updatePreview();
				});
			});
			document.querySelectorAll('[data-schuetzen-groups-table] input').forEach(function (field) { field.addEventListener('input', updatePreview); field.addEventListener('change', updatePreview); });
			var brandLine1 = document.getElementById('schuetzen_app_brand_line_1');
			var brandLine2 = document.getElementById('schuetzen_app_brand_line_2');
			var brandLine3 = document.getElementById('schuetzen_app_brand_line_3');
			var headerLogo = document.getElementById('schuetzen_app_header_logo');
			if (brandLine1) brandLine1.addEventListener('input', function () { document.querySelector('[data-schuetzen-preview-brand-line-1]').textContent = brandLine1.value; });
			if (brandLine2) brandLine2.addEventListener('input', function () { document.querySelector('[data-schuetzen-preview-brand-line-2]').textContent = brandLine2.value || <?php echo wp_json_encode( get_bloginfo( 'name' ) ); ?>; });
			if (brandLine3) brandLine3.addEventListener('input', function () { document.querySelector('[data-schuetzen-preview-brand-line-3]').textContent = brandLine3.value; });
			if (headerLogo) headerLogo.addEventListener('input', function () { document.querySelector('[data-schuetzen-preview-logo]').src = headerLogo.value || <?php echo wp_json_encode( esc_url( $header_logo_fallback ) ); ?>; });
			updatePreview();
		}());
		</script>
		<?php
	}
}
