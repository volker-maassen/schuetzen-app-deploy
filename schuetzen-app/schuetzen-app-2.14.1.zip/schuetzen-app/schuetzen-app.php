<?php
/**
 * Plugin Name: Schützen-App
 * Description: Schlanke Vereins-App für Termine, Nachrichten und Informationen.
 * Version: 2.14.1
 * Author: Volker Maaßen
 * Text Domain: schuetzen-app
 * Update URI: https://www.maassen.de/my-plugins/schuetzen-app
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

defined( 'ABSPATH' ) || exit;

define( 'SCHUETZEN_APP_VERSION', '2.14.1' );
define( 'SCHUETZEN_APP_FILE', __FILE__ );

require_once __DIR__ . '/includes/class-schuetzen-app-updater.php';
require_once __DIR__ . '/includes/class-schuetzen-app-rest.php';
require_once __DIR__ . '/includes/class-schuetzen-app-frontend.php';
require_once __DIR__ . '/includes/class-schuetzen-app-content.php';
require_once __DIR__ . '/includes/class-schuetzen-app-settings.php';
require_once __DIR__ . '/includes/class-schuetzen-app-mail-importer.php';

new Schuetzen_App_Updater(
	SCHUETZEN_APP_FILE,
	SCHUETZEN_APP_VERSION,
	'https://www.maassen.de/my-plugins/schuetzen-app/update.json'
);

new Schuetzen_App_REST();
new Schuetzen_App_Frontend();
new Schuetzen_App_Content();
new Schuetzen_App_Settings();
new Schuetzen_App_Mail_Importer();
