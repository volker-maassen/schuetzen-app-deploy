<?php

defined( 'ABSPATH' ) || exit;

/**
 * Verbindet die App mit der WordPress-Standardanmeldung.
 *
 * Die Anmeldung selbst bleibt vollständig bei WordPress. Diese Klasse liefert
 * nur die Rücksprung-URLs für die App und den Anmeldebildschirm.
 */
final class Schuetzen_App_Login {
	public static function app_url() {
		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		foreach ( $pages as $page ) {
			if ( has_shortcode( $page->post_content, 'schuetzen_app' ) ) {
				return get_permalink( $page );
			}
		}

		return home_url( '/' );
	}

	public static function login_url() {
		return wp_login_url( self::app_url() );
	}
}
