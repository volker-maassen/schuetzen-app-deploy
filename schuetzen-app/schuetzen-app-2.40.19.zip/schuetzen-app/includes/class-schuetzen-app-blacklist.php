<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Blacklist {
	const OPTION = 'schuetzen_app_blacklist';

	public function __construct() {
		add_action( 'pre_get_posts', array( $this, 'filter_admin_events' ), 5 );
		add_filter( 'views_edit-schuetzen_event', array( $this, 'event_views' ) );
		add_filter( 'post_row_actions', array( $this, 'event_row_actions' ), 20, 2 );
		add_action( 'admin_notices', array( $this, 'admin_notice' ) );
		add_action( 'admin_post_schuetzen_app_blacklist_event', array( $this, 'blacklist_event' ) );
		add_action( 'admin_post_schuetzen_app_blacklist_rule', array( $this, 'blacklist_rule' ) );
		add_action( 'admin_post_schuetzen_app_unblacklist_event', array( $this, 'unblacklist_event' ) );
		add_action( 'admin_post_schuetzen_app_unblacklist_rule', array( $this, 'unblacklist_rule' ) );
	}

	public static function is_blacklisted( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || 'schuetzen_event' !== $post->post_type ) return false;
		$key = self::event_key( $post_id );
		$data = array(
			'title'    => $post->post_title,
			'source_id' => get_post_meta( $post_id, '_schuetzen_event_source_id', true ),
			'category' => get_post_meta( $post_id, '_schuetzen_event_category', true ),
		);
		return self::matches( $key, $data );
	}

	public static function is_event_blacklisted( $source, $event, $external_key ) {
		return self::matches(
			$external_key,
			array(
				'title'     => $event['title'] ?? '',
				'source_id' => $source['id'] ?? '',
				'category'  => $source['group'] ?? '',
			)
		);
	}

	public static function has_matching_rule( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || 'schuetzen_event' !== $post->post_type ) return false;
		$data = array( 'title' => $post->post_title, 'source_id' => get_post_meta( $post_id, '_schuetzen_event_source_id', true ), 'category' => get_post_meta( $post_id, '_schuetzen_event_category', true ) );
		$title = self::normalize( $data['title'] );
		foreach ( self::get()['rules'] as $rule ) {
			if ( $title !== self::normalize( $rule['title'] ?? '' ) ) continue;
			if ( ! empty( $rule['source_id'] ) && (string) $rule['source_id'] !== (string) $data['source_id'] ) continue;
			if ( ! empty( $rule['category'] ) && (string) $rule['category'] !== (string) $data['category'] ) continue;
			return true;
		}
		return false;
	}

	public static function event_key( $post_id ) {
		$key = get_post_meta( $post_id, '_schuetzen_event_external_key', true );
		return $key ?: 'post:' . absint( $post_id );
	}

	public static function add_event( $post_id ) {
		$blacklist = self::get();
		$key       = self::event_key( $post_id );
		if ( ! in_array( $key, $blacklist['entries'], true ) ) {
			$blacklist['entries'][] = $key;
			self::save( $blacklist );
		}
	}

	public static function remove_event( $post_id ) {
		$blacklist           = self::get();
		$blacklist['entries'] = array_values( array_diff( $blacklist['entries'], array( self::event_key( $post_id ) ) ) );
		self::save( $blacklist );
	}

	public function filter_admin_events( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || 'schuetzen_event' !== $query->get( 'post_type' ) ) return;
		$ids = self::blacklisted_post_ids();
		if ( ! empty( $_GET['schuetzen_blacklist'] ) ) {
			$query->set( 'post__in', $ids ?: array( 0 ) );
		} elseif ( $ids ) {
			$query->set( 'post__not_in', $ids );
		}
	}

	public function event_views( $views ) {
		$count = count( self::blacklisted_post_ids() );
		$url = add_query_arg( array( 'post_type' => 'schuetzen_event', 'schuetzen_blacklist' => 1 ), admin_url( 'edit.php' ) );
		$views['schuetzen_blacklist'] = '<a href="' . esc_url( $url ) . '">Blacklist <span class="count">(' . absint( $count ) . ')</span></a>';
		return $views;
	}

	public function event_row_actions( $actions, $post ) {
		if ( 'schuetzen_event' !== $post->post_type || ! current_user_can( 'edit_post', $post->ID ) ) return $actions;
		if ( self::is_blacklisted( $post->ID ) ) {
			if ( self::has_matching_rule( $post->ID ) ) $actions['schuetzen_unblacklist_rule'] = '<a href="' . esc_url( $this->action_url( 'schuetzen_app_unblacklist_rule', $post->ID ) ) . '">Titel-Regel entfernen</a>';
			if ( in_array( self::event_key( $post->ID ), self::get()['entries'], true ) ) $actions['schuetzen_unblacklist'] = '<a href="' . esc_url( $this->action_url( 'schuetzen_app_unblacklist_event', $post->ID ) ) . '">Aus Blacklist entfernen</a>';
		} else {
			$actions['schuetzen_blacklist'] = '<a href="' . esc_url( $this->action_url( 'schuetzen_app_blacklist_event', $post->ID ) ) . '">Einzeln blacklisten</a>';
			if ( get_post_meta( $post->ID, '_schuetzen_event_source_id', true ) ) $actions['schuetzen_blacklist_rule'] = '<a href="' . esc_url( $this->action_url( 'schuetzen_app_blacklist_rule', $post->ID ) ) . '">Titel künftig blacklisten</a>';
		}
		return $actions;
	}

	public function blacklist_event() { $this->change_event( 'add' ); }
	public function unblacklist_event() { $this->change_event( 'remove' ); }

	public function blacklist_rule() {
		$post_id = $this->checked_post();
		if ( ! $post_id ) return;
		$post = get_post( $post_id );
		$data = array( 'title' => self::normalize( $post->post_title ), 'source_id' => get_post_meta( $post_id, '_schuetzen_event_source_id', true ), 'category' => get_post_meta( $post_id, '_schuetzen_event_category', true ) );
		$blacklist = self::get();
		$blacklist['rules'][] = $data;
		self::save( $blacklist );
		$this->redirect( 'rule-added' );
	}

	public function unblacklist_rule() {
		$post_id = $this->checked_post();
		if ( ! $post_id ) return;
		$post = get_post( $post_id );
		$rule = array( 'title' => self::normalize( $post->post_title ), 'source_id' => get_post_meta( $post_id, '_schuetzen_event_source_id', true ), 'category' => get_post_meta( $post_id, '_schuetzen_event_category', true ) );
		$blacklist = self::get();
		$blacklist['rules'] = array_values( array_filter( $blacklist['rules'], static function ( $item ) use ( $rule ) { return $item !== $rule; } ) );
		self::save( $blacklist );
		$this->redirect( 'rule-removed' );
	}

	public function admin_notice() {
		$screen = get_current_screen();
		if ( empty( $_GET['schuetzen_blacklist_notice'] ) || ! $screen || 'edit-schuetzen_event' !== $screen->id ) return;
		$messages = array( 'event-blacklisted' => 'Der Termin wurde auf die Blacklist gesetzt.', 'event-unblacklisted' => 'Der Termin wurde aus der Blacklist entfernt.', 'rule-added' => 'Die Titel-Regel wurde angelegt. Künftige passende Feed-Termine werden nicht importiert.', 'rule-removed' => 'Die Titel-Regel wurde entfernt.' );
		$key = sanitize_key( $_GET['schuetzen_blacklist_notice'] );
		if ( isset( $messages[ $key ] ) ) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $messages[ $key ] ) . '</p></div>';
	}

	private function change_event( $action ) {
		$post_id = $this->checked_post();
		if ( ! $post_id ) return;
		$blacklist = self::get();
		$key = self::event_key( $post_id );
		if ( 'add' === $action && ! in_array( $key, $blacklist['entries'], true ) ) $blacklist['entries'][] = $key;
		if ( 'remove' === $action ) $blacklist['entries'] = array_values( array_diff( $blacklist['entries'], array( $key ) ) );
		self::save( $blacklist );
		$this->redirect( 'event-' . ( 'add' === $action ? 'blacklisted' : 'unblacklisted' ) );
	}

	private function checked_post() {
		$post_id = absint( $_GET['post_id'] ?? 0 );
		if ( ! $post_id || 'schuetzen_event' !== get_post_type( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) wp_die( 'Keine Berechtigung.' );
		check_admin_referer( 'schuetzen_app_blacklist_' . $post_id );
		return $post_id;
	}

	private function action_url( $action, $post_id ) { return wp_nonce_url( admin_url( 'admin-post.php?action=' . $action . '&post_id=' . absint( $post_id ) ), 'schuetzen_app_blacklist_' . absint( $post_id ) ); }
	private function redirect( $status ) { wp_safe_redirect( add_query_arg( array( 'post_type' => 'schuetzen_event', 'schuetzen_blacklist_notice' => sanitize_key( $status ) ), admin_url( 'edit.php' ) ) ); exit; }

	private static function matches( $key, $data ) {
		$blacklist = self::get();
		if ( in_array( $key, $blacklist['entries'], true ) ) return true;
		$title = self::normalize( $data['title'] ?? '' );
		foreach ( $blacklist['rules'] as $rule ) {
			if ( $title !== self::normalize( $rule['title'] ?? '' ) ) continue;
			if ( ! empty( $rule['source_id'] ) && (string) $rule['source_id'] !== (string) ( $data['source_id'] ?? '' ) ) continue;
			if ( ! empty( $rule['category'] ) && (string) $rule['category'] !== (string) ( $data['category'] ?? '' ) ) continue;
			return true;
		}
		return false;
	}

	private static function blacklisted_post_ids() {
		$ids = array();
		foreach ( get_posts( array( 'post_type' => 'schuetzen_event', 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids' ) ) as $post_id ) if ( self::is_blacklisted( $post_id ) ) $ids[] = (int) $post_id;
		return $ids;
	}

	private static function get() {
		$value = get_option( self::OPTION, array() );
		return array( 'entries' => array_values( array_filter( (array) ( $value['entries'] ?? array() ), 'is_string' ) ), 'rules' => array_values( array_filter( (array) ( $value['rules'] ?? array() ), 'is_array' ) ) );
	}

	private static function save( $value ) { update_option( self::OPTION, array( 'entries' => array_values( array_unique( (array) ( $value['entries'] ?? array() ) ) ), 'rules' => array_values( array_unique( (array) ( $value['rules'] ?? array() ), SORT_REGULAR ) ) ), false ); }
	private static function normalize( $value ) { return strtolower( trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $value ) ) ) ); }
}
