<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Admin_Access {
	public function __construct() {
		add_action( 'admin_init', array( $this, 'keep_non_administrators_in_app' ) );
	}

	public function keep_non_administrators_in_app() {
		if ( ! is_user_logged_in() || current_user_can( 'manage_options' ) || wp_doing_ajax() ) {
			return;
		}
		wp_safe_redirect( Schuetzen_App_Login::app_url() );
		exit;
	}
}
