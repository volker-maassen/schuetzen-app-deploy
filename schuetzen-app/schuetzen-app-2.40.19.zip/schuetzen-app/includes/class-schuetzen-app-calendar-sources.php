<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Calendar_Sources {
	const CRON_HOOK = 'schuetzen_app_sync_calendars';
	const MAX_IMPORT_DURATION_DAYS = 7;

	public function __construct() {
		add_action( 'init', array( $this, 'schedule_sync' ) );
		add_action( self::CRON_HOOK, array( $this, 'sync_active_sources' ) );
		add_action( 'admin_post_schuetzen_app_sync_calendars', array( $this, 'manual_sync' ) );
	}

	public static function sanitize_sources( $sources, $available_groups = null ) {
		$clean  = array();
		$used   = array();
		$groups = array();
		if ( is_array( $available_groups ) ) {
			foreach ( $available_groups as $group ) {
				$groups[ $group['id'] ] = $group['name'];
			}
		} else {
			$groups = Schuetzen_App_Groups::labels();
		}

		foreach ( array_slice( (array) $sources, 0, 20 ) as $source ) {
			$name = sanitize_text_field( $source['name'] ?? '' );
			$url  = esc_url_raw( $source['url'] ?? '', array( 'http', 'https' ) );
			$id   = sanitize_key( $source['id'] ?? '' );
			if ( '' === $name && '' === $url ) {
				continue;
			}
			if ( '' === $id ) {
				$id = sanitize_key( 'quelle-' . wp_generate_uuid4() );
			}
			if ( isset( $used[ $id ] ) ) {
				continue;
			}

			$group = sanitize_key( $source['group'] ?? '' );
			$restricted = ! empty( $source['restricted'] );
			$used[ $id ] = true;
			$clean[] = array(
				'id'           => $id,
				'name'         => $name ?: $url,
				'url'          => $url,
				'group'        => isset( $groups[ $group ] ) ? $group : '',
				'restricted'   => $restricted ? 1 : 0,
				'status'       => 'publish' === ( $source['status'] ?? '' ) ? 'publish' : 'draft',
				'include_past' => ! empty( $source['include_past'] ) ? 1 : 0,
				'active'       => ! empty( $source['active'] ) ? 1 : 0,
			);
		}

		return $clean;
	}

	public function schedule_sync() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 300, 'twicedaily', self::CRON_HOOK );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	public function manual_sync() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Keine Berechtigung für die Kalendersynchronisierung.' );
		}
		check_admin_referer( 'schuetzen_app_sync_calendars' );

		$result = $this->sync_active_sources();
		set_transient( 'schuetzen_app_calendar_notice_' . get_current_user_id(), $result, 120 );
		wp_safe_redirect( add_query_arg( array( 'page' => 'schuetzen-app', 'tab' => 'calendars' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function sync_active_sources() {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$sources  = self::sanitize_sources( is_array( $settings ) ? ( $settings['calendar_sources'] ?? array() ) : array() );
		$result   = array( 'sources' => 0, 'created' => 0, 'updated' => 0, 'skipped' => 0, 'deleted' => $this->delete_past_imported_events(), 'errors' => array() );

		foreach ( $sources as $source ) {
			if ( empty( $source['active'] ) || empty( $source['url'] ) ) {
				continue;
			}
			$result['sources']++;
			$source_result = $this->sync_source( $source );
			if ( is_wp_error( $source_result ) ) {
				$result['errors'][] = $source['name'] . ': ' . $source_result->get_error_message();
				$this->save_status( $source['id'], 0, 0, 0, $source_result->get_error_message() );
				continue;
			}
			$result['created'] += $source_result['created'];
			$result['updated'] += $source_result['updated'];
			$result['skipped'] += $source_result['skipped'];
			$messages = array();
			if ( ! empty( $source_result['failed'] ) ) {
				$messages[] = sprintf( '%d Termin(e) konnten nicht gespeichert werden.', $source_result['failed'] );
			}
			if ( ! empty( $source_result['rejected'] ) ) {
				$messages[] = sprintf( 'Nicht importiert: %s. Maximal erlaubt sind %d Tage.', implode( '; ', $source_result['rejected'] ), self::MAX_IMPORT_DURATION_DAYS );
			}
			$error = implode( ' ', $messages );
			if ( $error ) {
				$result['errors'][] = $source['name'] . ': ' . $error;
			}
			$this->save_status( $source['id'], $source_result['created'], $source_result['updated'], $source_result['skipped'], $error );
		}

		return $result;
	}

	private function delete_past_imported_events() {
		$post_ids = get_posts(
			array(
				'post_type'      => 'schuetzen_event',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => '_schuetzen_event_source_id',
						'value'   => '',
						'compare' => '!=',
					),
				),
			)
		);

		$today   = current_time( 'Y-m-d' );
		$deleted = 0;
		foreach ( $post_ids as $post_id ) {
			$end_date = get_post_meta( $post_id, '_schuetzen_event_end_date', true );
			$last_date = $end_date ?: get_post_meta( $post_id, '_schuetzen_event_date', true );
			if ( '' !== $last_date && $last_date < $today && wp_delete_post( $post_id, true ) ) {
				$deleted++;
			}
		}

		return $deleted;
	}

	private function sync_source( $source ) {
		$calendar = $this->fetch_calendar( $source['url'] );
		if ( is_wp_error( $calendar ) ) {
			return $calendar;
		}

		$events = $this->parse_calendar( $calendar );
		if ( ! $events ) {
			return new WP_Error( 'schuetzen_calendar_empty', 'Die Quelle enthält keine lesbaren Termine.' );
		}

		$result = array( 'created' => 0, 'updated' => 0, 'skipped' => 0, 'failed' => 0, 'rejected' => array() );
		$eligible_events = array();
		foreach ( $events as $event ) {
			if ( $this->has_invalid_date_range( $event ) ) {
				$result['skipped']++;
				$removed = $this->remove_imported_event( $source, $event );
				$result['rejected'][] = sprintf( '%s (Enddatum liegt vor dem Startdatum%s)', $event['title'], $removed ? ', bestehender Import entfernt' : '' );
				continue;
			}
			$duration_days = $this->event_duration_days( $event );
			if ( $duration_days > self::MAX_IMPORT_DURATION_DAYS ) {
				$result['skipped']++;
				$removed = $this->remove_imported_event( $source, $event );
				$result['rejected'][] = sprintf( '%s (%d Tage%s)', $event['title'], $duration_days, $removed ? ', bestehender Import entfernt' : '' );
				continue;
			}
			if ( empty( $source['include_past'] ) && $this->is_past_event( $event ) ) {
				$result['skipped']++;
				continue;
			}
			if ( $this->is_beyond_import_horizon( $event ) ) {
				$result['skipped']++;
				continue;
			}
			$eligible_events[] = $event;
		}

		foreach ( array_slice( $eligible_events, 0, 500 ) as $event ) {
			$action = $this->upsert_event( $source, $event );
			if ( is_wp_error( $action ) ) {
				$result['failed']++;
			} elseif ( isset( $result[ $action ] ) ) {
				$result[ $action ]++;
			}
		}

		return $result;
	}

	private function is_past_event( $event ) {
		$last_date = ! empty( $event['end_date'] ) ? $event['end_date'] : ( $event['date'] ?? '' );
		return '' !== $last_date && $last_date < current_time( 'Y-m-d' );
	}

	private function is_beyond_import_horizon( $event ) {
		$start_date = $event['date'] ?? '';
		$horizon_end = ( (int) current_time( 'Y' ) + 1 ) . '-12-31';
		return '' !== $start_date && $start_date > $horizon_end;
	}

	private function event_duration_days( $event ) {
		$start_date = $event['date'] ?? '';
		$end_date   = $event['end_date'] ?? '';
		if ( ! $start_date ) {
			return 0;
		}
		if ( ! $end_date ) {
			return 1;
		}
		$start = DateTimeImmutable::createFromFormat( '!Y-m-d', $start_date, wp_timezone() );
		$end   = DateTimeImmutable::createFromFormat( '!Y-m-d', $end_date, wp_timezone() );
		if ( ! $start || ! $end || $end < $start ) {
			return 0;
		}
		return (int) $start->diff( $end )->days + 1;
	}

	private function has_invalid_date_range( $event ) {
		return ! empty( $event['end_date'] ) && ! empty( $event['date'] ) && $event['end_date'] < $event['date'];
	}

	private function fetch_calendar( $url ) {
		$response = $this->fetch_url( $url );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( false !== stripos( $response, 'BEGIN:VCALENDAR' ) ) {
			return $response;
		}

		if ( preg_match_all( '/<link\b[^>]*>/i', $response, $links ) ) {
			foreach ( $links[0] as $link ) {
				if ( ! preg_match( '/\btype=["\']text\/calendar["\']/i', $link ) || ! preg_match( '/\bhref=["\']([^"\']+)["\']/i', $link, $href ) ) {
					continue;
				}
				$feed_url = $this->resolve_feed_url( $url, html_entity_decode( $href[1], ENT_QUOTES, 'UTF-8' ) );
				if ( ! wp_http_validate_url( $feed_url ) ) {
					continue;
				}
				$feed = $this->fetch_url( $feed_url );
				if ( ! is_wp_error( $feed ) && false !== stripos( $feed, 'BEGIN:VCALENDAR' ) ) {
					return $feed;
				}
			}
		}

		return new WP_Error( 'schuetzen_calendar_missing', 'Unter dieser URL wurde kein iCalendar-Feed gefunden.' );
	}

	private function resolve_feed_url( $page_url, $feed_url ) {
		$feed_url = trim( (string) $feed_url );
		if ( wp_http_validate_url( $feed_url ) ) {
			return $feed_url;
		}

		$base = wp_parse_url( $page_url );
		if ( empty( $base['scheme'] ) || empty( $base['host'] ) ) {
			return '';
		}
		$origin = $base['scheme'] . '://' . $base['host'] . ( isset( $base['port'] ) ? ':' . absint( $base['port'] ) : '' );
		if ( 0 === strpos( $feed_url, '//' ) ) {
			return $base['scheme'] . ':' . $feed_url;
		}
		if ( 0 === strpos( $feed_url, '/' ) ) {
			return $origin . $feed_url;
		}
		$path = $base['path'] ?? '/';
		if ( 0 === strpos( $feed_url, '?' ) ) {
			return $origin . $path . $feed_url;
		}
		$directory = trailingslashit( dirname( $path ) );
		return $origin . $directory . $feed_url;
	}

	private function fetch_url( $url ) {
		if ( ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'schuetzen_calendar_url', 'Die URL ist ungültig oder nicht öffentlich erreichbar.' );
		}
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 20,
				'redirection'         => 5,
				'limit_response_size' => 5 * MB_IN_BYTES,
				'user-agent'          => 'Schuetzen-App/' . SCHUETZEN_APP_VERSION . '; ' . home_url( '/' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'schuetzen_calendar_http', 'Die Quelle antwortet mit HTTP ' . $code . '.' );
		}
		return (string) wp_remote_retrieve_body( $response );
	}

	private function parse_calendar( $body ) {
		$lines    = preg_split( "/\r\n|\n|\r/", (string) $body );
		$unfolded = array();
		foreach ( $lines as $line ) {
			if ( isset( $line[0] ) && ( ' ' === $line[0] || "\t" === $line[0] ) && $unfolded ) {
				$unfolded[ count( $unfolded ) - 1 ] .= substr( $line, 1 );
			} else {
				$unfolded[] = $line;
			}
		}

		$events  = array();
		$current = null;
		foreach ( $unfolded as $line ) {
			if ( 'BEGIN:VEVENT' === strtoupper( trim( $line ) ) ) {
				$current = array();
				continue;
			}
			if ( 'END:VEVENT' === strtoupper( trim( $line ) ) ) {
				$event = $this->normalize_event( $current );
				if ( $event ) {
					$events[] = $event;
				}
				$current = null;
				continue;
			}
			if ( null === $current || ! preg_match( '/^([A-Z][A-Z0-9-]*)(;[^:]*)?:(.*)$/i', $line, $match ) ) {
				continue;
			}
			$current[ strtoupper( $match[1] ) ] = array(
				'params' => $match[2] ?? '',
				'value'  => $match[3],
			);
		}

		return $events;
	}

	private function normalize_event( $data ) {
		if ( ! is_array( $data ) || empty( $data['UID']['value'] ) || empty( $data['SUMMARY']['value'] ) || empty( $data['DTSTART']['value'] ) ) {
			return null;
		}
		$start = $this->parse_date( $data['DTSTART'] );
		if ( ! $start['date'] ) {
			return null;
		}
		$end = ! empty( $data['DTEND'] ) ? $this->parse_date( $data['DTEND'] ) : array( 'date' => '', 'time' => '', 'all_day' => false );
		if ( $start['all_day'] && $end['date'] ) {
			$end_date = DateTimeImmutable::createFromFormat( '!Y-m-d', $end['date'], wp_timezone() );
			$end['date'] = $end_date ? $end_date->modify( '-1 day' )->format( 'Y-m-d' ) : '';
		}

		return array(
			'uid'         => sanitize_text_field( $this->unescape( $data['UID']['value'] ) ),
			'title'       => sanitize_text_field( $this->unescape( $data['SUMMARY']['value'] ) ),
			'description' => isset( $data['DESCRIPTION']['value'] ) ? $this->unescape( $data['DESCRIPTION']['value'] ) : '',
			'date'        => $start['date'],
			'time'        => $start['time'],
			'end_date'    => $end['date'],
			'all_day'     => $start['all_day'],
			'location'    => isset( $data['LOCATION']['value'] ) ? sanitize_text_field( $this->unescape( $data['LOCATION']['value'] ) ) : '',
			'url'         => isset( $data['URL']['value'] ) ? esc_url_raw( $this->unescape( $data['URL']['value'] ) ) : '',
		);
	}

	private function parse_date( $property ) {
		$value   = trim( $property['value'] ?? '' );
		$params  = $property['params'] ?? '';
		$all_day = false !== stripos( $params, 'VALUE=DATE' ) || preg_match( '/^\d{8}$/', $value );
		if ( $all_day && preg_match( '/^(\d{4})(\d{2})(\d{2})$/', $value, $match ) ) {
			return array( 'date' => $match[1] . '-' . $match[2] . '-' . $match[3], 'time' => '', 'all_day' => true );
		}
		if ( ! preg_match( '/^(\d{8})T(\d{6})(Z)?$/', $value, $match ) ) {
			return array( 'date' => '', 'time' => '', 'all_day' => false );
		}

		$timezone      = wp_timezone();
		$convert_to_wp = false;
		if ( ! empty( $match[3] ) ) {
			$timezone      = new DateTimeZone( 'UTC' );
			$convert_to_wp = true;
		} elseif ( preg_match( '/TZID=([^;:]+)/i', $params, $timezone_match ) ) {
			try {
				$timezone = new DateTimeZone( trim( $timezone_match[1], '"' ) );
			} catch ( Exception $exception ) {
				$timezone = wp_timezone();
			}
		}
		$date = DateTimeImmutable::createFromFormat( '!Ymd\THis', $match[1] . 'T' . $match[2], $timezone );
		if ( ! $date ) {
			return array( 'date' => '', 'time' => '', 'all_day' => false );
		}
		if ( $convert_to_wp ) {
			$date = $date->setTimezone( wp_timezone() );
		}
		return array( 'date' => $date->format( 'Y-m-d' ), 'time' => $date->format( 'H:i' ), 'all_day' => false );
	}

	private function unescape( $value ) {
		return str_replace( array( '\\n', '\\N', '\\,', '\\;', '\\\\' ), array( "\n", "\n", ',', ';', '\\' ), (string) $value );
	}

	private function upsert_event( $source, $event ) {
		$external_key = $this->external_key( $source, $event );
		if ( Schuetzen_App_Blacklist::is_event_blacklisted( $source, $event, $external_key ) ) {
			return 'skipped';
		}
		$existing = get_posts(
			array(
				'post_type'      => 'schuetzen_event',
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_schuetzen_event_external_key',
				'meta_value'     => $external_key,
			)
		);
		if ( ! $existing ) {
			$legacy_match = $this->find_legacy_event_match( $source, $event );
			if ( $legacy_match ) {
				$existing = array( $legacy_match );
			}
		}
		if ( $existing && Schuetzen_App_Groups::freezes_imported_events( $source['group'] ) && metadata_exists( 'post', (int) $existing[0], '_schuetzen_event_external_key' ) ) {
			return 'skipped';
		}
		if ( $existing && empty( $event['date'] ) ) {
			return new WP_Error( 'schuetzen_calendar_invalid_date', 'Der Import liefert für einen bestehenden Termin kein gültiges Startdatum.' );
		}
		$post_data = array(
			'post_type'    => 'schuetzen_event',
			'post_title'   => $event['title'],
		);
		if ( $existing ) {
			$post_id = (int) $existing[0];
			$post_data['ID'] = $post_id;
			if ( ! metadata_exists( 'post', $post_id, '_schuetzen_event_source_description' ) ) {
				$current_content = (string) get_post_field( 'post_content', $post_id );
				if ( trim( $current_content ) === trim( wp_kses_post( $event['description'] ) ) ) {
					$post_data['post_content'] = '';
				}
			}
			$result = wp_update_post( wp_slash( $post_data ), true );
			$action = 'updated';
		} else {
			$post_data['post_status'] = $source['status'];
			$post_data['post_content'] = '';
			$result = wp_insert_post( wp_slash( $post_data ), true );
			$post_id = is_wp_error( $result ) ? 0 : (int) $result;
			$action = 'created';
		}
		if ( is_wp_error( $result ) || ! $post_id ) {
			return is_wp_error( $result ) ? $result : new WP_Error( 'schuetzen_calendar_save', 'Der Termin konnte nicht gespeichert werden.' );
		}

		$meta = array(
			'_schuetzen_event_date'         => $event['date'],
			'_schuetzen_event_time'         => $event['time'],
			'_schuetzen_event_end_date'     => $event['end_date'],
			'_schuetzen_event_all_day'      => $event['all_day'] ? '1' : '',
			'_schuetzen_event_location'     => $event['location'],
			'_schuetzen_event_category'     => $source['group'],
			'_schuetzen_event_external_key' => $external_key,
			'_schuetzen_event_external_uid' => $event['uid'],
			'_schuetzen_event_source_id'    => $source['id'],
			'_schuetzen_event_source_name'  => $source['name'],
			'_schuetzen_event_source_url'   => $event['url'] ?: $source['url'],
			'_schuetzen_event_source_description' => wp_kses_post( $event['description'] ),
		);
		foreach ( $meta as $key => $value ) {
			update_post_meta( $post_id, $key, $value );
		}

		return $action;
	}

	private function find_legacy_event_match( $source, $event ) {
		if ( empty( $event['title'] ) || empty( $event['date'] ) ) {
			return 0;
		}

		$candidates = get_posts(
			array(
				'post_type'      => 'schuetzen_event',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'   => '_schuetzen_event_date',
						'value' => $event['date'],
					),
					array(
						'key'   => '_schuetzen_event_category',
						'value' => $source['group'],
					),
				),
			)
		);

		foreach ( $candidates as $post_id ) {
			if ( metadata_exists( 'post', $post_id, '_schuetzen_event_external_key' ) ) {
				continue;
			}
			if ( get_the_title( $post_id ) !== $event['title'] ) {
				continue;
			}
			if ( (string) get_post_meta( $post_id, '_schuetzen_event_end_date', true ) !== (string) $event['end_date'] ) {
				continue;
			}
			if ( (string) get_post_meta( $post_id, '_schuetzen_event_all_day', true ) !== ( $event['all_day'] ? '1' : '' ) ) {
				continue;
			}
			return (int) $post_id;
		}

		return 0;
	}

	private function external_key( $source, $event ) {
		return hash( 'sha256', $source['id'] . '|' . ( $event['uid'] ?? '' ) );
	}

	private function remove_imported_event( $source, $event ) {
		$post_ids = get_posts(
			array(
				'post_type'      => 'schuetzen_event',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => '_schuetzen_event_external_key',
				'meta_value'     => $this->external_key( $source, $event ),
			)
		);
		$removed = false;
		foreach ( $post_ids as $post_id ) {
			if ( wp_delete_post( $post_id, true ) ) {
				$removed = true;
			}
		}
		return $removed;
	}

	private function save_status( $source_id, $created, $updated, $skipped, $error ) {
		$status = get_option( 'schuetzen_app_calendar_status', array() );
		$status = is_array( $status ) ? $status : array();
		$status[ $source_id ] = array(
			'time'    => time(),
			'created' => absint( $created ),
			'updated' => absint( $updated ),
			'skipped' => absint( $skipped ),
			'error'   => sanitize_text_field( $error ),
		);
		update_option( 'schuetzen_app_calendar_status', $status, false );
	}
}
