<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Groups {
	public static function get() {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$settings = is_array( $settings ) ? $settings : array();
		$groups   = self::sanitize( $settings['groups'] ?? array() );

		return $groups ?: self::defaults( $settings );
	}

	public static function defaults( $settings = array() ) {
		$defaults = array(
			array( 'id' => 'zug', 'name' => 'Zug', 'color' => '#d6a84f', 'opacity' => 100, 'always_visible' => 0, 'collector_priority' => 0, 'freeze_imported' => 0 ),
			array( 'id' => 'korps', 'name' => 'Korps', 'color' => '#008037', 'opacity' => 100, 'always_visible' => 0, 'collector_priority' => 0, 'freeze_imported' => 0 ),
			array( 'id' => 'regiment', 'name' => 'Regiment', 'color' => '#D2071F', 'opacity' => 100, 'always_visible' => 0, 'collector_priority' => 0, 'freeze_imported' => 0 ),
		);

		foreach ( $defaults as &$group ) {
			$legacy_color = sanitize_hex_color( $settings[ 'color_' . $group['id'] ] ?? '' );
			if ( $legacy_color ) {
				$group['color'] = $legacy_color;
			}
			$group['opacity'] = min( 100, max( 0, absint( $settings[ 'color_' . $group['id'] . '_opacity' ] ?? 100 ) ) );
		}
		unset( $group );

		return $defaults;
	}

	public static function sanitize( $groups ) {
		$clean = array();
		$used  = array();

		foreach ( array_slice( (array) $groups, 0, 30 ) as $group ) {
			$name = sanitize_text_field( $group['name'] ?? '' );
			$id   = sanitize_key( $group['id'] ?? '' );
			if ( '' === $name ) {
				continue;
			}
			if ( '' === $id ) {
				$id = sanitize_title( $name );
			}
			if ( '' === $id || isset( $used[ $id ] ) ) {
				continue;
			}

			$used[ $id ] = true;
			$clean[] = array(
				'id'             => $id,
				'name'           => $name,
				'color'          => sanitize_hex_color( $group['color'] ?? '' ) ?: '#4b5563',
				'opacity'        => min( 100, max( 0, absint( $group['opacity'] ?? 100 ) ) ),
				'always_visible' => ! empty( $group['always_visible'] ) ? 1 : 0,
				'collector_priority' => ! empty( $group['collector_priority'] ) ? 1 : 0,
				'freeze_imported' => ! empty( $group['freeze_imported'] ) ? 1 : 0,
			);
		}

		return $clean;
	}

	public static function labels() {
		$labels = array();
		foreach ( self::get() as $group ) {
			$labels[ $group['id'] ] = $group['name'];
		}
		return $labels;
	}

	public static function is_valid( $id ) {
		return isset( self::labels()[ sanitize_key( $id ) ] );
	}

	public static function primary_id() {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$settings = is_array( $settings ) ? $settings : array();
		$groups   = self::get();
		$primary  = sanitize_key( $settings['primary_group'] ?? '' );

		foreach ( $groups as $group ) {
			if ( $primary === $group['id'] ) {
				return $primary;
			}
		}

		return $groups[0]['id'] ?? '';
	}

	public static function color_map() {
		$colors = array();
		foreach ( self::get() as $group ) {
			$colors[ $group['id'] ] = self::rgba( $group['color'], $group['opacity'] );
		}
		return $colors;
	}

	public static function collector_priority_ids() {
		$ids = array();
		foreach ( self::get() as $group ) {
			if ( ! empty( $group['collector_priority'] ) ) {
				$ids[] = $group['id'];
			}
		}
		return $ids;
	}

	public static function freezes_imported_events( $id ) {
		$id = sanitize_key( $id );
		foreach ( self::get() as $group ) {
			if ( $group['id'] === $id ) {
				return ! empty( $group['freeze_imported'] );
			}
		}
		return false;
	}

	private static function rgba( $hex, $opacity ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		return sprintf(
			'rgba(%d,%d,%d,%.2f)',
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
			min( 100, max( 0, absint( $opacity ) ) ) / 100
		);
	}
}
