<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Transfer {
	const SCHEMA_VERSION = 2;
	const BLACKLIST_OPTION = 'schuetzen_app_blacklist';
	const DATASETS = array( 'settings', 'events', 'messages', 'infos', 'persons', 'march_orders', 'groups', 'calendar_sources', 'blacklist' );

	public function __construct() {
		add_action( 'admin_post_schuetzen_app_export_bundle', array( $this, 'export_bundle' ) );
		add_action( 'admin_post_schuetzen_app_import_bundle', array( $this, 'import_bundle' ) );
	}

	public static function render_panel() {
		?>
		<hr>
		<h2>Schützen-App-Transfer</h2>
		<p>Hier werden Einstellungen und Inhalte in einer gemeinsamen, modularen JSON-Datei übertragen. Du wählst für Export und Import genau die Bereiche aus, die benötigt werden.</p>
		<h3>Export</h3>
		<p>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="settings" checked form="schuetzen-app-export-form"> Design und App-Einstellungen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="events" checked form="schuetzen-app-export-form"> Termine inklusive Meta-Informationen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="messages" checked form="schuetzen-app-export-form"> Nachrichten</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="infos" checked form="schuetzen-app-export-form"> Infos</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="persons" checked form="schuetzen-app-export-form"> Personen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="march_orders" checked form="schuetzen-app-export-form"> Marschordnungen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="groups" checked form="schuetzen-app-export-form"> Gruppen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="calendar_sources" checked form="schuetzen-app-export-form"> Kalenderquellen</label><br>
			<label><input type="checkbox" name="schuetzen_app_export_datasets[]" value="blacklist" checked form="schuetzen-app-export-form"> Blacklist und Blacklist-Regeln</label>
		</p>
		<p><label><input type="checkbox" name="schuetzen_app_export_private_urls" value="1" form="schuetzen-app-export-form"> Sensible Daten einschließen (private iCal-Adressen)</label><br><small>Benutzer, Passwörter, Rollen und Zugriffsrechte werden niemals exportiert. Private URLs nur in einer vertraulichen Datei einschließen.</small></p>
		<p><button type="submit" class="button button-primary" form="schuetzen-app-export-form">Ausgewählte Daten als JSON herunterladen</button></p>
		<h3>Import</h3>
		<p>Der Import arbeitet standardmäßig ergänzend: neue Inhalte werden angelegt, vorhandene Inhalte mit derselben Transfer-ID aktualisiert. Nicht enthaltene Daten werden nicht gelöscht.</p>
		<p><input type="file" name="schuetzen_app_bundle_file" accept="application/json,.json" required form="schuetzen-app-bundle-import-form"></p>
		<p>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="settings" checked form="schuetzen-app-bundle-import-form"> Design und App-Einstellungen</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="events" checked form="schuetzen-app-bundle-import-form"> Termine inklusive Meta-Informationen</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="messages" checked form="schuetzen-app-bundle-import-form"> Nachrichten</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="infos" checked form="schuetzen-app-bundle-import-form"> Infos</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="persons" checked form="schuetzen-app-bundle-import-form"> Personen</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="march_orders" checked form="schuetzen-app-bundle-import-form"> Marschordnungen</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="groups" checked form="schuetzen-app-bundle-import-form"> Gruppen</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="calendar_sources" form="schuetzen-app-bundle-import-form"> Kalenderquellen</label><br>
			<label><input type="checkbox" name="schuetzen_app_import_datasets[]" value="blacklist" checked form="schuetzen-app-bundle-import-form"> Blacklist und Regeln</label>
		</p>
		<p><button type="submit" class="button button-primary" form="schuetzen-app-bundle-import-form" onclick="return window.confirm('Die ausgewählten Schützen-App-Daten werden ergänzend importiert. Fortfahren?');">Ausgewählte Daten importieren</button></p>
		<p class="description">Medien werden als Referenzen übertragen; die eigentlichen Dateien bleiben im jeweiligen WordPress-Medienspeicher. Der bisherige Einstellungs-Transfer bleibt für alte Dateien intern kompatibel.</p>
		<?php
	}

	public function export_bundle() {
		$this->require_admin( 'Keine Berechtigung für den Schützen-App-Export.' );
		check_admin_referer( 'schuetzen_app_export_bundle' );
		$datasets = array_values( array_intersect( self::DATASETS, array_map( 'sanitize_key', (array) ( $_POST['schuetzen_app_export_datasets'] ?? self::DATASETS ) ) ) );
		$payload = array(
			'type' => 'schuetzen-app-bundle',
			'schema_version' => self::SCHEMA_VERSION,
			'plugin_version' => SCHUETZEN_APP_VERSION,
			'exported_at' => gmdate( 'c' ),
			'datasets' => array(),
		);
		if ( in_array( 'settings', $datasets, true ) ) $payload['datasets']['settings'] = $this->export_settings();
		if ( in_array( 'groups', $datasets, true ) ) $payload['datasets']['groups'] = Schuetzen_App_Groups::get();
		if ( in_array( 'calendar_sources', $datasets, true ) ) $payload['datasets']['calendar_sources'] = $this->export_sources( ! empty( $_POST['schuetzen_app_export_private_urls'] ) );
		if ( in_array( 'march_orders', $datasets, true ) ) $payload['datasets']['march_orders'] = $this->export_march_orders();
		if ( in_array( 'events', $datasets, true ) ) $payload['datasets']['events'] = $this->export_events();
		foreach ( array( 'messages', 'infos', 'persons' ) as $type ) if ( in_array( $type, $datasets, true ) ) $payload['datasets'][ $type ] = $this->export_posts( 'schuetzen_' . rtrim( $type, 's' ) );
		if ( in_array( 'blacklist', $datasets, true ) ) $payload['datasets']['blacklist'] = get_option( self::BLACKLIST_OPTION, array( 'entries' => array(), 'rules' => array() ) );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="schuetzen-app-daten-' . gmdate( 'Y-m-d' ) . '.json"' );
		echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	public function import_bundle() {
		$this->require_admin( 'Keine Berechtigung für den Schützen-App-Import.' );
		check_admin_referer( 'schuetzen_app_import_bundle' );
		$file = $_FILES['schuetzen_app_bundle_file'] ?? array();
		if ( ! is_array( $file ) || ! is_uploaded_file( $file['tmp_name'] ?? '' ) || UPLOAD_ERR_OK !== (int) ( $file['error'] ?? 0 ) || (int) ( $file['size'] ?? 0 ) > MB_IN_BYTES ) {
			$this->redirect( 'import-error' );
		}
		$payload = json_decode( (string) file_get_contents( $file['tmp_name'] ), true );
		if ( ! is_array( $payload ) || 'schuetzen-app-bundle' !== ( $payload['type'] ?? '' ) || ! in_array( (int) ( $payload['schema_version'] ?? 0 ), array( 1, self::SCHEMA_VERSION ), true ) || ! is_array( $payload['datasets'] ?? null ) ) {
			$this->redirect( 'import-invalid' );
		}
		$result = array( 'created' => 0, 'updated' => 0, 'skipped' => 0 );
		$datasets = $payload['datasets'];
		$selected = array_values( array_intersect( self::DATASETS, array_map( 'sanitize_key', (array) ( $_POST['schuetzen_app_import_datasets'] ?? self::DATASETS ) ) ) );
		if ( in_array( 'settings', $selected, true ) && isset( $datasets['settings'] ) ) $this->import_settings( $datasets['settings'] );
		$march_map = in_array( 'march_orders', $selected, true ) ? $this->import_march_orders( $datasets['march_orders'] ?? array(), $result ) : array();
		if ( in_array( 'groups', $selected, true ) && isset( $datasets['groups'] ) ) update_option( 'schuetzen_app_settings', $this->merge_groups( $datasets['groups'] ), false );
		if ( in_array( 'calendar_sources', $selected, true ) && isset( $datasets['calendar_sources'] ) ) $this->import_sources( $datasets['calendar_sources'], $result );
		if ( in_array( 'events', $selected, true ) ) $this->import_events( $datasets['events'] ?? array(), $march_map, $result );
		foreach ( array( 'messages', 'infos', 'persons' ) as $type ) if ( in_array( $type, $selected, true ) ) $this->import_posts( 'schuetzen_' . rtrim( $type, 's' ), $datasets[ $type ] ?? array(), $result );
		if ( in_array( 'blacklist', $selected, true ) && isset( $datasets['blacklist'] ) ) update_option( self::BLACKLIST_OPTION, $this->merge_blacklist( $datasets['blacklist'] ), false );
		set_transient( 'schuetzen_app_transfer_notice_' . get_current_user_id(), $result, 120 );
		$this->redirect( 'bundle-imported' );
	}

	private function export_settings() {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$settings = is_array( $settings ) ? $settings : array();
		unset( $settings['groups'], $settings['calendar_sources'] );
		return $settings;
	}

	private function import_settings( $settings ) {
		$current = get_option( 'schuetzen_app_settings', array() );
		$current = is_array( $current ) ? $current : array();
		$groups  = $current['groups'] ?? array();
		$sources = $current['calendar_sources'] ?? array();
		$merged  = array_merge( $current, is_array( $settings ) ? $settings : array() );
		$merged['groups'] = $groups;
		$merged['calendar_sources'] = $sources;
		update_option( 'schuetzen_app_settings', $merged, false );
	}

	private function export_posts( $post_type ) {
		$items = array();
		foreach ( get_posts( array( 'post_type' => $post_type, 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $post ) {
			$key = get_post_meta( $post->ID, '_schuetzen_transfer_key', true );
			$key = $key ?: hash( 'sha256', $post_type . '|' . $post->post_title . '|' . $post->ID );
			$meta = array();
			foreach ( get_post_meta( $post->ID ) as $meta_key => $values ) {
				if ( '_edit_' === substr( $meta_key, 0, 6 ) || '_schuetzen_transfer_key' === $meta_key ) continue;
				$meta[ $meta_key ] = count( $values ) === 1 ? maybe_unserialize( $values[0] ) : array_map( 'maybe_unserialize', $values );
			}
			$items[] = array( 'key' => $key, 'title' => $post->post_title, 'content' => $post->post_content, 'status' => $post->post_status, 'meta' => $meta, 'image_url' => get_the_post_thumbnail_url( $post->ID, 'full' ) ?: '' );
		}
		return $items;
	}

	private function import_posts( $post_type, $items, &$result ) {
		$allowed = array( 'schuetzen_message', 'schuetzen_info', 'schuetzen_person' );
		if ( ! in_array( $post_type, $allowed, true ) ) return;
		foreach ( (array) $items as $item ) {
			$key = sanitize_text_field( $item['key'] ?? '' );
			if ( '' === $key || empty( $item['title'] ) ) { $result['skipped']++; continue; }
			$existing = get_posts( array( 'post_type' => $post_type, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_schuetzen_transfer_key', 'meta_value' => $key ) );
			$data = array( 'post_type' => $post_type, 'post_title' => sanitize_text_field( $item['title'] ), 'post_content' => wp_kses_post( $item['content'] ?? '' ), 'post_status' => in_array( $item['status'] ?? 'draft', array( 'publish', 'draft', 'pending', 'private' ), true ) ? $item['status'] : 'draft' );
			if ( $existing ) { $data['ID'] = (int) $existing[0]; $post_id = wp_update_post( wp_slash( $data ), true ); $action = 'updated'; } else { $post_id = wp_insert_post( wp_slash( $data ), true ); $action = 'created'; }
			if ( is_wp_error( $post_id ) ) { $result['skipped']++; continue; }
			update_post_meta( $post_id, '_schuetzen_transfer_key', $key );
			foreach ( (array) ( $item['meta'] ?? array() ) as $meta_key => $value ) {
				$meta_key = sanitize_key( $meta_key );
				if ( 0 !== strpos( $meta_key, '_schuetzen_' ) ) continue;
				update_post_meta( $post_id, $meta_key, is_scalar( $value ) ? sanitize_text_field( $value ) : $value );
			}
			$result[ $action ]++;
		}
	}

	private function export_events() {
		$items = array();
		foreach ( get_posts( array( 'post_type' => 'schuetzen_event', 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $post ) {
			$date = get_post_meta( $post->ID, '_schuetzen_event_date', true );
			$category = get_post_meta( $post->ID, '_schuetzen_event_category', true );
			$key = get_post_meta( $post->ID, '_schuetzen_event_external_key', true ) ?: hash( 'sha256', $post->post_title . '|' . $date . '|' . $category );
			$march_id = absint( get_post_meta( $post->ID, '_schuetzen_event_march_order', true ) );
			$items[] = array( 'key' => $key, 'title' => $post->post_title, 'content' => $post->post_content, 'status' => $post->post_status, 'meta' => array( 'date' => $date, 'end_date' => get_post_meta( $post->ID, '_schuetzen_event_end_date', true ), 'time' => get_post_meta( $post->ID, '_schuetzen_event_time', true ), 'time_approx' => get_post_meta( $post->ID, '_schuetzen_event_time_approx', true ), 'time_after' => get_post_meta( $post->ID, '_schuetzen_event_time_after', true ), 'time_after_text' => get_post_meta( $post->ID, '_schuetzen_event_time_after_text', true ), 'location' => get_post_meta( $post->ID, '_schuetzen_event_location', true ), 'meeting_point' => get_post_meta( $post->ID, '_schuetzen_event_meeting_point', true ), 'category' => $category, 'all_day' => get_post_meta( $post->ID, '_schuetzen_event_all_day', true ), 'collector_disabled' => get_post_meta( $post->ID, '_schuetzen_event_collector_disabled', true ), 'internal' => get_post_meta( $post->ID, '_schuetzen_event_internal', true ), 'source_id' => get_post_meta( $post->ID, '_schuetzen_event_source_id', true ), 'source_name' => get_post_meta( $post->ID, '_schuetzen_event_source_name', true ) ), 'march_order_key' => $march_id ? $this->march_key( $march_id ) : '' );
		}
		return $items;
	}

	private function export_march_orders() {
		$items = array();
		foreach ( get_posts( array( 'post_type' => 'schuetzen_march', 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $post ) $items[] = array( 'key' => $this->march_key( $post->ID ), 'title' => $post->post_title, 'status' => $post->post_status, 'blocks' => get_post_meta( $post->ID, '_schuetzen_march_order_blocks', true ) );
		return $items;
	}

	private function export_sources( $include_urls ) {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$sources = Schuetzen_App_Calendar_Sources::sanitize_sources( is_array( $settings ) ? ( $settings['calendar_sources'] ?? array() ) : array() );
		if ( ! $include_urls ) foreach ( $sources as &$source ) $source['url'] = '';
		return $sources;
	}

	private function import_events( $items, $march_map, &$result ) {
		foreach ( (array) $items as $item ) {
			$key = sanitize_text_field( $item['key'] ?? '' );
			if ( '' === $key || empty( $item['title'] ) ) { $result['skipped']++; continue; }
			$existing = get_posts( array( 'post_type' => 'schuetzen_event', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_schuetzen_transfer_key', 'meta_value' => $key ) );
			$data = array( 'post_type' => 'schuetzen_event', 'post_title' => sanitize_text_field( $item['title'] ), 'post_content' => wp_kses_post( $item['content'] ?? '' ), 'post_status' => in_array( $item['status'] ?? 'draft', array( 'publish', 'draft', 'pending', 'private' ), true ) ? $item['status'] : 'draft' );
			if ( $existing ) { $data['ID'] = (int) $existing[0]; $post_id = wp_update_post( wp_slash( $data ), true ); $action = 'updated'; } else { $post_id = wp_insert_post( wp_slash( $data ), true ); $action = 'created'; }
			if ( is_wp_error( $post_id ) ) { $result['skipped']++; continue; }
			update_post_meta( $post_id, '_schuetzen_transfer_key', $key );
			foreach ( (array) ( $item['meta'] ?? array() ) as $meta_key => $value ) update_post_meta( $post_id, '_schuetzen_event_' . sanitize_key( $meta_key ), sanitize_text_field( $value ) );
			if ( ! empty( $item['march_order_key'] ) && isset( $march_map[ $item['march_order_key'] ] ) ) update_post_meta( $post_id, '_schuetzen_event_march_order', $march_map[ $item['march_order_key'] ] );
			$result[ $action ]++;
		}
	}

	private function import_march_orders( $items, &$result ) {
		$map = array();
		foreach ( (array) $items as $item ) {
			$key = sanitize_text_field( $item['key'] ?? '' ); if ( '' === $key || empty( $item['title'] ) ) { $result['skipped']++; continue; }
			$existing = get_posts( array( 'post_type' => 'schuetzen_march', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_schuetzen_transfer_key', 'meta_value' => $key ) );
			$data = array( 'post_type' => 'schuetzen_march', 'post_title' => sanitize_text_field( $item['title'] ), 'post_status' => 'publish' ); if ( $existing ) { $data['ID'] = (int) $existing[0]; $id = wp_update_post( wp_slash( $data ), true ); $action = 'updated'; } else { $id = wp_insert_post( wp_slash( $data ), true ); $action = 'created'; }
			if ( is_wp_error( $id ) ) { $result['skipped']++; continue; } update_post_meta( $id, '_schuetzen_transfer_key', $key ); update_post_meta( $id, '_schuetzen_march_order_blocks', is_array( $item['blocks'] ?? null ) ? $item['blocks'] : array() ); $map[ $key ] = (int) $id; $result[ $action ]++;
		}
		return $map;
	}

	private function merge_groups( $groups ) { $settings = get_option( 'schuetzen_app_settings', array() ); $settings['groups'] = is_array( $groups ) ? Schuetzen_App_Groups::sanitize( $groups ) : ( $settings['groups'] ?? array() ); return $settings; }
	private function import_sources( $sources, &$result ) {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$current  = Schuetzen_App_Calendar_Sources::sanitize_sources( (array) ( $settings['calendar_sources'] ?? array() ) );
		foreach ( (array) $sources as $source ) {
			if ( empty( $source['url'] ) ) { $result['skipped']++; continue; }
			$source = Schuetzen_App_Calendar_Sources::sanitize_sources( array( $source ) )[0] ?? array();
			$matched = false;
			foreach ( $current as $index => $existing ) {
				if ( ( ! empty( $source['id'] ) && (string) $source['id'] === (string) ( $existing['id'] ?? '' ) ) || ( ! empty( $source['name'] ) && $source['name'] === ( $existing['name'] ?? '' ) ) ) { $current[ $index ] = array_merge( $existing, $source ); $matched = true; break; }
			}
			if ( ! $matched ) $current[] = $source;
		}
		$settings['calendar_sources'] = Schuetzen_App_Calendar_Sources::sanitize_sources( $current );
		update_option( 'schuetzen_app_settings', $settings, false );
		$result['updated']++;
	}
	private function merge_blacklist( $blacklist ) { $current = get_option( self::BLACKLIST_OPTION, array( 'entries' => array(), 'rules' => array() ) ); return array( 'entries' => array_values( array_unique( array_merge( (array) ( $current['entries'] ?? array() ), (array) ( $blacklist['entries'] ?? array() ) ), SORT_REGULAR ) ), 'rules' => array_values( array_unique( array_merge( (array) ( $current['rules'] ?? array() ), (array) ( $blacklist['rules'] ?? array() ) ), SORT_REGULAR ) ) ); }
	private function march_key( $post_id ) { return hash( 'sha256', 'march|' . (int) $post_id . '|' . get_the_title( $post_id ) ); }
	private function require_admin( $message ) { if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html( $message ) ); }
	private function redirect( $status ) { wp_safe_redirect( add_query_arg( array( 'page' => 'schuetzen-app', 'tab' => 'transfer', 'transfer_status' => sanitize_key( $status ) ), admin_url( 'admin.php' ) ) ); exit; }
}
