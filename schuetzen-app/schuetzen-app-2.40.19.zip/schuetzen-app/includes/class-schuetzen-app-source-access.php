<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Source_Access {
	const USER_META_KEY = '_schuetzen_app_allowed_sources';

	public function __construct() {
		add_action( 'show_user_profile', array( $this, 'render_user_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'render_user_fields' ) );
		add_action( 'personal_options_update', array( $this, 'save_user_fields' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_user_fields' ) );
	}

	public static function restricted_sources() {
		$settings = get_option( 'schuetzen_app_settings', array() );
		$sources  = Schuetzen_App_Calendar_Sources::sanitize_sources( is_array( $settings ) ? ( $settings['calendar_sources'] ?? array() ) : array() );
		return array_values( array_filter( $sources, static function ( $source ) { return ! empty( $source['restricted'] ); } ) );
	}

	public static function can_view_source( $source_id, $user_id = 0 ) {
		$source_id = sanitize_key( $source_id );
		if ( '' === $source_id ) {
			return true;
		}
		if ( ! in_array( $source_id, wp_list_pluck( self::restricted_sources(), 'id' ), true ) ) {
			return true;
		}
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		return $user_id && in_array( $source_id, self::user_source_ids( $user_id ), true );
	}

	public static function user_source_ids( $user_id ) {
		return array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) get_user_meta( absint( $user_id ), self::USER_META_KEY, true ) ) ) ) );
	}

	public function render_user_fields( $user ) {
		if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}
		$sources = self::restricted_sources();
		if ( ! $sources ) {
			return;
		}
		$assigned = self::user_source_ids( $user->ID );
		$groups   = Schuetzen_App_Groups::labels();
		wp_nonce_field( 'schuetzen_app_source_access', 'schuetzen_app_source_access_nonce' );
		?>
		<h2>Schützen-App: geschützte Kalenderquellen</h2>
		<p>Lege fest, welche eingeschränkten Kalenderquellen dieser Benutzer nach der Anmeldung sehen darf.</p>
		<table class="form-table" role="presentation"><tr><th>Quellen freigeben</th><td><fieldset>
			<?php foreach ( $sources as $source ) : ?>
				<label><input type="checkbox" name="schuetzen_app_allowed_sources[]" value="<?php echo esc_attr( $source['id'] ); ?>" <?php checked( in_array( $source['id'], $assigned, true ) ); ?>> <strong><?php echo esc_html( $source['name'] ); ?></strong><?php if ( ! empty( $source['group'] ) && isset( $groups[ $source['group'] ] ) ) : ?><br><span class="description">Gruppe: <?php echo esc_html( $groups[ $source['group'] ] ); ?></span><?php endif; ?></label><br>
			<?php endforeach; ?>
		</fieldset></td></tr></table>
		<?php
	}

	public function save_user_fields( $user_id ) {
		if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}
		if ( ! isset( $_POST['schuetzen_app_source_access_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_app_source_access_nonce'] ) ), 'schuetzen_app_source_access' ) ) {
			return;
		}
		$valid_ids = wp_list_pluck( self::restricted_sources(), 'id' );
		$selected  = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) wp_unslash( $_POST['schuetzen_app_allowed_sources'] ?? array() ) ), static function ( $source_id ) use ( $valid_ids ) { return in_array( $source_id, $valid_ids, true ); } ) ) );
		update_user_meta( $user_id, self::USER_META_KEY, $selected );
	}
}
