<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Content {
	public function __construct() {
		add_action( 'init', array( $this, 'register_content_types' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_event_meta_box' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_person_meta_box' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_march_order_meta_box' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_info_meta_box' ) );
		add_action( 'save_post_schuetzen_event', array( $this, 'save_event_meta' ), 10, 2 );
		add_action( 'save_post_schuetzen_person', array( $this, 'save_person_meta' ), 10, 2 );
		add_action( 'save_post_schuetzen_march', array( $this, 'save_march_order_meta' ), 10, 2 );
		add_action( 'save_post_schuetzen_info', array( $this, 'save_info_meta' ), 10, 2 );
		add_filter( 'manage_schuetzen_event_posts_columns', array( $this, 'event_admin_columns' ) );
		add_action( 'manage_schuetzen_event_posts_custom_column', array( $this, 'render_event_admin_column' ), 10, 2 );
		add_action( 'pre_get_posts', array( $this, 'sort_event_admin_list' ) );
	}

	public function register_content_types() {
		register_post_type(
			'schuetzen_event',
			array(
				'labels'       => array(
					'name'          => 'Termine',
					'singular_name' => 'Termin',
					'add_new_item'  => 'Termin hinzufügen',
					'edit_item'     => 'Termin bearbeiten',
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => true,
				'menu_icon'     => 'dashicons-calendar-alt',
				'supports'      => array( 'title', 'editor', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_message',
			array(
				'labels'      => array(
					'name'          => 'Nachrichten',
					'singular_name' => 'Nachricht',
					'add_new_item'  => 'Nachricht hinzufügen',
					'edit_item'     => 'Nachricht bearbeiten',
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => true,
				'menu_icon'    => 'dashicons-megaphone',
				'supports'     => array( 'title', 'editor', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_info',
			array(
				'labels'      => array(
					'name'          => 'Infos',
					'singular_name' => 'Info',
					'add_new_item'  => 'Info hinzufügen',
					'edit_item'     => 'Info bearbeiten',
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => true,
				'menu_icon'    => 'dashicons-info-outline',
				'supports'     => array( 'title', 'editor', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_person',
			array(
				'labels'       => array(
					'name'          => 'Personen',
					'singular_name' => 'Person',
					'add_new_item'  => 'Person hinzufügen',
					'edit_item'     => 'Person bearbeiten',
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => true,
				'menu_icon'     => 'dashicons-id-alt',
				'supports'      => array( 'title', 'thumbnail' ),
			)
		);

		register_post_type(
			'schuetzen_march',
			array(
				'labels'       => array(
					'name'          => 'Marschordnungen',
					'singular_name' => 'Marschordnung',
					'add_new_item'  => 'Marschordnung hinzufügen',
					'edit_item'     => 'Marschordnung bearbeiten',
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => true,
				'menu_icon'     => 'dashicons-grid-view',
				'supports'      => array( 'title' ),
			)
		);
	}

	public function event_admin_columns( $columns ) {
		if ( isset( $columns['date'] ) ) {
			$columns['date'] = 'Termin';
		}
		return $columns;
	}

	public function render_event_admin_column( $column, $post_id ) {
		if ( 'date' !== $column ) {
			return;
		}

		$date = get_post_meta( $post_id, '_schuetzen_event_date', true );
		$time = get_post_meta( $post_id, '_schuetzen_event_time', true );
		if ( ! $date ) {
			echo '&mdash;';
			return;
		}

		$timestamp = strtotime( trim( $date . ' ' . $time ) );
		echo esc_html( $timestamp ? wp_date( 'd.m.Y', $timestamp ) : $date );
		if ( $time ) {
			echo '<br>' . esc_html( $time ) . ' Uhr';
		}
	}

	public function sort_event_admin_list( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || 'schuetzen_event' !== $query->get( 'post_type' ) ) {
			return;
		}

		global $wpdb;
		$query->set( 'orderby', 'none' );
		$query->set( 'order', 'ASC' );
		add_filter(
			'posts_clauses',
			static function ( $clauses, $query ) use ( $wpdb ) {
				if ( ! $query->is_main_query() || 'schuetzen_event' !== $query->get( 'post_type' ) ) {
					return $clauses;
				}

				$clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS schuetzen_event_date_sort ON ({$wpdb->posts}.ID = schuetzen_event_date_sort.post_id AND schuetzen_event_date_sort.meta_key = '_schuetzen_event_date')";
				$clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS schuetzen_event_time_sort ON ({$wpdb->posts}.ID = schuetzen_event_time_sort.post_id AND schuetzen_event_time_sort.meta_key = '_schuetzen_event_time')";
				$clauses['orderby'] = "CASE WHEN schuetzen_event_date_sort.meta_value IS NULL OR schuetzen_event_date_sort.meta_value = '' THEN 1 ELSE 0 END ASC, schuetzen_event_date_sort.meta_value ASC, schuetzen_event_time_sort.meta_value ASC, {$wpdb->posts}.ID DESC";
				return $clauses;
			},
			20,
			2
		);
	}

	public function add_event_meta_box() {
		add_meta_box(
			'schuetzen-event-details',
			'Terminangaben',
			array( $this, 'render_event_meta_box' ),
			'schuetzen_event',
			'normal',
			'high'
		);
	}

	public function render_event_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_event_details', 'schuetzen_event_nonce' );
		$date     = get_post_meta( $post->ID, '_schuetzen_event_date', true );
		$time     = get_post_meta( $post->ID, '_schuetzen_event_time', true );
		$location = get_post_meta( $post->ID, '_schuetzen_event_location', true );
		$category = get_post_meta( $post->ID, '_schuetzen_event_category', true );
		$march_order = get_post_meta( $post->ID, '_schuetzen_event_march_order', true );
		$orders = get_posts( array( 'post_type' => 'schuetzen_march', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		?>
		<p>
			<label for="schuetzen_event_date"><strong>Datum</strong></label><br>
			<input type="date" id="schuetzen_event_date" name="schuetzen_event_date" value="<?php echo esc_attr( $date ); ?>">
		</p>
		<p>
			<label for="schuetzen_event_time"><strong>Uhrzeit</strong></label><br>
			<input type="time" id="schuetzen_event_time" name="schuetzen_event_time" value="<?php echo esc_attr( $time ); ?>">
		</p>
		<p>
			<label for="schuetzen_event_location"><strong>Ort</strong></label><br>
			<input type="text" class="widefat" id="schuetzen_event_location" name="schuetzen_event_location" value="<?php echo esc_attr( $location ); ?>">
		</p>
		<p>
			<label for="schuetzen_event_category"><strong>Gruppe</strong></label><br>
			<select class="widefat" id="schuetzen_event_category" name="schuetzen_event_category">
				<option value="" <?php selected( $category, '' ); ?>>Keine Zuordnung</option>
				<option value="zug" <?php selected( $category, 'zug' ); ?>>Zug</option>
				<option value="korps" <?php selected( $category, 'korps' ); ?>>Korps</option>
				<option value="regiment" <?php selected( $category, 'regiment' ); ?>>Regiment</option>
			</select>
			<small>Die Gruppe bestimmt die Farbe des linken Randes der Termin-Card.</small>
		</p>
		<p>
			<label for="schuetzen_event_march_order"><strong>Marschordnung</strong></label><br>
			<select class="widefat" id="schuetzen_event_march_order" name="schuetzen_event_march_order">
				<option value="">Keine Marschordnung</option>
				<?php foreach ( $orders as $order ) : ?>
					<option value="<?php echo esc_attr( $order->ID ); ?>" <?php selected( (int) $march_order, $order->ID ); ?>><?php echo esc_html( $order->post_title ); ?></option>
				<?php endforeach; ?>
			</select>
			<small>Die Marschordnung wird auf der Termin-Detailseite angezeigt.</small>
		</p>
		<?php
	}

	public function add_person_meta_box() {
		add_meta_box( 'schuetzen-person-role', 'Rolle', array( $this, 'render_person_meta_box' ), 'schuetzen_person', 'side', 'high' );
	}

	public function render_person_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_person_details', 'schuetzen_person_nonce' );
		$role = get_post_meta( $post->ID, '_schuetzen_person_role', true );
		?>
		<label for="schuetzen_person_role">Rolle (optional)</label>
		<input type="text" class="widefat" id="schuetzen_person_role" name="schuetzen_person_role" value="<?php echo esc_attr( $role ); ?>">
		<p class="description">Zum Beispiel Hauptmann oder Fahnenschwenker.</p>
		<?php
	}

	public function add_march_order_meta_box() {
		add_meta_box( 'schuetzen-march-order-rows', 'Reihenfolge', array( $this, 'render_march_order_meta_box' ), 'schuetzen_march', 'normal', 'high' );
	}

	public function render_march_order_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_march_order_details', 'schuetzen_march_order_nonce' );
		$blocks = get_post_meta( $post->ID, '_schuetzen_march_order_blocks', true );
		if ( ! is_array( $blocks ) || ! $blocks ) {
			$legacy_rows = get_post_meta( $post->ID, '_schuetzen_march_order_rows', true );
			$blocks      = is_array( $legacy_rows ) && $legacy_rows ? array( $legacy_rows ) : array();
		}
		$blocks = array_pad( array_slice( $blocks, 0, 5 ), 5, array() );
		$people = get_posts( array( 'post_type' => 'schuetzen_person', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		?>
		<p>Der Zug kann in bis zu fünf Marschblöcke aufgeteilt werden. Jede Zeile kann eine, zwei oder drei Personen enthalten. Leere Felder bleiben frei.</p>
		<?php for ( $block_index = 0; $block_index < 5; $block_index++ ) : ?>
			<fieldset style="margin:1.5rem 0;padding:1rem;border:1px solid #ccd0d4;">
				<legend style="padding:0 .5rem;font-weight:600;">Marschblock <?php echo esc_html( $block_index + 1 ); ?></legend>
				<table class="widefat striped">
					<thead><tr><th>Links</th><th>Mitte</th><th>Rechts</th></tr></thead>
					<tbody>
					<?php for ( $row_index = 0; $row_index < 20; $row_index++ ) : ?>
						<tr>
						<?php for ( $slot = 0; $slot < 3; $slot++ ) : ?>
							<td><select class="widefat" name="schuetzen_march_blocks[<?php echo esc_attr( $block_index ); ?>][<?php echo esc_attr( $row_index ); ?>][<?php echo esc_attr( $slot ); ?>]"><option value="">— frei —</option><?php foreach ( $people as $person ) : ?><option value="<?php echo esc_attr( $person->ID ); ?>" <?php selected( (int) ( $blocks[ $block_index ][ $row_index ][ $slot ] ?? 0 ), $person->ID ); ?>><?php echo esc_html( $person->post_title ); ?></option><?php endforeach; ?></select></td>
						<?php endfor; ?>
						</tr>
					<?php endfor; ?>
					</tbody>
				</table>
			</fieldset>
		<?php endfor; ?>
		<?php
	}

	public function add_info_meta_box() {
		add_meta_box( 'schuetzen-info-category', 'Info-Kategorie', array( $this, 'render_info_meta_box' ), 'schuetzen_info', 'side', 'high' );
	}

	public function render_info_meta_box( $post ) {
		wp_nonce_field( 'schuetzen_info_category', 'schuetzen_info_nonce' );
		$category = get_post_meta( $post->ID, '_schuetzen_info_category', true );
		?>
		<label for="schuetzen_info_category">Kategorie</label>
		<select class="widefat" id="schuetzen_info_category" name="schuetzen_info_category">
			<option value="" <?php selected( $category, '' ); ?>>Alle</option>
			<option value="regiment" <?php selected( $category, 'regiment' ); ?>>Regiment</option>
			<option value="korps" <?php selected( $category, 'korps' ); ?>>Korps</option>
			<option value="zug" <?php selected( $category, 'zug' ); ?>>Zug</option>
		</select>
		<?php
	}

	public function save_info_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_info_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_info_nonce'] ) ), 'schuetzen_info_category' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$category = sanitize_key( wp_unslash( $_POST['schuetzen_info_category'] ?? '' ) );
		update_post_meta( $post_id, '_schuetzen_info_category', in_array( $category, array( 'regiment', 'korps', 'zug' ), true ) ? $category : '' );
	}

	public function save_event_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_event_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_event_nonce'] ) ), 'schuetzen_event_details' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_schuetzen_event_date', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_date'] ?? '' ) ) );
		update_post_meta( $post_id, '_schuetzen_event_time', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_time'] ?? '' ) ) );
		update_post_meta( $post_id, '_schuetzen_event_location', sanitize_text_field( wp_unslash( $_POST['schuetzen_event_location'] ?? '' ) ) );
		$category = sanitize_key( wp_unslash( $_POST['schuetzen_event_category'] ?? '' ) );
		update_post_meta( $post_id, '_schuetzen_event_category', in_array( $category, array( 'zug', 'korps', 'regiment' ), true ) ? $category : '' );
		update_post_meta( $post_id, '_schuetzen_event_march_order', absint( $_POST['schuetzen_event_march_order'] ?? 0 ) );
	}

	public function save_person_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_person_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_person_nonce'] ) ), 'schuetzen_person_details' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_schuetzen_person_role', sanitize_text_field( wp_unslash( $_POST['schuetzen_person_role'] ?? '' ) ) );
	}

	public function save_march_order_meta( $post_id, $post ) {
		if ( ! isset( $_POST['schuetzen_march_order_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['schuetzen_march_order_nonce'] ) ), 'schuetzen_march_order_details' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$blocks = array();
		foreach ( array_slice( (array) ( $_POST['schuetzen_march_blocks'] ?? array() ), 0, 5 ) as $block ) {
			$clean_rows = array();
			foreach ( array_slice( (array) $block, 0, 20 ) as $row ) {
				$clean_row = array_map( 'absint', array_slice( (array) $row, 0, 3 ) );
				if ( array_filter( $clean_row ) ) {
					$clean_rows[] = $clean_row;
				}
			}
			$blocks[] = $clean_rows;
		}
		update_post_meta( $post_id, '_schuetzen_march_order_blocks', $blocks );
	}
}
