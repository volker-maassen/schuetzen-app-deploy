<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Admin_Access {
	private const LIMITED_ROLES = array( 'editor', 'author', 'contributor' );

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'limit_admin_menu' ), 999 );
	}

	public function limit_admin_menu() {
		$role = $this->get_limited_role();
		if ( ! $role ) {
			return;
		}

		$allowed = array(
			'index.php',
			'edit.php?post_type=schuetzen_event',
			'edit.php?post_type=schuetzen_message',
			'edit.php?post_type=schuetzen_info',
			'edit.php?post_type=schuetzen_person',
			'edit.php?post_type=schuetzen_march',
		);

		if ( 'editor' === $role ) {
			$allowed[] = 'upload.php';
		}

		global $menu;
		foreach ( (array) $menu as $item ) {
			$slug = $item[2] ?? '';
			if ( $slug && ! in_array( $slug, $allowed, true ) ) {
				remove_menu_page( $slug );
			}
		}
	}

	private function get_limited_role( $user = null ) {
		$user = $user instanceof WP_User ? $user : wp_get_current_user();
		if ( ! $user->exists() || in_array( 'administrator', (array) $user->roles, true ) ) {
			return '';
		}

		foreach ( self::LIMITED_ROLES as $role ) {
			if ( in_array( $role, (array) $user->roles, true ) ) {
				return $role;
			}
		}

		return '';
	}
}
