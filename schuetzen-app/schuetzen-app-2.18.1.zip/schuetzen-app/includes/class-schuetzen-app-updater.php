<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Updater {
	private $plugin_file;
	private $version;
	private $metadata_url;
	private $clear_cache_on_shutdown = false;

	public function __construct( $plugin_file, $version, $metadata_url ) {
		$this->plugin_file  = $plugin_file;
		$this->version      = $version;
		$this->metadata_url = esc_url_raw( $metadata_url );

		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_for_update' ) );
		add_filter( 'site_transient_update_plugins', array( $this, 'remove_stale_update' ) );
		add_filter( 'plugins_api', array( $this, 'plugin_information' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( $this, 'clear_update_cache' ), 10, 2 );
		add_action( 'shutdown', array( $this, 'maybe_clear_update_cache' ), PHP_INT_MAX );
	}

	public function clear_update_cache( $upgrader, $options ) {
		if ( 'update' !== ( $options['action'] ?? '' ) || 'plugin' !== ( $options['type'] ?? '' ) ) {
			return;
		}

		$updated_plugins = array_merge(
			(array) ( $options['plugins'] ?? array() ),
			(array) ( $options['plugin'] ?? array() )
		);
		$updated_plugins = array_map( 'plugin_basename', $updated_plugins );

		if ( in_array( plugin_basename( $this->plugin_file ), $updated_plugins, true ) ) {
			$this->clear_cache_on_shutdown = true;
		}
	}

	public function maybe_clear_update_cache() {
		if ( $this->clear_cache_on_shutdown ) {
			delete_site_transient( 'update_plugins' );
		}
	}

	public function remove_stale_update( $transient ) {
		if ( ! is_object( $transient ) || empty( $transient->response ) ) {
			return $transient;
		}

		$plugin_basename = plugin_basename( $this->plugin_file );
		$update = $transient->response[ $plugin_basename ] ?? null;

		if ( is_object( $update ) && ! empty( $update->new_version ) && ! version_compare( $update->new_version, $this->version, '>' ) ) {
			unset( $transient->response[ $plugin_basename ] );
		}

		return $transient;
	}

	public function check_for_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			$transient = new stdClass();
		}

		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		$metadata = $this->get_metadata();
		if ( ! $metadata || empty( $metadata->version ) || empty( $metadata->download_url ) ) {
			return $transient;
		}

		$plugin_basename = plugin_basename( $this->plugin_file );
		if ( version_compare( $metadata->version, $this->version, '>' ) ) {
			$update              = new stdClass();
			$update->id          = $metadata->id ?? $this->metadata_url;
			$update->slug        = $metadata->slug ?? 'schuetzen-app';
			$update->plugin      = $plugin_basename;
			$update->new_version = sanitize_text_field( $metadata->version );
			$update->url         = esc_url_raw( $metadata->homepage ?? 'https://www.maassen.de/' );
			$update->package     = esc_url_raw( $metadata->download_url );

			$transient->response[ $plugin_basename ] = $update;
		}

		return $transient;
	}

	public function plugin_information( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || 'schuetzen-app' !== $args->slug ) {
			return $result;
		}

		$metadata = $this->get_metadata();
		if ( ! $metadata ) {
			return $result;
		}

		$info                = new stdClass();
		$info->name          = $metadata->name ?? 'Schützen-App';
		$info->slug          = $metadata->slug ?? 'schuetzen-app';
		$info->version       = $metadata->version ?? $this->version;
		$info->author        = $metadata->author ?? 'Volker Maaßen';
		$info->homepage      = $metadata->homepage ?? 'https://www.maassen.de/';
		$info->download_link = $metadata->download_url ?? '';
		$info->sections      = array(
			'description' => $metadata->description ?? '',
			'changelog'   => $metadata->changelog ?? '',
		);

		return $info;
	}

	private function get_metadata() {
		$response = wp_remote_get(
			add_query_arg( 'schuetzen_app_cache', time(), $this->metadata_url ),
			array(
				'timeout'    => 10,
				'sslverify'  => true,
				'headers'    => array( 'Cache-Control' => 'no-cache, no-store, must-revalidate' ),
				'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url( '/' ),
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$metadata = json_decode( wp_remote_retrieve_body( $response ) );
		return is_object( $metadata ) ? $metadata : false;
	}
}
