<?php

defined( 'ABSPATH' ) || exit;

final class Schuetzen_App_Settings {
	private $option_name = 'schuetzen_app_settings';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	public function add_menu() {
		add_menu_page( 'Schützen-App', 'Schützen-App', 'manage_options', 'schuetzen-app', array( $this, 'render_page' ), 'dashicons-smartphone', 26 );
	}

	public function register_settings() {
		register_setting( 'schuetzen_app_settings_group', $this->option_name, array( $this, 'sanitize_settings' ) );
	}

	public function sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();
		$colors = array( 'background_start', 'background_end', 'green', 'green_dark', 'gold', 'cream', 'paper', 'ink', 'muted', 'header', 'footer' );
		$groups = Schuetzen_App_Groups::sanitize( $input['groups'] ?? array() );
		if ( ! $groups ) {
			$groups = Schuetzen_App_Groups::defaults();
		}
		$group_ids = wp_list_pluck( $groups, 'id' );
		$primary_group = sanitize_key( $input['primary_group'] ?? '' );
		$output = array(
			'brand_line_1'   => sanitize_text_field( $input['brand_line_1'] ?? '' ),
			'brand_line_2'   => sanitize_text_field( $input['brand_line_2'] ?? '' ),
			'background_events' => esc_url_raw( $input['background_events'] ?? '' ),
			'background_messages' => esc_url_raw( $input['background_messages'] ?? '' ),
			'background_info' => esc_url_raw( $input['background_info'] ?? '' ),
			'groups' => $groups,
			'primary_group' => in_array( $primary_group, $group_ids, true ) ? $primary_group : $group_ids[0],
			'calendar_sources' => Schuetzen_App_Calendar_Sources::sanitize_sources( $input['calendar_sources'] ?? array(), $groups ),
		);
		foreach ( $colors as $color ) {
			$value = sanitize_hex_color( $input[ 'color_' . $color ] ?? '' );
			$output[ 'color_' . $color ] = $value ?: '';
			$default_opacity = ( 'background_end' === $color ) ? ( $input['background_end_opacity'] ?? 100 ) : 100;
			$output[ 'color_' . $color . '_opacity' ] = min( 100, max( 0, absint( $input[ 'color_' . $color . '_opacity' ] ?? $default_opacity ) ) );
		}
		return $output;
	}

	public function render_page() {
		wp_enqueue_media();
		$settings = get_option( $this->option_name, array() );
		$settings = is_array( $settings ) ? $settings : array();
		$groups = Schuetzen_App_Groups::get();
		$primary_group = Schuetzen_App_Groups::primary_id();
		$sources = Schuetzen_App_Calendar_Sources::sanitize_sources( $settings['calendar_sources'] ?? array() );
		$source_status = get_option( 'schuetzen_app_calendar_status', array() );
		$source_status = is_array( $source_status ) ? $source_status : array();
		$sync_notice = get_transient( 'schuetzen_app_calendar_notice_' . get_current_user_id() );
		if ( false !== $sync_notice ) {
			delete_transient( 'schuetzen_app_calendar_notice_' . get_current_user_id() );
		}
		$section_backgrounds = array(
			'background_events' => 'Termine',
			'background_messages' => 'Nachrichten',
			'background_info' => 'Infos',
		);
		$colors = array(
			'background_start' => 'Verlaufsfarbe oben',
			'background_end'   => 'Verlaufsfarbe unten',
			'green'      => 'Hauptfarbe',
			'green_dark' => 'Dunkle Hauptfarbe',
			'gold'       => 'Akzentfarbe',
			'cream'      => 'App-Hintergrund',
			'paper'      => 'Card-Hintergrund',
			'ink'        => 'Textfarbe',
			'muted'      => 'Gedämpfte Textfarbe',
			'header'     => 'Header-Hintergrund',
			'footer'     => 'Footer-Hintergrund',
		);
		$color_defaults = array(
			'background_start' => '#f7f4ec',
			'background_end'   => '#e9e5db',
			'green'      => '#1e4d3a',
			'green_dark' => '#123326',
			'gold'       => '#d6a84f',
			'cream'      => '#f7f4ec',
			'paper'      => '#fffdf8',
			'ink'        => '#1f2824',
			'muted'      => '#69736d',
			'header'     => '#f7f4ec',
			'footer'     => '#fffdf8',
		);
		?>
		<div class="wrap schuetzen-app-settings">
			<h1>Schützen-App</h1>
			<?php if ( is_array( $sync_notice ) ) : ?>
				<div class="notice <?php echo empty( $sync_notice['errors'] ) ? 'notice-success' : 'notice-warning'; ?> is-dismissible"><p>
					<?php echo esc_html( sprintf( '%d Quelle(n) geprüft, %d Termin(e) angelegt, %d aktualisiert.', absint( $sync_notice['sources'] ?? 0 ), absint( $sync_notice['created'] ?? 0 ), absint( $sync_notice['updated'] ?? 0 ) ) ); ?>
					<?php if ( ! empty( $sync_notice['errors'] ) ) : ?><br><?php echo esc_html( implode( ' | ', $sync_notice['errors'] ) ); ?><?php endif; ?>
				</p></div>
			<?php endif; ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'schuetzen_app_settings_group' ); ?>
				<nav class="nav-tab-wrapper" aria-label="Schützen-App Einstellungen">
					<button type="button" class="nav-tab nav-tab-active" data-schuetzen-tab="design">Design</button>
					<button type="button" class="nav-tab" data-schuetzen-tab="groups">Gruppen</button>
					<button type="button" class="nav-tab" data-schuetzen-tab="calendars">Kalenderquellen</button>
					<button type="button" class="nav-tab" data-schuetzen-tab="help">Hilfe</button>
				</nav>

				<section data-schuetzen-panel="design">
					<h2>Kopfzeile</h2>
					<table class="form-table" role="presentation">
						<tr><th scope="row"><label for="schuetzen_app_brand_line_1">Erste Zeile</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_1" name="<?php echo esc_attr( $this->option_name . '[brand_line_1]' ); ?>" value="<?php echo esc_attr( $settings['brand_line_1'] ?? '' ); ?>"></td></tr>
						<tr><th scope="row"><label for="schuetzen_app_brand_line_2">Zweite Zeile</label></th><td><input type="text" class="regular-text" id="schuetzen_app_brand_line_2" name="<?php echo esc_attr( $this->option_name . '[brand_line_2]' ); ?>" value="<?php echo esc_attr( $settings['brand_line_2'] ?? '' ); ?>"></td></tr>
					</table>
					<p class="description">Icon und Begrüßungstext der App werden aus den allgemeinen WordPress-Einstellungen übernommen.</p>

					<h2>Bereichs-Hintergrundbilder</h2>
					<p class="description">Die Bilder erscheinen als dezenter Hintergrund im jeweiligen Hauptbereich der App.</p>
					<table class="form-table" role="presentation">
						<?php foreach ( $section_backgrounds as $key => $label ) : ?>
							<tr>
								<th scope="row"><label for="schuetzen_app_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
								<td>
									<input type="url" class="regular-text" id="schuetzen_app_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $this->option_name . '[' . $key . ']' ); ?>" value="<?php echo esc_url( $settings[ $key ] ?? '' ); ?>" data-schuetzen-media-field>
									<button type="button" class="button" data-schuetzen-media-button="<?php echo esc_attr( $key ); ?>">Bild auswählen</button>
									<?php if ( ! empty( $settings[ $key ] ) ) : ?><button type="button" class="button-link-delete" data-schuetzen-media-clear="<?php echo esc_attr( $key ); ?>">Bild entfernen</button><?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>

					<h2>App-Farben</h2>
					<table class="form-table" role="presentation">
						<?php foreach ( $colors as $key => $label ) : ?>
							<?php $opacity = $settings[ 'color_' . $key . '_opacity' ] ?? ( 'background_end' === $key ? ( $settings['background_end_opacity'] ?? 100 ) : 100 ); ?>
							<tr><th scope="row"><label for="schuetzen_app_color_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th><td><input type="color" id="schuetzen_app_color_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $this->option_name . '[color_' . $key . ']' ); ?>" value="<?php echo esc_attr( $settings[ 'color_' . $key ] ?? $settings[ $key ] ?? $color_defaults[ $key ] ); ?>"> <label for="schuetzen_app_color_<?php echo esc_attr( $key ); ?>_opacity">Deckkraft</label> <input type="range" min="0" max="100" step="1" id="schuetzen_app_color_<?php echo esc_attr( $key ); ?>_opacity" name="<?php echo esc_attr( $this->option_name . '[color_' . $key . '_opacity]' ); ?>" value="<?php echo esc_attr( $opacity ); ?>" oninput="this.nextElementSibling.value = this.value + '%'"> <output><?php echo esc_html( $opacity . '%' ); ?></output></td></tr>
						<?php endforeach; ?>
					</table>
				</section>

				<section data-schuetzen-panel="groups" hidden>
					<h2>Gruppen und Farben</h2>
					<p>Die Hauptgruppe liefert die führende Designfarbe für Navigation, Willkommen und aktive Schaltflächen. Die interne ID bleibt beim Umbenennen unverändert.</p>
					<table class="widefat striped" data-schuetzen-groups-table>
						<thead><tr><th>Hauptgruppe</th><th>Name</th><th>Farbe</th><th>Deckkraft</th><th></th></tr></thead>
						<tbody>
						<?php foreach ( $groups as $index => $group ) : ?>
							<tr>
								<td><input type="radio" name="<?php echo esc_attr( $this->option_name . '[primary_group]' ); ?>" value="<?php echo esc_attr( $group['id'] ); ?>" <?php checked( $primary_group, $group['id'] ); ?>></td>
								<td><input type="hidden" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][id]' ); ?>" value="<?php echo esc_attr( $group['id'] ); ?>"><input type="text" class="regular-text" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][name]' ); ?>" value="<?php echo esc_attr( $group['name'] ); ?>" required><br><small>ID: <?php echo esc_html( $group['id'] ); ?></small></td>
								<td><input type="color" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][color]' ); ?>" value="<?php echo esc_attr( $group['color'] ); ?>"></td>
								<td><input type="range" min="0" max="100" name="<?php echo esc_attr( $this->option_name . '[groups][' . $index . '][opacity]' ); ?>" value="<?php echo esc_attr( $group['opacity'] ); ?>" oninput="this.nextElementSibling.value=this.value+'%'"> <output><?php echo esc_html( $group['opacity'] . '%' ); ?></output></td>
								<td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p><button type="button" class="button" data-schuetzen-add-group>Gruppe hinzufügen</button></p>
					<p class="description">Wird eine verwendete Gruppe entfernt, bleiben die Inhalte erhalten, erscheinen aber bis zu einer neuen Zuordnung in Dunkelgrau.</p>
				</section>

				<section data-schuetzen-panel="calendars" hidden>
					<h2>Externe Kalenderquellen</h2>
					<p>Trage eine Webseite mit verknüpftem iCalendar-Feed oder direkt eine öffentliche ICS-URL ein. Aktive Quellen werden zweimal täglich synchronisiert. Neu angelegte Gruppen bitte vor der Zuordnung einmal speichern.</p>
					<table class="widefat striped" data-schuetzen-sources-table>
						<thead><tr><th>Aktiv</th><th>Name und URL</th><th>Gruppe</th><th>Neue Termine</th><th>Status</th><th></th></tr></thead>
						<tbody>
						<?php foreach ( $sources as $index => $source ) : ?>
							<?php $status = $source_status[ $source['id'] ] ?? array(); ?>
							<tr>
								<td><input type="hidden" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][id]' ); ?>" value="<?php echo esc_attr( $source['id'] ); ?>"><input type="checkbox" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][active]' ); ?>" value="1" <?php checked( $source['active'], 1 ); ?>></td>
								<td><input type="text" class="regular-text" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][name]' ); ?>" value="<?php echo esc_attr( $source['name'] ); ?>" placeholder="z. B. Bezirksverband Neuss"><br><input type="url" class="large-text" name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][url]' ); ?>" value="<?php echo esc_attr( $source['url'] ); ?>" placeholder="https://…" required></td>
								<td><select name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][group]' ); ?>"><option value="">Keine Zuordnung</option><?php foreach ( $groups as $group ) : ?><option value="<?php echo esc_attr( $group['id'] ); ?>" <?php selected( $source['group'], $group['id'] ); ?>><?php echo esc_html( $group['name'] ); ?></option><?php endforeach; ?></select></td>
								<td><select name="<?php echo esc_attr( $this->option_name . '[calendar_sources][' . $index . '][status]' ); ?>"><option value="draft" <?php selected( $source['status'], 'draft' ); ?>>Als Entwurf</option><option value="publish" <?php selected( $source['status'], 'publish' ); ?>>Automatisch veröffentlichen</option></select></td>
								<td><?php if ( $status ) : ?><?php echo esc_html( wp_date( 'd.m.Y H:i', absint( $status['time'] ?? 0 ) ) ); ?><br><small><?php echo ! empty( $status['error'] ) ? esc_html( $status['error'] ) : esc_html( sprintf( '%d neu, %d aktualisiert', absint( $status['created'] ?? 0 ), absint( $status['updated'] ?? 0 ) ) ); ?></small><?php else : ?>Noch nicht synchronisiert<?php endif; ?></td>
								<td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p><button type="button" class="button" data-schuetzen-add-source>Kalenderquelle hinzufügen</button></p>
					<p><a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=schuetzen_app_sync_calendars' ), 'schuetzen_app_sync_calendars' ) ); ?>">Aktive Quellen jetzt synchronisieren</a> <span class="description">Änderungen vorher speichern.</span></p>
				</section>

				<section data-schuetzen-panel="help" hidden>
					<h2>Inhalte pflegen</h2>
					<div style="max-width: 760px; padding: 16px; background: #fff; border-left: 4px solid #1e4d3a;">
						<p><strong>Termine</strong><br>Datum, Uhrzeit, Ort, Treffpunkt und Zuordnung werden direkt beim Termin gepflegt. Ein Termin ohne Uhrzeit dient als Tageskarte für weitere Termine desselben Tages.</p>
						<p><strong>Nachrichten und Infos</strong><br>Die Inhalte werden über die jeweiligen Menüpunkte angelegt. Die Gruppenzuordnung bestimmt die farbliche Kennzeichnung in der App.</p>
						<p><strong>Kalenderquellen</strong><br>Externe iCalendar-Termine können als Entwurf oder automatisch veröffentlicht importiert werden. Bereits importierte Termine werden über ihre eindeutige Kalender-ID aktualisiert und nicht dupliziert.</p>
						<p><strong>Personen und Marschordnungen</strong><br>Personen werden einmalig angelegt und können anschließend in den Marschordnungen verwendet werden. Eine Marschordnung lässt sich einem Termin zuweisen.</p>
					</div>
				</section>

				<?php submit_button( 'Einstellungen speichern' ); ?>
			</form>
		</div>
		<script>
		(function () {
			var tabs = document.querySelectorAll('[data-schuetzen-tab]');
			var panels = document.querySelectorAll('[data-schuetzen-panel]');
			var groupOptions = <?php echo wp_json_encode( array_map( static function ( $group ) { return array( 'id' => $group['id'], 'name' => $group['name'] ); }, $groups ) ); ?>;
			var rowIndex = Date.now();
			var escapeHtml = function (value) {
				return String(value || '').replace(/[&<>"']/g, function (character) {
					return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[character];
				});
			};
			var activateTab = function (name) {
				if (['design', 'groups', 'calendars', 'help'].indexOf(name) === -1) name = 'design';
				tabs.forEach(function (item) { item.classList.toggle('nav-tab-active', item.getAttribute('data-schuetzen-tab') === name); });
				panels.forEach(function (panel) { panel.hidden = panel.getAttribute('data-schuetzen-panel') !== name; });
				var url = new URL(window.location.href);
				url.searchParams.set('tab', name);
				window.history.replaceState({}, '', url.toString());
				var referer = document.querySelector('input[name="_wp_http_referer"]');
				if (referer) referer.value = url.pathname + url.search;
			};
			tabs.forEach(function (tab) {
				tab.addEventListener('click', function () {
					activateTab(tab.getAttribute('data-schuetzen-tab'));
				});
			});
			activateTab(new URLSearchParams(window.location.search).get('tab') || 'design');
			document.addEventListener('click', function (event) {
				var removeButton = event.target.closest('[data-schuetzen-remove-row]');
				if (removeButton) {
					removeButton.closest('tr').remove();
					return;
				}
				if (event.target.closest('[data-schuetzen-add-group]')) {
					var index = rowIndex++;
					var id = 'gruppe-' + index;
					var body = document.querySelector('[data-schuetzen-groups-table] tbody');
					body.insertAdjacentHTML('beforeend', '<tr><td><input type="radio" name="schuetzen_app_settings[primary_group]" value="' + id + '"></td><td><input type="hidden" name="schuetzen_app_settings[groups][' + index + '][id]" value="' + id + '"><input type="text" class="regular-text" name="schuetzen_app_settings[groups][' + index + '][name]" required><br><small>ID: ' + id + '</small></td><td><input type="color" name="schuetzen_app_settings[groups][' + index + '][color]" value="#4b5563"></td><td><input type="range" min="0" max="100" name="schuetzen_app_settings[groups][' + index + '][opacity]" value="100" oninput="this.nextElementSibling.value=this.value+\'%\'"> <output>100%</output></td><td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td></tr>');
					return;
				}
				if (event.target.closest('[data-schuetzen-add-source]')) {
					var sourceIndex = rowIndex++;
					var sourceId = 'quelle-' + sourceIndex;
					var options = '<option value="">Keine Zuordnung</option>' + groupOptions.map(function (group) { return '<option value="' + escapeHtml(group.id) + '">' + escapeHtml(group.name) + '</option>'; }).join('');
					var sourceBody = document.querySelector('[data-schuetzen-sources-table] tbody');
					sourceBody.insertAdjacentHTML('beforeend', '<tr><td><input type="hidden" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][id]" value="' + sourceId + '"><input type="checkbox" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][active]" value="1" checked></td><td><input type="text" class="regular-text" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][name]" placeholder="z. B. Bezirksverband Neuss"><br><input type="url" class="large-text" name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][url]" placeholder="https://…" required></td><td><select name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][group]">' + options + '</select></td><td><select name="schuetzen_app_settings[calendar_sources][' + sourceIndex + '][status]"><option value="draft">Als Entwurf</option><option value="publish">Automatisch veröffentlichen</option></select></td><td>Noch nicht synchronisiert</td><td><button type="button" class="button-link-delete" data-schuetzen-remove-row>Entfernen</button></td></tr>');
				}
			});
			document.querySelectorAll('[data-schuetzen-media-button]').forEach(function (button) {
				button.addEventListener('click', function () {
					var key = button.getAttribute('data-schuetzen-media-button');
					var field = document.getElementById('schuetzen_app_' + key);
					var frame = wp.media({ title: 'Bild für ' + key + ' auswählen', button: { text: 'Bild übernehmen' }, multiple: false });
					frame.on('select', function () { var attachment = frame.state().get('selection').first().toJSON(); field.value = attachment.url; });
					frame.open();
				});
			});
			document.querySelectorAll('[data-schuetzen-media-clear]').forEach(function (button) {
				button.addEventListener('click', function () { document.getElementById('schuetzen_app_' + button.getAttribute('data-schuetzen-media-clear')).value = ''; button.remove(); });
			});
		}());
		</script>
		<?php
	}
}
