# Änderungsprotokoll

## 2.25.2

- Tageskarten werden unabhängig von der Gruppenzuordnung mit weißem Hintergrund dargestellt.
- Der Rand der Tageskarte übernimmt weiterhin die Gruppenfarbe.
- Karten ohne Gruppenzuordnung erhalten einen weißen Rand und weißen Hintergrund.

## 2.25.1

- Die App überschreibt die individuellen WordPress-Schriften für H2 und H3 nicht mehr.
- Überschriften übernehmen dadurch die jeweils im Theme festgelegte Typografie, beispielsweise Marcellus für H3.

## 2.25.0

- Externe Kalender werden nur bis zum 31. Dezember des kommenden Jahres importiert.
- Wiederkehrende Termine außerhalb dieses Zeitraums werden übersprungen.
- Bereits vorhandene externe Termine außerhalb des Zeitfensters werden in der App ausgeblendet.

## 2.24.9

- Ladefehler bei importierten Terminen durch eine nicht erreichbare Hauptgruppen-Variable behoben.
- Hauptgruppentermine bleiben auch bei gespeicherten Ausblendungen sichtbar; andere Quellen bleiben steuerbar.

## 2.24.8

- Der App-REST-Aufruf verwendet die WordPress-Query-Route und funktioniert dadurch auch bei Servern ohne funktionierende `/wp-json/`-Rewrite-Regel.

## 2.24.7

- Die Hauptgruppe bleibt auch bei deaktivierten externen Terminen immer sichtbar.
- Kalenderquellen der Hauptgruppe werden im Frontend-Einstellungsdialog nicht als abschaltbare Quellen angeboten.

## 2.24.6

- Der Hilfebereich erklärt jetzt die notwendige WordPress-Zeitzone für korrekte Kalenderzeiten.
- Ergänzende Hinweise erläutern das Zusammenspiel von WordPress-Typografie, App-Überschriften, Farben und responsiver Darstellung.

## 2.24.5

- Der Brand-Title im Header erhält einen oberen Abstand von 4 Pixeln.

## 2.24.4

- Nachträgliche Header-Anpassungen als neue Update-Version veröffentlicht, damit WordPress die Änderung zuverlässig erkennt.
- Die Hauptzeile wird als H1 ausgegeben und übernimmt die WordPress-Überschriftenschrift.

## 2.24.3

- Inhaltsüberschriften übernehmen die in WordPress festgelegte Überschriftenschrift.
- Die App unterstützt damit beispielsweise Marcellus oder Cardo ohne doppelte Font-Konfiguration.
- Ohne WordPress-Überschriftenschrift bleibt ein Serif-Fallback aktiv.
- Die Hauptzeile im Header verwendet semantisch ein H1 und übernimmt damit ebenfalls die WordPress-Typografie.
- Die Zeilenabstände im Header wurden an die Card-Typografie angeglichen.

## 2.24.2

- Live-Vorschau verwendet für Kopfzeile, Logo und Schriften jetzt dieselben Maße wie das Frontend.
- Abstände und Form der Kopfzeile in der Vorschau an die tatsächliche App-Darstellung angeglichen.

## 2.24.1

- Kopfzeile mit mehr Höhe und großzügigerem Innenabstand dargestellt.
- Logos werden proportional und ohne Beschnitt in einer größeren Fläche angezeigt.
- Hauptüberschrift im App-Kopf auf 1,4 rem vergrößert.

## 2.24.0

- Doppelte Willkommen-Card entfernt und den Inhaltsbereich direkt unter die Kopfzeile gesetzt.
- Logo, kleine obere Zeile, Hauptüberschrift und Unterzeile können im Backend separat gepflegt werden.
- Ohne eigenes Header-Logo wird weiterhin das WordPress-Favicon verwendet.
- Administratoren können geprüfte SVG-Logos bis 1 MB hochladen; aktive und externe SVG-Inhalte werden abgewiesen.
- Bestehende Kopfzeilentexte bleiben erhalten und die bisherige Website-Beschreibung wird als Unterzeile übernommen.

## 2.23.0

- Nachrichten und Infos können in den Backend-Einstellungen einzeln aus der unteren App-Navigation ausgeblendet werden.
- Termine und Einstellungen bleiben immer sichtbar.
- Der bisherige Navigationspunkt „Anzeige“ heißt jetzt „Einstellungen“.
- Die verbleibenden Navigationspunkte werden automatisch gleichmäßig über die verfügbare Breite verteilt.
- Bestehende Installationen zeigen Nachrichten und Infos weiterhin standardmäßig an.

## 2.22.0

- Feste Bindung der Vollbildansicht an `app.hubertus-fahnenzug.de` und die Seiten-ID 9 entfernt.
- Seiten mit dem Shortcode `[schuetzen_app]` verwenden automatisch die App-Vollbildvorlage ohne Theme-Header und Theme-Footer.
- Im Hilfe-Reiter kann eine fertige, veröffentlichte App-Seite automatisch angelegt werden.
- Bereits vorhandene App-Seiten werden erkannt, sodass keine Duplikate entstehen.

## 2.21.7

- Hilfe um eine kurze Anleitung zum Einfügen der App mit dem Shortcode `[schuetzen_app]` ergänzt.

## 2.21.6

- Logo im App-Kopf ohne erzwungenen dunklen Hintergrund und ohne farbige Umrandung dargestellt.
- Die eigene Gestaltung des jeweiligen Website-Logos bleibt dadurch unverfälscht sichtbar.

## 2.21.5

- Web-App-Manifest und iPhone-Touch-Icon verwenden das Website-Icon der jeweiligen WordPress-Installation.
- Name und Startseite der installierten Web-App werden passend zur aktuellen Website erzeugt.
- Die fest eingebundenen Hubertus-Symbole dienen nur noch als Rückfall, wenn kein Website-Icon eingerichtet ist.

## 2.21.4

- Update-Metadaten und Installationspakete werden direkt über das öffentliche GitHub-Auslieferungsrepository bezogen.
- Der Updater funktioniert dadurch auch auf Servern, denen der Webschutz von maassen.de statt der JSON-Datei eine HTML-Prüfseite liefert.

## 2.21.3

- „Einstellungen“ als ersten Unterpunkt der Schützen-App ergänzt.
- Der Klick auf den Hauptmenüpunkt Schützen-App öffnet wieder die Einstellungen statt der Terminübersicht.

## 2.21.2

- Den Updater an die offizielle WordPress-Schnittstelle für externe Update-Quellen angebunden.
- Die bisherige Update-Erkennung bleibt als Rückwärtskompatibilität erhalten.
- Die Transient-Verarbeitung gegen leere WordPress-Update-Daten abgesichert.

## 2.21.0

- Termine, Nachrichten, Infos, Personen und Marschordnungen als Untermenüs unter Schützen-App zusammengefasst.
- Das Dashboard bleibt für eingeschränkte Benutzerrollen sichtbar.
- Die bisherige Medien-Berechtigung für Redakteure bleibt unverändert.

## 2.20.1

- Fehler beim Öffnen von Nachrichten und Infos nach dem Update behoben.

## 2.20.0

- JSON-Export und -Import für die Einstellungen der Schützen-App ergänzt.
- Exportiert werden ausschließlich Design, Gruppen, Kalenderquellen und weitere Plugin-Einstellungen.
- Termine, Nachrichten, Infos, Personen, Marschordnungen und Mediendateien bleiben beim Import unverändert.
- Abgelaufene externe Termine werden bei der Kalendersynchronisierung dauerhaft gelöscht.
- Laufende mehrtägige Termine bleiben bis einschließlich ihres Enddatums erhalten.

## 2.19.2

- Termin-Cards werden mit zehn Prozent ihrer zugeordneten Gruppenfarbe getönt.
- Der vollfarbige Gruppenrand bleibt erhalten.
- Die Gruppenbezeichnung erscheint klein, fett und in Großbuchstaben oberhalb des Termintitels.
- Bereits importierte Entwürfe werden beim Synchronisieren veröffentlicht, wenn ihre Quelle auf automatische Veröffentlichung gestellt wurde.

## 2.19.1

- Neue Gruppen können direkt an einer Kalenderquelle angelegt werden.
- Die neue Gruppe wird beim gemeinsamen Speichern automatisch der Kalenderquelle zugeordnet.

## 2.19.0

- Farbeinstellungen in eine kompakte Grundansicht und einen einklappbaren Expertenbereich gegliedert.
- Lange Deckkraft-Schieberegler durch platzsparende Prozentfelder ersetzt.
- Hexadezimalwerte können direkt eingegeben und Farben einzeln zurückgesetzt werden.
- Live-Vorschau für App-Verlauf, Kopfbereich, Karten, Texte, Navigation und führende Gruppenfarbe ergänzt.
- Bestehende Farbwerte bleiben beim Update unverändert erhalten.

## 2.18.2

- Vergangene Termine werden je Kalenderquelle standardmäßig nicht mehr importiert.
- Laufende mehrtägige Termine bleiben bis zu ihrem Enddatum im Import enthalten.
- Optional kann der Import vergangener Termine pro Quelle wieder aktiviert werden.
- Die Synchronisierung zeigt die Anzahl übersprungener vergangener Termine an.

## 2.18.1

- Anzeigeeinstellungen um eigene Schalter für jede aktive Kalenderquelle erweitert.
- Ein Hauptschalter blendet weiterhin alle externen Termine gemeinsam ein oder aus.
- Lokale Termine bleiben von sämtlichen Quellenfiltern unberührt.

## 2.18.0

- Das vorhandene Textfeld importierter Termine bleibt als lokale Ergänzung bei Synchronisierungen erhalten.
- Externe Beschreibungen werden getrennt gespeichert und gemeinsam mit lokalen Ergänzungen ausgegeben.
- Neuer Anzeige-Button mit Zahnrad-Icon im App-Footer ergänzt.
- Nutzer können extern importierte Termine ausblenden; die Auswahl bleibt lokal auf dem Gerät gespeichert.

## 2.17.2

- Doppelte Datumsanzeige bei mehrtägigen Terminen in der Terminübersicht entfernt.
- Der vollständige Zeitraum bleibt in der Termindetailansicht sichtbar.

## 2.17.1

- Uhrzeiten aus iCalendar-Feeds mit eigener Zeitzone werden ohne ungewollte Verschiebung übernommen.

## 2.17.0

- Zug, Korps und Regiment in eine frei verwaltbare Gruppenliste überführt.
- Eigener Einstellungsreiter für Gruppen, Farben, Deckkraft und Hauptgruppe ergänzt.
- Termine, Nachrichten, Infos, Backend-Filter und Schnellbearbeitung verwenden die dynamischen Gruppen.
- Externe Webseiten und iCalendar-URLs können als Kalenderquellen hinterlegt werden.
- Kalenderfeeds werden zweimal täglich oder manuell synchronisiert und über ihre UID ohne Duplikate aktualisiert.
- Neue Termine können je Quelle als Entwurf oder automatisch veröffentlicht angelegt werden.
- Mehrtägige Ganztagstermine und Links zur Originalveranstaltung werden unterstützt.

## 2.16.0

- Mailimport, IMAP-Integration und iCalendar-Verarbeitung vollständig entfernt.
- Maileinstellungen und mailbezogene Hilfetexte aus dem Backend entfernt.
- Der bisherige Mailimport-Cronjob wird beim Update beendet.
- Gespeicherte Mailzugänge, Passwörter und Importprotokolle werden beim Update gelöscht.
- Bereits vorhandene Termine, Nachrichten, Infos und Bilder bleiben unverändert erhalten.

## 2.15.5

- Kalenderwochen werden nach ISO-Standard berechnet.
- Gleichnamige Kalenderwochen verschiedener Jahre werden nicht mehr zusammengelegt.
- Tageskarten für zukünftige Schützenfesttage erscheinen an der chronologisch richtigen Stelle.

## 2.15.4

- Bereits installierte Versionen werden nicht mehr durch einen veralteten Update-Transient erneut angeboten.
- Der Übergang vom bisherigen Updater auf die korrigierte Cache-Behandlung funktioniert nach einem einzigen Update.

## 2.15.3

- Der WordPress-Update-Cache wird nach einer Aktualisierung erst am Ende des Requests geleert.
- Die Cache-Bereinigung reagiert nur noch auf Aktualisierungen der Schützen-App.
- Das erneute Angebot derselben Plugin-Version direkt nach einer erfolgreichen Aktualisierung wurde behoben.

## 2.2.1

- Die Terminabfrage auf 50 Einträge erhöht, damit umfangreiche Schützenfest-Tagesprogramme vollständig angezeigt werden.

## 2.2.0

- Zug-, Korps- und Regimentsfarben im App-Panel einstellbar gemacht.
- Termine können einer Gruppe zugeordnet werden.
- Der linke Rand der Termin-Card übernimmt die Farbe der zugeordneten Gruppe.
- Antretezeiten aus dem Majorsbefehl 2026 als Terminvorschläge dokumentiert.

## 2.1.0

- Marschordnungen um fünf separat pflegbare Marschblöcke mit jeweils bis zu 20 dreireihigen Zeilen erweitert.
- Bestehende Marschordnungen werden automatisch als erster Marschblock weiterverwendet.
- Marschblock-Bezeichnungen werden im Frontend nur angezeigt, wenn mehr als ein Block befüllt ist.

## 2.0.2

- Personenbilder und Fallback-Icons auf 4rem vergrößert.
- Titel der Marschordnung zentriert.
- Dezenter Schatten für Personenbilder und Fallback-Icons ergänzt.

## 2.0.1

- Interne Bezeichnung des Inhaltstyps gekürzt, damit der WordPress-Menüpunkt Marschordnungen korrekt registriert wird.

## 2.0.0

- Personen als eigene Inhalte mit optionalem Portraitbild und Rolle ergänzt.
- Marschordnungen als eigene Inhalte mit flexiblen Ein-, Zwei- und Dreierreihen ergänzt.
- Marschordnungen können direkt einem Termin zugeordnet und auf der Detailseite angezeigt werden.
- Personen ohne Portraitbild erhalten automatisch ein neutrales Personen-Icon.

## 1.9.5

- HTML-Entities in manuellen Termin-, Nachrichten- und Info-Texten werden vor der Ausgabe korrekt dekodiert.

## 1.9.4

- Header-Schatten dauerhaft sichtbar gemacht.

## 1.9.3

- Header-Schatten an den Footer-Schatten angeglichen.
- Update-Abfrage mit Cache-Busting für `update.json` versehen.
- WordPress-Update-Transient nach Plugin-Aktualisierung gelöscht.

## 1.9.2

- Rahmenlinie der unteren App-Navigation entfernt.

## 1.9.1

- Oberen Abstand der Hero-Zone auf 1,2rem erhöht.

## 1.9.0

- Hintergrundfarbe des Headers im Plugin-Backend einstellbar gemacht.
- Hintergrundfarbe des Footer-Menüs im Plugin-Backend einstellbar gemacht.

## 1.8.2

- Header wieder auf die ursprüngliche App-Breite zurückgeführt.
- Nur die unteren Ecken mit dem Radius des Footer-Menüs abgerundet.
- Icon und Schriftzug im Header mit zusätzlichem Innenabstand versehen.

## 1.8.1

- Header auf die gesamte App-Breite ausgedehnt.
- Schatten auf die Unterkante des Headers begrenzt.

## 1.8.0

- Kopfzeile bleibt beim Scrollen sichtbar.
- Dezenter Schatten erscheint nur beim Scrollen nach oben.

## 1.7.3

- Aktive Markierung der Info-Filter beim Wechsel in den Bereich Infos korrigiert.

## 1.7.2

- Der aktive Info-Filter wird beim Öffnen jetzt auch tatsächlich angewendet.
- Beim Wechsel in den Bereich Infos startet die Ansicht standardmäßig mit der Kategorie Zug.

## 1.7.1

- Info-Filter in der Reihenfolge Zug, Korps, Regiment und Alle angeordnet.
- Zug ist beim Öffnen standardmäßig aktiv.

## 1.7.0

- Zweizeilige Kopfzeile im Plugin-Backend einstellbar gemacht.
- Website-Icon, Website-Titel und Untertitel werden aus den WordPress-Allgemeinen Einstellungen übernommen.

## 1.6.1

- Termine werden ausschließlich aus `.ics`-Anhängen importiert.
- Normale Text-Mails ohne Kalenderdatei werden als Termin-Mail übersprungen.

## 1.6.0

- iCalendar-Dateien (`.ics`) aus Termin-Mails werden importiert.
- Bestehende Termine werden über ihre Kalender-UID aktualisiert statt dupliziert.
- Titel, Beschreibung, Beginn, Ende und Ort werden aus dem iCalendar übernommen.

## 1.5.4

- Verschachtelte Outlook-MIME-Mails werden jetzt korrekt ausgelesen.
- HTML- und Textteile werden auch innerhalb von `multipart/alternative` erkannt.

## 1.5.3

- MIME- und Base64-Inhalte aus Outlook-Mails werden korrekt aufgelöst.
- HTML-Mailinhalt wird nicht mehr als Rohdaten in den Beitrag übernommen.

## 1.5.2

- HTML-Mailtexte aus Outlook werden vor der Erkennung von Terminangaben bereinigt.
- Datum, Uhrzeit und Ort werden dadurch auch aus HTML-Mails übernommen.

## 1.5.1

- Mailtest vom Einstellungsformular getrennt.
- „Änderungen speichern“ sendet wieder korrekt an WordPress.

## 1.5.0

- Manuellen Mailimport-Testlauf ergänzt.
- Importstatus und Fehlerprotokoll im Admin-Panel ergänzt.

## 1.4.0

- Erstes Bild aus einem Mailanhang als Beitragsbild übernommen.
- Bildanhänge über der eingestellten Maximalgröße verworfen.
- Info-Kategorie aus der Mailzeile `Kategorie` übernommen.

## 1.3.0

- Separate IMAP-Benutzer und Passwörter für Termine, Nachrichten und Infos ergänzt.
- Mailimport auf drei getrennte Postfächer umgestellt.

## 1.2.1

- Mailstruktur-Dokumentation im Admin-Panel ergänzt.
- Einstellbare maximale Bildgröße für Mailanhänge ergänzt.

## 1.2.0

- IMAP-Mailimport für Termine, Nachrichten und Infos ergänzt.
- Absender-Whitelist und Betreff-/Textübernahme integriert.
- Terminangaben aus Mailzeilen `Datum`, `Uhrzeit` und `Ort` werden übernommen.

## 1.1.1

- Unterschiedliche Standardwerte für die App-Farben im Admin-Panel ergänzt.

## 1.1.0

- Administrationspanel für Mailadressen, Absender-Whitelist und App-Farben ergänzt.
- Einstellbare Farben werden im Frontend als CSS-Variablen verwendet.

## 1.0.3

- Abgelaufene Termine zusätzlich direkt in der App ausgeblendet.
- REST-Inhalte werden nicht mehr aus dem Service-Worker-Cache geladen.

## 1.0.2

- Orts-Icon bei mehrzeiligem Umbruch oben an der ersten Textzeile ausgerichtet.

## 1.0.1

- Loader beim manuellen Aktualisieren verbessert.
- Aktueller Bereich und geöffnete Detailansicht bleiben nach dem Aktualisieren erhalten.

## 1.0.0

- Manuelles Aktualisieren durch Wischen nach unten ergänzt.
- Loader während des Datenabrufs ergänzt.
- Automatische Intervallabfrage entfernt.

## 0.9.5

- Inhalte werden während der geöffneten App automatisch alle 30 Sekunden aktualisiert.

## 0.9.4

- Inhalte werden bei Aktualisierung und beim Zurückkehren zur App frisch geladen.
- API-Abruf für aktuelle Nachrichten und Infos vom Browser-Cache ausgenommen.

## 0.9.3

- Info-Kategorien korrekt an die App-API übergeben.

## 0.9.2

- Info-Filter bei Terminen und Nachrichten zuverlässig ausgeblendet.

## 0.9.1

- Kategorie-Buttons nur noch im Tab „Infos“ sichtbar.
- Beschreibungstexte aus Termin- und Info-Cards entfernt.
- Nachrichten behalten eine kurze Einleitung.

## 0.9.0

- Info-Kategorien Regiment, Korps und Zug im Backend ergänzt.
- Filterleiste mit Alle, Regiment, Korps und Zug ergänzt.
- Info-Übersicht zeigt nur noch die Überschriften.

## 0.8.2

- Datumsangaben bei Nachrichten und Infos entfernt.
- Überschriften in Cards und Detailansicht bündig ausgerichtet.

## 0.8.1

- Uhrzeit und Ort in Termin-Cards getrennt dargestellt.
- Lokale Uhr- und Orts-Icons ergänzt.
- Uhrzeit um „Uhr“ ergänzt.

## 0.8.0

- Lokale SVG-Icons für Termine, Nachrichten und Infos ergänzt.
- Navigation auf scharfe, farbsteuerbare Icons umgestellt.

## 0.7.2

- Hintergrundbilder aus den Cards entfernt und ausschließlich in den Datums-Badges dargestellt.
- `--schuetzen-green-dark` als 60%-Overlay für Badges und Detailansicht ergänzt.

## 0.7.1

- Bilddarstellung in Cards und Detailansicht korrigiert.
- Detailansicht nutzt jetzt den Tab „Termine“ als Rückkehr zur Terminübersicht.

## 0.7.0

- Beitragsbilder für Termine, Nachrichten und Infos ergänzt.
- Klickbare Cards mit Detailansicht und Hintergrundbild ergänzt.
- Kurztexte nach 50 Zeichen gekürzt.

## 0.6.2

- Vergangene Termine werden ab dem Folgetag ausgeblendet.
- Termin-Cards mit Datumsblock und Wochenüberschriften gestaltet.

## 0.6.1

- Hochformat als bevorzugte App-Ausrichtung festgelegt.
- Hinweis bei mobiler Querformat-Nutzung ergänzt.

## 0.6.0

- App-Optik mit kompakter Kopfzeile, Vereinsabzeichen und unterer Navigation überarbeitet.
- Kartenlayout und mobile App-Anmutung verbessert.

## 0.5.0

- Vereinsabzeichen als PWA-App-Icons ergänzt.
- Apple-Startbildschirm-Metadaten ergänzt.
- Root-Service-Worker mit Offline-Cache ergänzt.

## 0.4.0

- Eigenständige App-Seite ohne WordPress-Theme-Rahmen ergänzt.

## 0.3.1

- Datumsanzeige im Format „Wochentag, dd. Monat JJJJ“ ergänzt.

## 0.3.0

- Backend-Bereiche für Termine, Nachrichten und Infos ergänzt.
- Navigation zwischen den Inhaltsbereichen ergänzt.

## 0.2.0

- PWA-Grundgerüst, responsive Frontend-Oberfläche und REST-Endpunkt ergänzt.

## 0.1.0

- Erste Plugin-Grundversion mit eigener Update-Anbindung.
