(function () {
	'use strict';

	var root = document.getElementById('schuetzen-app');
	var config = window.SchuetzenAppConfig || {};
	var primaryGroup = String(config.primaryGroup || '');
	var importHorizonEnd = String(config.importHorizonEnd || '');
	var currentView = { section: 0, category: '', detailId: null };
	var activeHeader = null;
	var lastScrollY = window.scrollY;
	var externalEventsPreferenceKey = 'schuetzenAppShowExternalEvents';
	var hiddenExternalSourcesPreferenceKey = 'schuetzenAppHiddenExternalSources';
	var showExternalEvents = true;
	var hiddenExternalSources = {};
	try {
		showExternalEvents = window.localStorage.getItem(externalEventsPreferenceKey) !== 'false';
	} catch (storageError) {
		showExternalEvents = true;
	}
	try {
		var storedHiddenSources = JSON.parse(window.localStorage.getItem(hiddenExternalSourcesPreferenceKey) || '[]');
		if (Array.isArray(storedHiddenSources)) {
			storedHiddenSources.forEach(function (sourceId) { hiddenExternalSources[String(sourceId)] = true; });
		}
	} catch (storageError) {
		hiddenExternalSources = {};
	}

if (!root) {
    return;
}

window.addEventListener('scroll', function () {
		var currentScrollY = window.scrollY;
		if (activeHeader) {
			activeHeader.classList.toggle('is-scrolling-up', currentScrollY > 0 && currentScrollY < lastScrollY);
		}
		lastScrollY = currentScrollY;
	}, { passive: true });

function requestPortrait() {
    if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('portrait').catch(function () {
            // Einige Browser erlauben die Sperre nur im installierten App-Modus.
        });
    }
}

requestPortrait();
document.addEventListener('click', requestPortrait, { once: true });

	function escapeHtml(value) {
		return String(value || '').replace(/[&<>'"]/g, function (character) {
			return {
				'&': '&amp;',
				'<': '&lt;',
				'>': '&gt;',
				"'": '&#039;',
				'"': '&quot;'
			}[character];
		});
	}

	function decodeHtmlEntities(value) {
		var textarea = document.createElement('textarea');
		textarea.innerHTML = String(value || '');
		return textarea.value;
	}

	function escapeText(value) {
		return escapeHtml(decodeHtmlEntities(value));
	}

	function formatDate(value) {
		var parts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || '');
		if (!parts) {
			return value || '';
		}

		var date = new Date(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3]));
		return new Intl.DateTimeFormat('de-DE', {
			weekday: 'long',
			day: '2-digit',
			month: 'long',
			year: 'numeric'
		}).format(date);
	}

	function parseDate(value) {
		var parts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || '');
		return parts ? new Date(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3])) : null;
	}

	function dateBadge(value) {
		var date = parseDate(value);
		if (!date) {
			return '';
		}
		return '<span class="schuetzen-app__date-badge"><strong>' +
			escapeHtml(new Intl.DateTimeFormat('de-DE', { day: '2-digit' }).format(date)) +
			'</strong><small>' + escapeHtml(new Intl.DateTimeFormat('de-DE', { month: 'short' }).format(date).replace('.', '').toUpperCase()) + '</small></span>';
	}

	function weekInfo(value) {
		var parts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || '');
		if (!parts) {
			return { key: 'weitere-termine', label: 'Weitere Termine' };
		}

		var date = new Date(Date.UTC(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3])));
		var day = date.getUTCDay() || 7;
		date.setUTCDate(date.getUTCDate() + 4 - day);
		var weekYear = date.getUTCFullYear();
		var yearStart = new Date(Date.UTC(weekYear, 0, 1));
		var week = Math.ceil((((date - yearStart) / 86400000) + 1) / 7);

		return {
			key: String(weekYear) + '-' + String(week).padStart(2, '0'),
			label: 'Woche ' + week
		};
	}

	function excerpt(value) {
		var text = decodeHtmlEntities(String(value || '').replace(/<[^>]*>/g, '')).replace(/\s+/g, ' ').trim();
		return text.length > 50 ? text.slice(0, 50).trim() + '...' : text;
	}

	function eventMeta(entry, includeAllDayDate) {
		var html = '';
		if (entry.all_day && includeAllDayDate) {
			var dateLabel = formatDate(entry.date);
			if (entry.end_date && entry.end_date !== entry.date) {
				dateLabel += ' – ' + formatDate(entry.end_date);
			}
			html += '<span><img src="' + escapeHtml((config.iconBase || '') + 'calendar-alt-regular.svg') + '" alt="" aria-hidden="true">' + escapeHtml(dateLabel) + '</span>';
		}
		if (entry.time && entry.time_after) {
			html += '<span><img src="' + escapeHtml((config.iconBase || '') + 'clock-regular.svg') + '" alt="" aria-hidden="true">' + escapeText(entry.time_after_text || 'Danach') + '</span>';
		} else if (entry.time) {
			html += '<span><img src="' + escapeHtml((config.iconBase || '') + 'clock-regular.svg') + '" alt="" aria-hidden="true">' + (entry.time_approx ? 'ca. ' : '') + escapeText(entry.time) + ' Uhr</span>';
		}
		if (entry.location) {
			html += '<span><img src="' + escapeHtml((config.iconBase || '') + 'map-regular.svg') + '" alt="" aria-hidden="true">' + escapeText(entry.location) + '</span>';
		}
		if (entry.meeting_point) {
			html += '<span><img src="' + escapeHtml((config.iconBase || '') + 'location-dot-solid.svg') + '" alt="" aria-hidden="true">' + escapeText(entry.meeting_point) + '</span>';
		}
		return html;
	}

	function eventTint(color) {
		var rgba = /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)$/i.exec(String(color || ''));
		if (!rgba) return 'rgba(75,85,99,0.10)';
		var opacity = rgba[4] === undefined ? 1 : Math.min(1, Math.max(0, Number(rgba[4])));
		return 'rgba(' + rgba[1] + ',' + rgba[2] + ',' + rgba[3] + ',' + (opacity * 0.1).toFixed(3) + ')';
	}

	function eventStyle(entry) {
		var colors = config.groupColors || {};
		var color = colors[entry && entry.category] || '#ffffff';
		return ' style="--schuetzen-event-border:' + color + ';--schuetzen-event-tint:' + eventTint(color) + '"';
	}

	function eventGroupLabel(entry) {
		var labels = config.groupLabels || {};
		var label = labels[entry && entry.category] || '';
		return label ? '<p class="schuetzen-app__event-group">' + escapeText(label) + '</p>' : '';
	}

	function setSectionBackground(section) {
		root.classList.remove('is-detail-view');
		root.style.removeProperty('--schuetzen-detail-image');
		var keys = ['events', 'messages', 'info'];
		var image = config.sectionBackgrounds && config.sectionBackgrounds[keys[section]];
		root.classList.toggle('has-section-background', Boolean(image));
		if (image) {
			root.style.setProperty('--schuetzen-section-image', 'url("' + String(image).replace(/"/g, '\\"') + '")');
		} else {
			root.style.removeProperty('--schuetzen-section-image');
		}
	}

	function eventCard(entry, nested) {
		var meta = eventMeta(entry, nested);
		return '<article tabindex="0" role="button" data-event-id="' + escapeHtml(String(entry.id)) + '" class="' + (nested ? 'schuetzen-app__day-event' : 'schuetzen-app__event') + '"' + eventStyle(entry) + '>' +
			(nested ? '' : '<div class="schuetzen-app__event-date">' + (entry.image ? '<span class="schuetzen-app__date-image" style="background-image:url(&quot;' + escapeHtml(entry.image) + '&quot;)">' + dateBadge(entry.date) + '</span>' : dateBadge(entry.date)) + '</div>') +
			'<div class="schuetzen-app__event-body">' + eventGroupLabel(entry) + '<h3>' + escapeText(entry.title) + '</h3>' +
			(!nested ? '<p class="schuetzen-app__event-day">' + escapeHtml(formatDate(entry.date) + (entry.end_date && entry.end_date !== entry.date ? ' – ' + formatDate(entry.end_date) : '')) + '</p>' : '') +
			(meta ? '<p class="schuetzen-app__event-meta">' + meta + '</p>' : '') + '</div></article>';
	}

	function dayCard(day) {
		var header = day.container || { title: formatDate(day.date), date: day.date };
		var badge = header.image ? '<span class="schuetzen-app__date-image" style="background-image:url(&quot;' + escapeHtml(header.image) + '&quot;)">' + dateBadge(day.date) + '</span>' : dateBadge(day.date);
		return '<section class="schuetzen-app__day-card"' + eventStyle(header) + '><div class="schuetzen-app__day-header"><div class="schuetzen-app__event-date">' + badge + '</div><div>' + eventGroupLabel(header) + '<h3>' + escapeText(header.title) + '</h3><p class="schuetzen-app__event-day">' + escapeHtml(formatDate(day.date)) + '</p></div></div><div class="schuetzen-app__day-events">' + day.entries.map(function (entry) { return eventCard(entry, true); }).join('') + '</div></section>';
	}

	function marchOrderMarkup(order) {
		var blocks = order && Array.isArray(order.blocks) ? order.blocks : (order && order.rows ? [order.rows] : []);
		if (!blocks.length) {
			return '';
		}
		if (String(order.title || '').trim().toLowerCase() === 'wolke') {
			var people = [];
			blocks.forEach(function (block) {
				(block || []).forEach(function (row) {
					[0, 1, 2].forEach(function (slot) {
						if (row && row[slot]) people.push(row[slot]);
					});
				});
			});
			return '<section class="schuetzen-app__march-order schuetzen-app__march-order--cloud"><h3>Marschordnung &quot;Wolke&quot;</h3><div class="schuetzen-app__person-cloud">' + people.map(function (person, index) {
				var portrait = person.image ? '<img src="' + escapeHtml(person.image) + '" alt="" aria-hidden="true">' : '<img src="' + escapeHtml((config.iconBase || '') + 'user-regular.svg') + '" alt="" aria-hidden="true">';
				var x = 5 + ((index * 37) % 86);
				var y = 8 + ((index * 61) % 78);
				var dx = ((index % 2 ? 1 : -1) * (1.5 + (index % 4) * 0.7)).toFixed(1);
				var dy = ((index % 3 ? -1 : 1) * (1 + (index % 3) * 0.8)).toFixed(1);
				var duration = 5 + (index % 5);
				var delay = -(index % 6);
				var style = ' style="--cloud-x:' + x + '%;--cloud-y:' + y + '%;--cloud-dx:' + dx + 'rem;--cloud-dy:' + dy + 'rem;--cloud-duration:' + duration + 's;--cloud-delay:' + delay + 's"';
				return '<span class="schuetzen-app__cloud-person"' + style + '>' + portrait + '<strong>' + escapeText(person.name) + '</strong></span>';
			}).join('') + '</div></section>';
		}
		return '<section class="schuetzen-app__march-order"><h3>' + escapeText(order.title || 'Marschordnung') + '</h3>' + blocks.map(function (block, blockIndex) {
			if (!block || !block.length) return '';
			return '<div class="schuetzen-app__march-block">' + (blocks.length > 1 ? '<h4 class="schuetzen-app__march-block-title">Marschblock ' + (blockIndex + 1) + '</h4>' : '') + '<div class="schuetzen-app__formation">' + block.map(function (row) {
				return '<div class="schuetzen-app__formation-row">' + [0, 1, 2].map(function (slot) {
				var person = row[slot];
				if (!person) {
					return '<span class="schuetzen-app__person schuetzen-app__person--empty" aria-hidden="true"></span>';
				}
				var portrait = person.image ? '<img src="' + escapeHtml(person.image) + '" alt="" aria-hidden="true">' : '<img src="' + escapeHtml((config.iconBase || '') + 'user-regular.svg') + '" alt="" aria-hidden="true">';
				return '<span class="schuetzen-app__person">' + portrait + '<strong>' + escapeText(person.name) + '</strong>' + (person.role ? '<small>' + escapeText(person.role) + '</small>' : '') + '</span>';
				}).join('') + '</div>';
			}).join('') + '</div></div>';
		}).join('') + '</section>';
	}

	function filterCurrentEvents(events) {
		var today = new Date();
		var todayKey = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
		return (events || []).filter(function (event) { return !event.date || event.date >= todayKey || (event.end_date && event.end_date >= todayKey); });
	}

	function showDetail(content, entry, section) {
		currentView = { section: section, category: '', detailId: entry.id };
		root.classList.remove('has-section-background');
		root.classList.add('is-detail-view');
		if (entry.image) {
			root.style.setProperty('--schuetzen-detail-image', 'url("' + String(entry.image).replace(/"/g, '\\"') + '")');
		} else {
			root.style.removeProperty('--schuetzen-detail-image');
		}
		var meta = section === 0 ? eventMeta(entry, true) : formatDate(entry.date);
		var source = section === 0 && entry.source_url ? '<p class="schuetzen-app__event-source"><a href="' + escapeHtml(entry.source_url) + '" target="_blank" rel="noopener">Originaltermin bei ' + escapeText(entry.source_name || 'der Kalenderquelle') + ' öffnen</a></p>' : '';
		content.innerHTML = '<article class="schuetzen-app__detail"><div class="schuetzen-app__detail-content"><h2>' + escapeText(entry.title) + '</h2>' +
			(section === 0 ? '<p class="schuetzen-app__event-meta">' + meta + '</p>' : '') + (entry.description || '') + source + (section === 0 ? marchOrderMarkup(entry.march_order) : '') + '</div></article>';
	}

	function showPreferences(content, data) {
		var previous = root.querySelector('.schuetzen-app__preferences-modal');
		if (previous) previous.remove();
		var modal = document.createElement('div');
		modal.className = 'schuetzen-app__preferences-modal';
		modal.setAttribute('role', 'dialog');
		modal.setAttribute('aria-modal', 'true');
		modal.setAttribute('aria-labelledby', 'schuetzen-app-preferences-title');
		var sources = (Array.isArray(data.calendar_sources) ? data.calendar_sources : []).filter(function (source) {
			return String(source.group || '') !== primaryGroup;
		});
		var sourceOptions = sources.length ? '<fieldset class="schuetzen-app__source-preferences"><legend>Einzelne Quellen</legend>' + sources.map(function (source) {
			return '<label class="schuetzen-app__preference"><input type="checkbox" data-external-source="' + escapeHtml(source.id) + '"><span><strong>' + escapeText(source.name) + '</strong><small>Termine dieser Quelle anzeigen</small></span></label>';
		}).join('') + '</fieldset>' : '<p class="schuetzen-app__no-sources">Es sind keine zusätzlich steuerbaren externen Kalenderquellen eingerichtet.</p>';
		modal.innerHTML = '<div class="schuetzen-app__preferences-panel"><button type="button" class="schuetzen-app__preferences-close" aria-label="Einstellungen schließen">×</button>' +
			'<h2 id="schuetzen-app-preferences-title">Einstellungen</h2><p>Lege fest, welche Termine in dieser App angezeigt werden.</p>' +
			'<label class="schuetzen-app__preference schuetzen-app__preference--all"><input type="checkbox" data-external-events-toggle><span><strong>Alle weiteren externen Termine anzeigen</strong><small>Termine der Hauptgruppe und lokale Termine bleiben immer sichtbar.</small></span></label>' + sourceOptions + '</div>';
		root.appendChild(modal);
		var checkbox = modal.querySelector('[data-external-events-toggle]');
		var sourceCheckboxes = modal.querySelectorAll('[data-external-source]');
		checkbox.checked = showExternalEvents;
		sourceCheckboxes.forEach(function (sourceCheckbox) {
			sourceCheckbox.checked = !hiddenExternalSources[sourceCheckbox.getAttribute('data-external-source')];
		});
		var updateSourceControls = function () {
			sourceCheckboxes.forEach(function (sourceCheckbox) {
				sourceCheckbox.disabled = !showExternalEvents;
				sourceCheckbox.closest('.schuetzen-app__preference').classList.toggle('is-disabled', !showExternalEvents);
			});
		};
		var refreshEvents = function () {
			if (currentView.section === 0) {
				currentView.detailId = null;
				renderSection(content, 0, data, '');
			}
		};
		var close = function () { modal.remove(); document.removeEventListener('keydown', onKey); };
		var onKey = function (event) { if (event.key === 'Escape') close(); };
		modal.addEventListener('click', function (event) { if (event.target === modal) close(); });
		modal.querySelector('.schuetzen-app__preferences-close').addEventListener('click', close);
		checkbox.addEventListener('change', function () {
			showExternalEvents = checkbox.checked;
			updateSourceControls();
			try {
				window.localStorage.setItem(externalEventsPreferenceKey, showExternalEvents ? 'true' : 'false');
			} catch (storageError) {
				// Die Einstellung gilt dann nur bis zum nächsten Laden der App.
			}
			refreshEvents();
		});
		sourceCheckboxes.forEach(function (sourceCheckbox) {
			sourceCheckbox.addEventListener('change', function () {
				var sourceId = sourceCheckbox.getAttribute('data-external-source');
				if (sourceCheckbox.checked) {
					delete hiddenExternalSources[sourceId];
				} else {
					hiddenExternalSources[sourceId] = true;
				}
				try {
					window.localStorage.setItem(hiddenExternalSourcesPreferenceKey, JSON.stringify(Object.keys(hiddenExternalSources)));
				} catch (storageError) {
					// Die Einstellung gilt dann nur bis zum nächsten Laden der App.
				}
				refreshEvents();
			});
		});
		updateSourceControls();
		document.addEventListener('keydown', onKey);
		modal.querySelector('.schuetzen-app__preferences-close').focus();
	}

	var pdfJsPromise = null;

	function loadPdfJs() {
		if (window.pdfjsLib) {
			return Promise.resolve(window.pdfjsLib);
		}
		if (!pdfJsPromise) {
			pdfJsPromise = new Promise(function (resolve, reject) {
				var script = document.createElement('script');
				script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
				script.onload = function () { resolve(window.pdfjsLib); };
				script.onerror = reject;
				document.head.appendChild(script);
			});
		}
		return pdfJsPromise;
	}

	function showPdfModal(entry) {
		var modal = document.createElement('div');
		modal.className = 'schuetzen-app__pdf-modal';
		modal.setAttribute('role', 'dialog');
		modal.setAttribute('aria-modal', 'true');
		modal.setAttribute('aria-label', entry.title);
		modal.innerHTML = '<div class="schuetzen-app__pdf-panel"><button type="button" class="schuetzen-app__pdf-close" aria-label="PDF schließen">×</button><h2>' + escapeText(entry.title) + '</h2><div class="schuetzen-app__pdf-toolbar"><button type="button" data-pdf-zoom-out aria-label="Verkleinern">−</button><span data-pdf-zoom>100 %</span><button type="button" data-pdf-zoom-in aria-label="Vergrößern">+</button></div><p class="schuetzen-app__pdf-status">PDF wird geladen …</p><div class="schuetzen-app__pdf-scroll"></div></div>';
		root.appendChild(modal);
		var close = function () { modal.remove(); document.removeEventListener('keydown', onKey); };
		var onKey = function (event) { if (event.key === 'Escape') close(); };
		modal.addEventListener('click', function (event) { if (event.target === modal) close(); });
		modal.querySelector('.schuetzen-app__pdf-close').addEventListener('click', close);
		document.addEventListener('keydown', onKey);

		loadPdfJs().then(function (pdfjsLib) {
			pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
			return pdfjsLib.getDocument(entry.pdf).promise;
		}).then(function (pdf) {
			var scroll = modal.querySelector('.schuetzen-app__pdf-scroll');
			var status = modal.querySelector('.schuetzen-app__pdf-status');
			var zoomLabel = modal.querySelector('[data-pdf-zoom]');
			var zoom = 1;
			status.remove();
			var renderPages = function () {
				scroll.innerHTML = '';
				zoomLabel.textContent = Math.round(zoom * 100) + ' %';
				return Array.from({ length: pdf.numPages }, function (_, index) { return index + 1; }).reduce(function (promise, pageNumber) {
					return promise.then(function () {
						return pdf.getPage(pageNumber).then(function (page) {
							var baseViewport = page.getViewport({ scale: 1 });
							var scale = Math.max(1, scroll.clientWidth / baseViewport.width) * zoom;
							var viewport = page.getViewport({ scale: scale });
							var pixelRatio = Math.min(3, window.devicePixelRatio || 1);
							var canvas = document.createElement('canvas');
							canvas.className = 'schuetzen-app__pdf-page';
							canvas.width = Math.floor(viewport.width * pixelRatio);
							canvas.height = Math.floor(viewport.height * pixelRatio);
							canvas.style.width = viewport.width + 'px';
							canvas.style.height = viewport.height + 'px';
							scroll.appendChild(canvas);
							var context = canvas.getContext('2d');
							context.scale(pixelRatio, pixelRatio);
							return page.render({ canvasContext: context, viewport: viewport }).promise;
						});
					});
				}, Promise.resolve());
			};
			modal.querySelector('[data-pdf-zoom-in]').addEventListener('click', function () {
				zoom = Math.min(3, zoom + 0.25);
				renderPages();
			});
			modal.querySelector('[data-pdf-zoom-out]').addEventListener('click', function () {
				zoom = Math.max(0.75, zoom - 0.25);
				renderPages();
			});
			return renderPages();
		}).catch(function () {
			var status = modal.querySelector('.schuetzen-app__pdf-status');
			if (status) {
				status.innerHTML = 'PDF konnte nicht eingebettet werden. <a href="' + escapeHtml(entry.pdf) + '" target="_blank" rel="noopener">PDF separat öffnen</a>';
			}
		});
	}

	function render(data) {
		data.events = filterCurrentEvents(data.events);
		window.SchuetzenAppData = data;
		root.classList.remove('is-detail-view');
		root.classList.remove('has-section-background');
		root.style.removeProperty('--schuetzen-detail-image');
		root.style.removeProperty('--schuetzen-section-image');
		root.innerHTML = '';

		var header = document.createElement('header');
		header.className = 'schuetzen-app__topbar';
		activeHeader = header;
		var headerTitle = config.brandLine2 || config.appName || 'Schützen-App';
		header.innerHTML = (config.iconUrl ? '<img class="schuetzen-app__logo" src="' + escapeHtml(config.iconUrl) + '" alt="" />' : '') +
			'<span class="schuetzen-app__brand">' + (config.brandLine1 ? '<small>' + escapeHtml(config.brandLine1) + '</small>' : '') + '<h1 class="schuetzen-app__brand-title">' + escapeHtml(headerTitle) + '</h1>' + (config.brandLine3 ? '<span>' + escapeHtml(config.brandLine3) + '</span>' : '') + '</span>';
		root.appendChild(header);

		var nav = document.createElement('nav');
		nav.className = 'schuetzen-app__nav';
		nav.setAttribute('aria-label', 'App-Navigation');
		var content = document.createElement('main');
		content.className = 'schuetzen-app__content';
		var navButtons = [];

		var enabledSections = config.enabledSections || {};
		var navigationItems = [{ label: 'Termine', icon: 'calendar-alt-regular.svg', section: 0 }];
		if (enabledSections.messages !== false) navigationItems.push({ label: 'Nachrichten', icon: 'paper-plane-regular.svg', section: 1 });
		if (enabledSections.info !== false) navigationItems.push({ label: 'Infos', icon: 'lightbulb-regular.svg', section: 2 });
		nav.style.gridTemplateColumns = 'repeat(' + (navigationItems.length + 1) + ', 1fr)';

		navigationItems.forEach(function (item) {
			var button = document.createElement('button');
			button.type = 'button';
			button.dataset.section = String(item.section);
			button.innerHTML = '<img src="' + escapeHtml((config.iconBase || '') + item.icon) + '" alt="" aria-hidden="true"><span>' + escapeHtml(item.label) + '</span>';
			button.setAttribute('aria-current', item.section === 0 ? 'page' : 'false');
			button.addEventListener('click', function () {
				currentView = { section: item.section, category: '', detailId: null };
				nav.querySelectorAll('button').forEach(function (navButton) {
					navButton.setAttribute('aria-current', navButton === button ? 'page' : 'false');
				});
				renderSection(content, item.section, data, currentView.category);
			});
			nav.appendChild(button);
			navButtons.push(button);
		});
		var preferencesButton = document.createElement('button');
		preferencesButton.type = 'button';
		preferencesButton.className = 'schuetzen-app__preferences-button';
		preferencesButton.innerHTML = '<img src="' + escapeHtml((config.iconBase || '') + 'gear-solid.svg') + '" alt="" aria-hidden="true"><span>Einstellungen</span>';
		preferencesButton.setAttribute('aria-label', 'Einstellungen öffnen');
		preferencesButton.setAttribute('aria-current', 'false');
		preferencesButton.addEventListener('click', function () { showPreferences(content, data); });
		nav.appendChild(preferencesButton);
		root.appendChild(nav);
		root.appendChild(content);
		if (currentView.detailId !== null) {
			var detailEntries = currentView.section === 0 ? data.events : (currentView.section === 1 ? data.messages : data.info);
			var detailEntry = detailEntries.find(function (entry) { return String(entry.id) === String(currentView.detailId); });
			if (detailEntry) {
				showDetail(content, detailEntry, currentView.section);
			} else {
				currentView.detailId = null;
				renderSection(content, currentView.section, data, currentView.category);
			}
		} else {
			renderSection(content, currentView.section, data, currentView.category);
		}
		navButtons.forEach(function (button) {
			button.setAttribute('aria-current', Number(button.dataset.section) === currentView.section ? 'page' : 'false');
		});
	}

	function renderSection(content, section, data, infoCategory) {
		setSectionBackground(section);
		if (section === 0) {
			var visibleEvents = (data.events || []).filter(function (event) {
				var beyondHorizon = event.external && importHorizonEnd !== '' && String(event.date || '') > importHorizonEnd;
				return !beyondHorizon && (!event.external || (primaryGroup !== '' && String(event.category || '') === primaryGroup) || (showExternalEvents && !hiddenExternalSources[String(event.source_id || '')]));
			});
			if (!visibleEvents.length) {
				content.innerHTML = '<h2>Termine</h2><p class="schuetzen-app__empty">Noch keine Termine vorhanden.</p>';
				return;
			}

			var events = visibleEvents.slice().sort(function (a, b) {
				var dateCompare = String(a.date || '').localeCompare(String(b.date || ''));
				if (dateCompare) return dateCompare;
				if (!a.time && b.time) return -1;
				if (a.time && !b.time) return 1;
				return String(a.time || '').localeCompare(String(b.time || ''));
			});
			var grouped = {};
			events.forEach(function (event) {
				var week = weekInfo(event.date);
				grouped[week.key] = grouped[week.key] || { label: week.label, events: [] };
				grouped[week.key].events.push(event);
			});
			content.innerHTML = '<h2>Termine</h2>' + Object.keys(grouped).map(function (key) {
				var days = {};
				grouped[key].events.forEach(function (event) {
					days[event.date] = days[event.date] || { date: event.date, container: null, entries: [] };
					if (!event.time && !event.all_day) {
						days[event.date].container = event;
					} else {
						days[event.date].entries.push(event);
					}
				});
				return '<h3 class="schuetzen-app__week">' + escapeHtml(grouped[key].label) + '</h3>' + Object.keys(days).map(function (date) {
					var day = days[date];
					return day.container ? dayCard(day) : day.entries.map(function (entry) { return eventCard(entry, false); }).join('');
				}).join('');
			}).join('');
			content.querySelectorAll('[data-event-id]').forEach(function (card) {
				card.addEventListener('click', function () {
					var entry = data.events.find(function (item) { return String(item.id) === String(card.dataset.eventId); });
					if (entry && (entry.time || entry.all_day)) showDetail(content, entry, 0);
				});
			});
			return;
		}

		var title = section === 1 ? 'Nachrichten' : 'Infos';
		var entries = section === 1 ? data.messages : data.info.slice().sort(function (a, b) {
			return String(a.title || '').localeCompare(String(b.title || ''), 'de', { sensitivity: 'base' });
		});

		if (!entries || !entries.length) {
			content.innerHTML = '<h2>' + title + '</h2><p class="schuetzen-app__empty">Noch keine Inhalte vorhanden.</p>';
			return;
		}

		content.innerHTML = '<h2>' + title + '</h2>' + entries.map(function (entry) {
			entry.type = section === 1 ? 'message' : 'info';
			var style = eventStyle(entry);
			return '<article tabindex="0" role="button" class="schuetzen-app__event"' + style + '><div class="schuetzen-app__event-body"><h3>' + escapeText(entry.title) + '</h3>' +
				(section === 1 && excerpt(entry.description) ? '<p class="schuetzen-app__event-excerpt">' + escapeHtml(excerpt(entry.description)) + '</p>' : '') + '</div></article>';
		}).join('');
		content.querySelectorAll('.schuetzen-app__event').forEach(function (card, index) {
			card.addEventListener('click', function () {
				if (section === 2 && entries[index].pdf) {
					showPdfModal(entries[index]);
					return;
				}
				showDetail(content, entries[index], section);
			});
		});
	}

	function renderError() {
		root.innerHTML = '<div class="schuetzen-app__error">Die App-Inhalte konnten gerade nicht geladen werden.</div>';
	}

	function loadContent(showLoader) {
		if (showLoader) {
			root.classList.add('is-refreshing');
		}
		return fetch(config.apiUrl, { credentials: 'same-origin', cache: 'no-store' })
			.then(function (response) {
			if (!response.ok) {
				throw new Error('API request failed');
			}
			return response.json();
			})
			.then(render)
			.catch(renderError)
			.finally(function () { root.classList.remove('is-refreshing'); });
	}

	loadContent();
	var touchStartY = 0;
	var refreshTriggered = false;
	document.addEventListener('touchstart', function (event) {
		if (window.scrollY === 0 && event.touches.length === 1) {
			touchStartY = event.touches[0].clientY;
			refreshTriggered = false;
		}
	}, { passive: true });
	document.addEventListener('touchmove', function (event) {
		if (touchStartY && event.touches.length === 1 && event.touches[0].clientY - touchStartY > 70) {
			refreshTriggered = true;
			root.classList.add('pull-to-refresh');
		}
	}, { passive: true });
	document.addEventListener('touchend', function () {
		if (refreshTriggered) {
			loadContent(true);
		}
		touchStartY = 0;
		refreshTriggered = false;
		root.classList.remove('pull-to-refresh');
	}, { passive: true });
	document.addEventListener('visibilitychange', function () {
		if (document.visibilityState === 'visible') {
			loadContent();
		}
	});

	if (config.manifest && !document.querySelector('link[rel="manifest"]')) {
		var manifest = document.createElement('link');
		manifest.rel = 'manifest';
		manifest.href = config.manifest;
		document.head.appendChild(manifest);
	}

	if ('serviceWorker' in navigator && config.workerUrl) {
		navigator.serviceWorker.register(config.workerUrl, { scope: '/' }).catch(function () {
			// Offline support is optional; the online app remains usable.
		});
	}
})();
