<?php

defined( 'ABSPATH' ) || exit;

$app_markup = do_shortcode( '[schuetzen_app]' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="color-scheme" content="light">
	<meta name="supported-color-schemes" content="light">
	<meta name="theme-color" content="#1e4d3a">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="default">
	<link rel="apple-touch-icon" href="<?php echo esc_url( get_site_icon_url( 180 ) ?: plugin_dir_url( SCHUETZEN_APP_FILE ) . 'assets/icons/icon-192.png' ); ?>">
	<title><?php echo esc_html( get_bloginfo( 'name' ) ); ?></title>
	<?php wp_head(); ?>
</head>
<body class="schuetzen-app-standalone">
	<?php echo $app_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<?php wp_footer(); ?>
</body>
</html>
