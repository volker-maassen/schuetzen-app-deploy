# Schützen-App

Schlanke WordPress-Grundlage für Termine, Nachrichten und Vereinsinformationen.

## Aktueller Stand

Version `0.1.0` enthält zunächst nur das Plugin-Grundgerüst und die Anbindung an den zentralen Update-Endpunkt:

`https://raw.githubusercontent.com/volker-maassen/schuetzen-app-deploy/main/schuetzen-app/update.json`

Die eigentlichen Vereinsfunktionen werden anschließend schrittweise ergänzt.
